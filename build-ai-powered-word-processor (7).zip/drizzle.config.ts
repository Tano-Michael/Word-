import { config as loadEnv } from "dotenv";
import type { Config } from "drizzle-kit";

// Load DATABASE_URL from the user's .env file
loadEnv();

const url = process.env.DATABASE_URL;

if (!url) {
  throw new Error(
    "DATABASE_URL is not set.\n" +
      "Create a file named .env in the project root containing:\n" +
      "  DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/aether"
  );
}

export default {
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: { url },
} satisfies Config;
