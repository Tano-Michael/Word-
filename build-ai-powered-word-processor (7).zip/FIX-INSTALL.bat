@echo off
setlocal EnableDelayedExpansion
title Aether - Fix Installation
color 0E

cd /d "%~dp0"

echo.
echo   ============================================================
echo                  AETHER - FIX INSTALLATION
echo   ============================================================
echo.
echo   Use this only if INSTALL.bat has been stuck on "2/5"
echo   for more than 5 minutes without new output.
echo.
echo   This removes incomplete downloaded components and retries.
echo   YOUR DOCUMENTS in the "data" folder are NOT touched.
echo.
set "CONFIRM="
set /p CONFIRM="   Continue? (Y/n): "
if /i "!CONFIRM!"=="n" goto :end

where node >nul 2>nul
if errorlevel 1 (
    color 0C
    echo.
    echo   [X] Node.js is missing. Run INSTALL.bat instead.
    goto :end
)

echo.
echo   [1/4] Checking the npm download cache...
call npm cache verify
if errorlevel 1 (
    echo       Cache check had an issue - clearing only the cache.
    call npm cache clean --force
)

echo.
echo   [2/4] Removing incomplete components...
if exist "node_modules" (
    rmdir /s /q "node_modules"
)
if exist "package-lock.json" (
    echo       Package lock found - clean install will use it.
)
echo       Done.

echo.
echo   [3/4] Downloading components again...
echo.
echo   This can take 5-15 minutes on the first download. Keep this
echo   window open. Package names or a progress spinner should change.
echo.

REM Avoid extremely long stalled network retries.
set "npm_config_fetch_retries=2"
set "npm_config_fetch_retry_mintimeout=5000"
set "npm_config_fetch_retry_maxtimeout=30000"
set "npm_config_fetch_timeout=120000"

if exist "package-lock.json" (
    call npm ci --no-audit --no-fund --prefer-offline --foreground-scripts
) else (
    call npm install --no-audit --no-fund --prefer-offline --foreground-scripts
)

if errorlevel 1 (
    color 0C
    echo.
    echo   [X] Components could not be downloaded.
    echo.
    echo   Most likely causes:
    echo     - Internet connection interrupted
    echo     - Corporate/school firewall blocks npmjs.org
    echo     - Windows Defender or antivirus is scanning the folder
    echo.
    echo   Try moving this folder to C:\Aether, then run this file again.
    echo   If it still fails, send a screenshot of the last red npm error.
    goto :end
)

echo.
echo   [4/4] Building Aether...
call npm run build
if errorlevel 1 (
    color 0C
    echo.
    echo   [X] Build failed. Run DIAGNOSE.bat and keep its output.
    goto :end
)

color 0A
echo.
echo   ============================================================
echo                        REPAIR COMPLETE
echo   ============================================================
echo.
echo   Double-click Aether.bat or your Desktop shortcut to start.
echo.

:end
pause
endlocal
exit /b 0
