import { NextRequest, NextResponse } from "next/server";
import { htmlToPlain } from "@/lib/ai-engine";
import { htmlToDocxBuffer } from "@/lib/html-to-docx";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

function htmlToMarkdown(html: string): string {
  let md = html;
  md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, "# $1\n\n");
  md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, "## $1\n\n");
  md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, "### $1\n\n");
  md = md.replace(/<h4[^>]*>(.*?)<\/h4>/gi, "#### $1\n\n");
  md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**");
  md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**");
  md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*");
  md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, "*$1*");
  md = md.replace(/<u[^>]*>(.*?)<\/u>/gi, "$1");
  md = md.replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)");
  md = md.replace(/<li[^>]*>(.*?)<\/li>/gi, "- $1\n");
  md = md.replace(/<\/?ul[^>]*>/gi, "\n");
  md = md.replace(/<\/?ol[^>]*>/gi, "\n");
  md = md.replace(/<br\s*\/?>/gi, "\n");
  md = md.replace(/<\/p>/gi, "\n\n");
  md = md.replace(/<p[^>]*>/gi, "");
  md = md.replace(/<[^>]+>/g, "");
  md = md
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"');
  return md.replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

function wrapDocxLite(title: string, plain: string) {
  // Minimal Word-compatible HTML package many apps open as .doc
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${title}</title></head><body>${plain
    .split(/\n{2,}/)
    .map((p) => `<p>${p.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\n/g, "<br>")}</p>`)
    .join("")}</body></html>`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const title = String(body.title || "document");
    const html = String(body.html || "");
    const format = String(body.format || "txt");
    const plain = htmlToPlain(html);
    const safe = title.replace(/[^\w\s-]+/g, "").trim() || "document";

    if (format === "md" || format === "markdown") {
      const md = htmlToMarkdown(html);
      return new NextResponse(md, {
        headers: {
          "Content-Type": "text/markdown; charset=utf-8",
          "Content-Disposition": `attachment; filename="${safe}.md"`,
        },
      });
    }

    if (format === "html") {
      const full = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${safe}</title>
<style>body{font-family:Georgia,serif;max-width:720px;margin:40px auto;line-height:1.7;color:#111}
h1,h2,h3{line-height:1.25} p{margin:0 0 1em}</style></head><body>${html}</body></html>`;
      return new NextResponse(full, {
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Content-Disposition": `attachment; filename="${safe}.html"`,
        },
      });
    }

    if (format === "docx") {
      const buffer = await htmlToDocxBuffer(html, safe);
      return new NextResponse(new Uint8Array(buffer), {
        headers: {
          "Content-Type":
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          "Content-Disposition": `attachment; filename="${safe}.docx"`,
          "Content-Length": String(buffer.byteLength),
        },
      });
    }

    if (format === "doc") {
      const doc = wrapDocxLite(safe, plain);
      return new NextResponse(doc, {
        headers: {
          "Content-Type": "application/msword; charset=utf-8",
          "Content-Disposition": `attachment; filename="${safe}.doc"`,
        },
      });
    }

    if (format === "json") {
      return NextResponse.json({
        title,
        html,
        plain,
        exportedAt: new Date().toISOString(),
      });
    }

    return new NextResponse(plain, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": `attachment; filename="${safe}.txt"`,
      },
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Export failed" }, { status: 500 });
  }
}
