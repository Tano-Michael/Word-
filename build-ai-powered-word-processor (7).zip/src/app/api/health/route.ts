import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { dbReady, requireDb, isEmbedded, getInitError } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await dbReady;
    const db = requireDb();
    await db.execute(sql`select 1`);
    return NextResponse.json({
      ok: true,
      mode: isEmbedded ? "embedded" : "server",
      platform: process.platform,
    });
  } catch (error) {
    const initError = getInitError();
    const message =
      error instanceof Error ? error.message : String(error ?? "unknown");
    return NextResponse.json(
      {
        ok: false,
        mode: isEmbedded ? "embedded" : "server",
        initError,
        error: message,
        hint: isEmbedded
          ? "Close Aether, delete the 'data' folder in the app folder, then start Aether.bat again."
          : "Check DATABASE_URL in your .env file.",
      },
      { status: 500 }
    );
  }
}
