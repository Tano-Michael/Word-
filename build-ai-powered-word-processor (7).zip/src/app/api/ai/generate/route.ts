import { NextRequest, NextResponse } from "next/server";
import {
  runAiGenerate,
  analyzeWriting,
  htmlToPlain,
  plainToHtml,
} from "@/lib/ai-engine";
import {
  generateWithCloud,
  getProviderStatus,
  getFreeResearchContext,
} from "@/lib/online-ai";
import type { AiMode } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MODES: AiMode[] = [
  "write",
  "continue",
  "improve",
  "summarize",
  "expand",
  "shorten",
  "outline",
  "brainstorm",
  "translate",
  "tone",
  "explain",
  "fix",
  "meeting-notes",
  "email",
  "blog",
  "proposal",
  "resume",
  "research",
];

function safeCloudHtml(raw: string): string {
  let value = raw
    .replace(/^```(?:html)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
  value = value
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<iframe[\s\S]*?<\/iframe>/gi, "")
    .replace(/\son\w+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son\w+\s*=\s*'[^']*'/gi, "")
    .replace(/javascript:/gi, "");
  return /<(?:h[1-3]|p|ul|ol|li|blockquote|strong|em|hr)[\s>]/i.test(value)
    ? value
    : plainToHtml(value);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const mode = (MODES.includes(body.mode) ? body.mode : "write") as AiMode;
    const params = {
      mode,
      prompt: String(body.prompt || ""),
      selection: body.selection ? String(body.selection) : undefined,
      documentText: body.documentText ? String(body.documentText) : undefined,
    };

    const status = getProviderStatus();
    const useCloud = body.online !== false && status.cloudAi.available;
    const cloud = useCloud
      ? await generateWithCloud(params)
      : {
          text: "",
          online: false,
          provider: status.cloudAi.provider,
          model: status.cloudAi.model,
          error: status.cloudAi.available
            ? "Cloud generation was disabled for this request."
            : "No cloud AI provider is configured.",
        };

    let freeResearch: Awaited<ReturnType<typeof getFreeResearchContext>> = {
      text: "",
      online: false,
      provider: "Wikipedia",
      model: "opensearch+summary",
      error: "Not used.",
    };

    let result;
    if (cloud.online && cloud.text.trim()) {
      const html = safeCloudHtml(cloud.text);
      const plain = htmlToPlain(html);
      const heading = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
      result = {
        html,
        plain,
        title: heading?.[1]?.replace(/<[^>]+>/g, "").trim() || undefined,
      };
    } else {
      // Free starter API: enrich research mode with a Wikipedia summary before
      // falling back to the local generator. This gives online value without an
      // API key, while keeping the main document generation private/offline.
      if (mode === "research" && body.online !== false) {
        freeResearch = await getFreeResearchContext(
          params.prompt || params.selection || params.documentText || ""
        );
      }
      result = runAiGenerate(
        freeResearch.online
          ? {
              ...params,
              prompt: `${params.prompt}\n\n${freeResearch.text}`,
            }
          : params
      );
    }

    const insights = analyzeWriting(result.plain || htmlToPlain(result.html));

    return NextResponse.json({
      ...result,
      insights,
      mode,
      engine: {
        mode: cloud.online ? "cloud" : freeResearch.online ? "free-online" : "local",
        provider: cloud.online ? cloud.provider : freeResearch.online ? freeResearch.provider : null,
        model: cloud.online ? cloud.model : freeResearch.online ? freeResearch.model : null,
        message: cloud.online
          ? `Generated online with ${cloud.provider} (${cloud.model}).`
          : freeResearch.online
            ? `Research enriched with the free Wikipedia API, then drafted by Aether local Copilot.`
            : `${cloud.error || "Cloud unavailable"} Using Aether's private local Copilot.`,
        providerStatus: status,
      },
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Generation failed" }, { status: 500 });
  }
}
