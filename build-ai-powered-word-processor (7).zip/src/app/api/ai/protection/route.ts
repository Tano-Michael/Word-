import { NextRequest, NextResponse } from "next/server";
import { analyzeProtection } from "@/lib/protection-engine";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = String(body.text || "").trim();
    if (!text) {
      return NextResponse.json({ error: "No text provided" }, { status: 400 });
    }

    const result = analyzeProtection(text);

    return NextResponse.json({
      ...result,
      originalText: text,
    });
  } catch (error) {
    console.error("Protection API error:", error);
    return NextResponse.json(
      { error: "Failed to analyze writing protection." },
      { status: 500 }
    );
  }
}
