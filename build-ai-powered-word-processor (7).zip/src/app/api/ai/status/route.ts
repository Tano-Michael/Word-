import { NextResponse } from "next/server";
import { getProviderStatus } from "@/lib/online-ai";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({
    ok: true,
    ...getProviderStatus(),
    privacy: {
      localFallback: true,
      onlineGrammar:
        "Text is sent to LanguageTool only when you explicitly choose Check online, unless paid/self-hosted automatic checking is enabled.",
      cloudAi:
        "Cloud rewriting and Copilot requests are sent only to the provider configured in the server environment. Keys are never exposed to the browser.",
    },
  });
}
