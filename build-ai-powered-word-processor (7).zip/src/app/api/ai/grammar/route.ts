import { NextRequest, NextResponse } from "next/server";
import { runGrammarCheck } from "@/lib/grammar-engine";
import { analyzeWriting } from "@/lib/ai-engine";
import {
  checkOnlineGrammar,
  checkCloudGrammar,
  getProviderStatus,
  mergeGrammarIssues,
} from "@/lib/online-ai";
import type { GrammarIssue } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = String(body.text || "");
    const localIssues = runGrammarCheck(text);
    const insights = analyzeWriting(text);
    const wantsOnline = body.online === true;

    const onlineResult = await checkOnlineGrammar(text, {
      language: typeof body.language === "string" ? body.language : "en-US",
      explicitUserAction: wantsOnline,
    });

    // When useAi is set and a cloud provider is configured, also ask the LLM
    // for corrections. This catches semantic issues that rule engines miss.
    let cloudIssues: GrammarIssue[] = [];
    const status = getProviderStatus();
    if (body.useAi && status.cloudAi.available) {
      const aiResult = await checkCloudGrammar(text);
      if (aiResult.online && aiResult.text) {
        try {
          const parsed = JSON.parse(aiResult.text);
          cloudIssues = (Array.isArray(parsed) ? parsed : [])
            .filter(
              (x: Record<string, unknown>) =>
                typeof x.original === "string" && typeof x.suggestion === "string"
            )
            .map((x: Record<string, unknown>, i: number) => ({
              id: `ai-${i}-${Date.now()}`,
              type: (["spelling", "grammar", "punctuation", "style", "clarity", "conciseness", "passive", "readability", "repetition"].includes(String(x.type)) ? x.type : "clarity") as GrammarIssue["type"],
              original: String(x.original),
              suggestion: String(x.suggestion),
              explanation: String(x.explanation || x.message || "AI-detected issue."),
              severity: (["error", "warning", "suggestion"].includes(String(x.severity)) ? x.severity : "suggestion") as GrammarIssue["severity"],
              start: 0,
              end: 0,
            }));
        } catch {
          // LLM returned unparseable JSON — ignore silently.
        }
      }
    }

    const allIssues = [
      ...localIssues,
      ...(onlineResult.online ? onlineResult.issues : []),
      ...cloudIssues,
    ];
    // Dedupe by original+suggestion pair.
    const seen = new Set<string>();
    const issues = allIssues.filter((i) => {
      const key = `${i.original.toLowerCase()}→${i.suggestion.toLowerCase()}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    const score = Math.max(
      0,
      Math.min(
        100,
        100 -
          issues.filter((i) => i.severity === "error").length * 8 -
          issues.filter((i) => i.severity === "warning").length * 3 -
          issues.filter((i) => i.severity === "suggestion").length
      )
    );

    return NextResponse.json({
      issues,
      insights,
      score,
      summary: {
        errors: issues.filter((i) => i.severity === "error").length,
        warnings: issues.filter((i) => i.severity === "warning").length,
        suggestions: issues.filter((i) => i.severity === "suggestion").length,
      },
      engine: {
        mode: cloudIssues.length > 0
          ? "ai-enhanced"
          : onlineResult.online
            ? "hybrid-online"
            : "local",
        local: "Aether Grammar",
        online: onlineResult.online ? onlineResult.provider : null,
        ai: cloudIssues.length > 0 ? status.cloudAi.provider : null,
        cached: onlineResult.cached,
        truncated: onlineResult.truncated,
        message: cloudIssues.length > 0
          ? `Enhanced with ${status.cloudAi.provider} AI (${status.cloudAi.model}) — ${cloudIssues.length} extra corrections.`
          : onlineResult.online
            ? `Checked by ${onlineResult.provider} cloud and Aether local rules.`
            : onlineResult.error || "Checked privately on this device.",
        providerStatus: status,
      },
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Grammar check failed" }, { status: 500 });
  }
}
