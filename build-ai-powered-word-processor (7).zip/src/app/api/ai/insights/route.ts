import { NextRequest, NextResponse } from "next/server";
import { analyzeWriting, extractOutlineFromHtml, extractOutlineFromText } from "@/lib/ai-engine";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = String(body.text || "");
    const html = String(body.html || "");
    const insights = analyzeWriting(text);
    const outline = html
      ? extractOutlineFromHtml(html)
      : extractOutlineFromText(text);

    const recommendations: string[] = [];
    if (insights.avgWordsPerSentence > 25) {
      recommendations.push(
        "Average sentence length is high — split long sentences for scannability."
      );
    }
    if (insights.passiveVoicePct > 30) {
      recommendations.push(
        "Passive voice is frequent — prefer active constructions for energy."
      );
    }
    if (insights.fleschReadingEase < 50) {
      recommendations.push(
        "Reading level is advanced — simplify vocabulary if writing for a general audience."
      );
    }
    if (insights.tone.friendly < 30 && insights.wordCount > 80) {
      recommendations.push(
        "Tone skews cool — a warmer phrase or two can improve connection."
      );
    }
    if (insights.uniqueWordPct < 35 && insights.wordCount > 100) {
      recommendations.push(
        "Vocabulary variety is low — Aether Rewrite can diversify phrasing."
      );
    }
    if (!recommendations.length) {
      recommendations.push(
        "Writing looks healthy. Consider adding a crisp summary or stronger close."
      );
    }

    return NextResponse.json({ insights, outline, recommendations });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Insights failed" }, { status: 500 });
  }
}
