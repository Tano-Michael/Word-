import { NextRequest, NextResponse } from "next/server";
import { generateRewriteVariants, rewriteText } from "@/lib/ai-engine";
import {
  getProviderStatus,
  rewriteWithCloud,
  rewriteWithFreeLexical,
} from "@/lib/online-ai";
import type { RewriteStyle } from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const STYLES: RewriteStyle[] = [
  "standard",
  "fluency",
  "formal",
  "simple",
  "creative",
  "expand",
  "shorten",
  "academic",
  "casual",
  "persuasive",
  "confident",
  "empathetic",
  "seo",
];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = String(body.text || "").trim();
    if (!text) {
      return NextResponse.json({ error: "text required" }, { status: 400 });
    }
    const style = (STYLES.includes(body.style) ? body.style : "standard") as RewriteStyle;
    const localVariants = generateRewriteVariants(text, style);
    const status = getProviderStatus();
    const useCloud = body.online !== false && status.cloudAi.available;
    const cloud = useCloud
      ? await rewriteWithCloud(text.slice(0, 24_000), style)
      : {
          text: "",
          online: false,
          provider: status.cloudAi.provider,
          model: status.cloudAi.model,
          error: status.cloudAi.available
            ? "Cloud rewrite was disabled for this request."
            : "No cloud AI provider is configured.",
        };

    const freeLexical = !cloud.online && body.online !== false
      ? await rewriteWithFreeLexical(text, style)
      : { text: "", online: false, provider: "Datamuse" as const, model: "free-lexical-api", error: "Not used." };

    const variants = [cloud.text, freeLexical.text, ...localVariants]
      .map((v) => v.trim())
      .filter((v, i, all) => v && all.indexOf(v) === i)
      .slice(0, 3);

    const allStyles = STYLES.map((s) => ({
      style: s,
      preview: rewriteText(text, s).slice(0, 220),
    }));

    return NextResponse.json({
      style,
      variants,
      allStyles,
      original: text,
      engine: {
        mode: cloud.online ? "cloud" : freeLexical.online ? "free-online" : "local",
        provider: cloud.online ? cloud.provider : freeLexical.online ? freeLexical.provider : null,
        model: cloud.online ? cloud.model : freeLexical.online ? freeLexical.model : null,
        message: cloud.online
          ? `Rewritten online with ${cloud.provider} (${cloud.model}).`
          : freeLexical.online
            ? `Enhanced with the free Datamuse lexical API. Add a personal LLM key later for deeper QuillBot-class paraphrasing.`
            : `${cloud.error || "Cloud unavailable"} Using Aether's private local rewriter.`,
        providerStatus: status,
      },
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Rewrite failed" }, { status: 500 });
  }
}
