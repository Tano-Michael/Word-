import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import path from "node:path";
import fs from "node:fs";
import { dbReady, requireDb, isEmbedded, getInitError } from "@/db";

export const dynamic = "force-dynamic";

interface Check {
  name: string;
  ok: boolean;
  detail: string;
}

export async function GET() {
  const checks: Check[] = [];

  checks.push({
    name: "Node.js runtime",
    ok: true,
    detail: `${process.version} on ${process.platform} (${process.arch})`,
  });

  checks.push({
    name: "Database mode",
    ok: true,
    detail: isEmbedded
      ? "Embedded (built-in, no installation needed)"
      : "PostgreSQL server via DATABASE_URL",
  });

  const dataDir = path.join(process.cwd(), "data");
  let dataWritable = false;
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    fs.accessSync(dataDir, fs.constants.W_OK);
    dataWritable = true;
  } catch {
    /* below */
  }
  checks.push({
    name: "Data folder writable",
    ok: !isEmbedded || dataWritable,
    detail: dataWritable
      ? dataDir
      : `Cannot write to ${dataDir} — move the Aether folder out of "Program Files" or OneDrive, then try again.`,
  });

  let dbOk = false;
  let dbDetail = "not tested";
  try {
    await dbReady;
    const db = requireDb();
    const res = await db.execute(sql`select count(*) as n from documents`);
    const rows = (res as { rows?: { n: string | number }[] }).rows ?? [];
    dbOk = true;
    dbDetail = `Connected · ${rows[0]?.n ?? 0} document(s) stored`;
  } catch (error) {
    dbDetail =
      (error instanceof Error ? error.message : String(error)) ||
      "connection failed";
  }
  checks.push({
    name: "Database reachable",
    ok: dbOk,
    detail: dbDetail,
  });

  const initError = getInitError();

  const advice: string[] = [];
  if (!dbOk) {
    if (isEmbedded) {
      advice.push(
        "Close Aether completely, open the app folder, DELETE the 'data' folder, then double-click Aether.bat again."
      );
      advice.push(
        "If you extracted Aether into 'Program Files', AppData-roving, or inside OneDrive/Dropbox, move the folder to somewhere simple like C:\\Aether and try again."
      );
      advice.push(
        "Temporarily disable real-time antivirus scanning on the Aether folder, then retry."
      );
    } else {
      advice.push(
        "Verify DATABASE_URL inside .env and make sure the PostgreSQL service is running."
      );
    }
  }
  if (initError) advice.push(`Startup error: ${initError}`);
  if (!advice.length) advice.push("Everything looks healthy.");

  return NextResponse.json({
    ok: checks.every((c) => c.ok),
    checks,
    advice,
    initError,
    node: process.version,
    platform: `${process.platform}/${process.arch}`,
    cwd: process.cwd(),
    time: new Date().toISOString(),
  });
}
