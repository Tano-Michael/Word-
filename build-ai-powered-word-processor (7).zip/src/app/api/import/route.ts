import { NextRequest, NextResponse } from "next/server";
import { importFileToHtml } from "@/lib/file-import";
import { analyzeWriting, htmlToPlain } from "@/lib/ai-engine";
import { documents } from "@/db/schema";
import { requireDb, dbReady } from "@/db";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MAX_BYTES = 25 * 1024 * 1024;

export async function POST(req: NextRequest) {
  try {
    await dbReady;
    const form = await req.formData();
    const file = form.get("file");
    const createDoc = form.get("createDocument") === "1";

    if (!file || typeof file === "string") {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json(
        { error: "File is larger than the 25 MB limit." },
        { status: 413 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const result = await importFileToHtml(buffer, file.name);
    const plain = htmlToPlain(result.html);
    const insights = analyzeWriting(plain);

    if (createDoc) {
      const db = requireDb();
      const [doc] = await db
        .insert(documents)
        .values({
          title: result.title,
          content: result.html,
          plainText: plain,
          wordCount: insights.wordCount,
          charCount: insights.charCount,
          folder: "Imported",
          coverColor: result.kind === "pdf" ? "#dc2626" : "#2563eb",
          aiSummary: plain.slice(0, 240),
          readingLevel: insights.gradeLevel,
          toneScore: insights.tone,
          tags: [result.kind],
          lastOpenedAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      return NextResponse.json({
        ...result,
        document: doc,
        wordCount: insights.wordCount,
      });
    }

    return NextResponse.json({ ...result, wordCount: insights.wordCount });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Import failed unexpectedly.";
    console.error("Import error:", error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
