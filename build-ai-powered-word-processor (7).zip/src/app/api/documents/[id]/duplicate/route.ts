import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { requireDb, dbReady } from "@/db";
import { documents } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    const { id } = await ctx.params;
    const [existing] = await db
      .select()
      .from(documents)
      .where(eq(documents.id, id))
      .limit(1);

    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const [copy] = await db
      .insert(documents)
      .values({
        title: `${existing.title} (copy)`,
        content: existing.content,
        contentJson: existing.contentJson,
        plainText: existing.plainText,
        wordCount: existing.wordCount,
        charCount: existing.charCount,
        folder: existing.folder,
        tags: existing.tags,
        coverColor: existing.coverColor,
        aiSummary: existing.aiSummary,
        readingLevel: existing.readingLevel,
        toneScore: existing.toneScore,
        lastOpenedAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    return NextResponse.json({ document: copy }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to duplicate" }, { status: 500 });
  }
}
