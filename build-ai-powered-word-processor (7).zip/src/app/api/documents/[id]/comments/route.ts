import { NextRequest, NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { comments } from "@/db/schema";
import { requireDb, dbReady, getInitError } from "@/db";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function fail(error: unknown, msg: string) {
  console.error(error);
  return NextResponse.json(
    { error: msg, initError: getInitError() },
    { status: 503 }
  );
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    const { id } = await ctx.params;
    const rows = await db
      .select()
      .from(comments)
      .where(eq(comments.documentId, id))
      .orderBy(desc(comments.createdAt));
    return NextResponse.json({ comments: rows });
  } catch (error) {
    return fail(error, "Failed to load comments");
  }
}

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    const { id } = await ctx.params;
    const body = await req.json();
    if (!body.body?.trim()) {
      return NextResponse.json({ error: "Comment body required" }, { status: 400 });
    }
    const [row] = await db
      .insert(comments)
      .values({
        documentId: id,
        body: body.body,
        anchorText: body.anchorText || null,
        author: body.author || "You",
        resolved: false,
      })
      .returning();
    return NextResponse.json({ comment: row }, { status: 201 });
  } catch (error) {
    return fail(error, "Failed to add comment");
  }
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    await ctx.params;
    const body = await req.json();
    if (!body.id) {
      return NextResponse.json({ error: "id required" }, { status: 400 });
    }
    const patch: { resolved?: boolean; body?: string } = {};
    if (typeof body.resolved === "boolean") patch.resolved = body.resolved;
    if (typeof body.body === "string") patch.body = body.body;
    const [row] = await db
      .update(comments)
      .set(patch)
      .where(eq(comments.id, body.id))
      .returning();
    return NextResponse.json({ comment: row });
  } catch (error) {
    return fail(error, "Failed to update comment");
  }
}
