import { NextRequest, NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import {
  documents,
  documentVersions,
  comments,
  aiSuggestions,
} from "@/db/schema";
import { requireDb, dbReady, getInitError } from "@/db";
import { analyzeWriting, htmlToPlain } from "@/lib/ai-engine";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function dbErrorResponse(error: unknown, fallback: string) {
  console.error(error);
  return NextResponse.json(
    { error: fallback, initError: getInitError() },
    { status: 503 }
  );
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    const { id } = await ctx.params;
    const [doc] = await db
      .select()
      .from(documents)
      .where(eq(documents.id, id))
      .limit(1);

    if (!doc) {
      return NextResponse.json(
        { error: "Document not found", code: "NOT_FOUND" },
        { status: 404 }
      );
    }

    // Touch lastOpenedAt, but never fail the request for it.
    db.update(documents)
      .set({ lastOpenedAt: new Date() })
      .where(eq(documents.id, id))
      .catch(() => undefined);

    // Related data loaded defensively — a failure here must not block opening.
    const [versions, docComments, suggestions] = await Promise.all([
      db
        .select()
        .from(documentVersions)
        .where(eq(documentVersions.documentId, id))
        .orderBy(desc(documentVersions.createdAt))
        .limit(30)
        .catch(() => []),
      db
        .select()
        .from(comments)
        .where(eq(comments.documentId, id))
        .orderBy(desc(comments.createdAt))
        .catch(() => []),
      db
        .select()
        .from(aiSuggestions)
        .where(eq(aiSuggestions.documentId, id))
        .orderBy(desc(aiSuggestions.createdAt))
        .limit(50)
        .catch(() => []),
    ]);

    return NextResponse.json({ document: doc, versions, comments: docComments, suggestions });
  } catch (error) {
    return dbErrorResponse(error, "Failed to load the document.");
  }
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    const { id } = await ctx.params;
    const body = await req.json();

    const [existing] = await db
      .select()
      .from(documents)
      .where(eq(documents.id, id))
      .limit(1);

    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const content =
      typeof body.content === "string" ? body.content : existing.content;
    const plainText = htmlToPlain(content);
    const insights = analyzeWriting(plainText);

    if (
      body.createVersion ||
      (existing.plainText &&
        plainText &&
        Math.abs(existing.plainText.length - plainText.length) > 400)
    ) {
      db.insert(documentVersions)
        .values({
          documentId: id,
          title: existing.title,
          content: existing.content,
          contentJson: existing.contentJson,
          plainText: existing.plainText,
          label: body.versionLabel || "Auto-save checkpoint",
        })
        .catch((e: unknown) => console.error("Version snapshot failed:", e));
    }

    const [doc] = await db
      .update(documents)
      .set({
        title: body.title ?? existing.title,
        content,
        contentJson: body.contentJson ?? existing.contentJson,
        plainText,
        wordCount: insights.wordCount,
        charCount: insights.charCount,
        status: body.status ?? existing.status,
        folder: body.folder ?? existing.folder,
        tags: body.tags ?? existing.tags,
        coverColor: body.coverColor ?? existing.coverColor,
        aiSummary: body.aiSummary ?? existing.aiSummary,
        readingLevel: insights.gradeLevel,
        toneScore: insights.tone,
        isStarred:
          typeof body.isStarred === "boolean" ? body.isStarred : existing.isStarred,
        updatedAt: new Date(),
        lastOpenedAt: new Date(),
      })
      .where(eq(documents.id, id))
      .returning();

    return NextResponse.json({ document: doc, insights });
  } catch (error) {
    return dbErrorResponse(error, "Failed to update the document.");
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  try {
    await dbReady;
    const db = requireDb();
    const { id } = await ctx.params;
    await db.delete(documents).where(eq(documents.id, id));
    return NextResponse.json({ ok: true });
  } catch (error) {
    return dbErrorResponse(error, "Failed to delete.");
  }
}
