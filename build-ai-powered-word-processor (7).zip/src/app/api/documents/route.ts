import { NextRequest, NextResponse } from "next/server";
import { desc, ilike, or } from "drizzle-orm";
import { documents } from "@/db/schema";
import { requireDb, dbReady, getInitError } from "@/db";
import { analyzeWriting, htmlToPlain } from "@/lib/ai-engine";

export const dynamic = "force-dynamic";

function dbErrorResponse(error: unknown) {
  const initError = getInitError();
  console.error(error);
  return NextResponse.json(
    {
      error:
        error instanceof Error && error.message.includes("Database is not available")
          ? error.message
          : "The database is having trouble answering.",
      initError,
      hint: "If this persists, run DIAGNOSE.bat (or open /api/diagnose).",
    },
    { status: 503 }
  );
}

export async function GET(req: NextRequest) {
  try {
    await dbReady;
    const db = requireDb();
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const folder = searchParams.get("folder");
    const starred = searchParams.get("starred");
    const templates = searchParams.get("templates");

    let rows;
    if (q) {
      rows = await db
        .select()
        .from(documents)
        .where(
          or(
            ilike(documents.title, `%${q}%`),
            ilike(documents.plainText, `%${q}%`),
            ilike(documents.aiSummary, `%${q}%`)
          )
        )
        .orderBy(desc(documents.updatedAt))
        .limit(100);
    } else {
      rows = await db
        .select()
        .from(documents)
        .orderBy(desc(documents.updatedAt))
        .limit(100);
    }

    type DocRow = typeof documents.$inferSelect;
    let filtered = rows as DocRow[];
    if (folder) filtered = filtered.filter((d: DocRow) => d.folder === folder);
    if (starred === "1") filtered = filtered.filter((d: DocRow) => d.isStarred);
    if (templates === "1") filtered = filtered.filter((d: DocRow) => d.isTemplate);
    else filtered = filtered.filter((d: DocRow) => !d.isTemplate);

    return NextResponse.json({ documents: filtered });
  } catch (error) {
    return dbErrorResponse(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await dbReady;
    const db = requireDb();
    const body = await req.json();
    const title = (body.title as string) || "Untitled Document";
    const content = (body.content as string) || "<p></p>";
    const plainText = htmlToPlain(content);
    const insights = analyzeWriting(plainText);

    const [doc] = await db
      .insert(documents)
      .values({
        title,
        content,
        contentJson: body.contentJson ?? null,
        plainText,
        wordCount: insights.wordCount,
        charCount: insights.charCount,
        status: body.status || "draft",
        folder: body.folder || "My Documents",
        tags: body.tags || [],
        coverColor: body.coverColor || "#2563eb",
        aiSummary: body.aiSummary || null,
        readingLevel: insights.gradeLevel,
        toneScore: insights.tone,
        isStarred: !!body.isStarred,
        isTemplate: !!body.isTemplate,
        templateCategory: body.templateCategory || null,
        lastOpenedAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    return NextResponse.json({ document: doc }, { status: 201 });
  } catch (error) {
    return dbErrorResponse(error);
  }
}
