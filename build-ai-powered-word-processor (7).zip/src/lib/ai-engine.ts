import type {
  GrammarIssue,
  RewriteStyle,
  WritingInsights,
  OutlineItem,
  AiMode,
} from "./types";

const COMMON_MISSPELLINGS: Record<string, string> = {
  teh: "the",
  sentance: "sentence",
  sentense: "sentence",
  eror: "error",
  erorr: "error",
  becuase: "because",
  becasue: "because",
  seperate: "separate",
  recieve: "receive",
  definately: "definitely",
  occured: "occurred",
  untill: "until",
  wierd: "weird",
  accomodate: "accommodate",
  acheive: "achieve",
  beleive: "believe",
  calender: "calendar",
  cemetary: "cemetery",
  colum: "column",
  comming: "coming",
  concensus: "consensus",
  copywrite: "copyright",
  decidely: "decidedly",
  dependant: "dependent",
  desparate: "desperate",
  embarass: "embarrass",
  enviroment: "environment",
  existance: "existence",
  experince: "experience",
  facinating: "fascinating",
  foriegn: "foreign",
  fourty: "forty",
  freind: "friend",
  goverment: "government",
  grammer: "grammar",
  harrass: "harass",
  independant: "independent",
  knowlege: "knowledge",
  liase: "liaise",
  libary: "library",
  maintainance: "maintenance",
  millenium: "millennium",
  mispell: "misspell",
  neccessary: "necessary",
  noticable: "noticeable",
  occassion: "occasion",
  occurence: "occurrence",
  parliment: "parliament",
  persue: "pursue",
  posession: "possession",
  prefered: "preferred",
  priviledge: "privilege",
  realy: "really",
  refered: "referred",
  religous: "religious",
  rember: "remember",
  remeber: "remember",
  responce: "response",
  rythm: "rhythm",
  sence: "sense",
  succesful: "successful",
  sucess: "success",
  supercede: "supersede",
  suprise: "surprise",
  thier: "their",
  tommorrow: "tomorrow",
  tounge: "tongue",
  truely: "truly",
  usefull: "useful",
  vaccum: "vacuum",
  wether: "whether",
  whitch: "which",
  writting: "writing",
  youre: "you're",
  dont: "don't",
  cant: "can't",
  wont: "won't",
  im: "I'm",
  ive: "I've",
  theyre: "they're",
  its: "it's",
};

const WEAK_WORDS: Record<string, string> = {
  "a lot": "many / considerably",
  "really": "notably / substantially",
  "very": "highly / exceptionally",
  "just": "",
  "things": "elements / factors",
  "stuff": "material / content",
  "good": "strong / effective",
  "bad": "ineffective / poor",
  "nice": "thoughtful / polished",
  "big": "substantial / significant",
  "small": "modest / limited",
  "get": "obtain / receive",
  "got": "received / obtained",
  "went": "traveled / proceeded",
  "said": "stated / noted",
  "amazing": "remarkable / impressive",
  "awesome": "outstanding",
  "basically": "",
  "literally": "",
  "actually": "",
  "sort of": "",
  "kind of": "",
  "in order to": "to",
  "due to the fact that": "because",
  "at this point in time": "now",
  "in the event that": "if",
  "for the purpose of": "to",
  "with regard to": "regarding",
  "in spite of the fact that": "although",
  "it is important to note that": "",
  "needless to say": "",
  "as a matter of fact": "in fact",
};

const PASSIVE_PATTERNS = [
  /\b(?:is|are|was|were|be|been|being)\s+(\w+ed)\b/gi,
  /\b(?:is|are|was|were|be|been|being)\s+(\w+en)\b/gi,
];

const FORMAL_REPLACEMENTS: Record<string, string> = {
  "kids": "children",
  "guys": "colleagues",
  "yeah": "yes",
  "ok": "acceptable",
  "okay": "acceptable",
  "gonna": "going to",
  "wanna": "want to",
  "gotta": "have to",
  "ASAP": "as soon as possible",
  "info": "information",
  "docs": "documents",
  "app": "application",
  "thanks": "thank you",
  "hey": "hello",
  "btw": "by the way",
  "fyi": "for your information",
};

const SIMPLE_REPLACEMENTS: Record<string, string> = {
  "utilize": "use",
  "facilitate": "help",
  "implement": "put in place",
  "leverage": "use",
  "optimize": "improve",
  "subsequently": "then",
  "consequently": "so",
  "nevertheless": "still",
  "commence": "start",
  "terminate": "end",
  "endeavor": "try",
  "ascertain": "find out",
  "procure": "get",
  "disseminate": "share",
  "approximately": "about",
  "sufficient": "enough",
  "demonstrate": "show",
  "indicate": "show",
  "require": "need",
  "additional": "more",
  "assistance": "help",
  "purchase": "buy",
  "individuals": "people",
  "regarding": "about",
  "concerning": "about",
};

const SYNONYMS: Record<string, string[]> = {
  improve: ["enhance", "strengthen", "elevate", "refine", "upgrade"],
  important: ["critical", "essential", "vital", "significant", "key"],
  show: ["demonstrate", "illustrate", "reveal", "highlight", "display"],
  help: ["support", "assist", "enable", "empower", "aid"],
  create: ["build", "design", "craft", "develop", "produce"],
  use: ["apply", "employ", "leverage", "adopt", "utilize"],
  change: ["transform", "shift", "adapt", "modify", "evolve"],
  think: ["believe", "consider", "reason", "reflect", "conclude"],
  make: ["produce", "generate", "form", "construct", "compose"],
  good: ["strong", "solid", "effective", "valuable", "excellent"],
  problem: ["challenge", "issue", "obstacle", "concern", "barrier"],
  idea: ["concept", "notion", "approach", "insight", "perspective"],
  people: ["individuals", "teams", "audiences", "stakeholders", "users"],
  work: ["function", "operate", "perform", "deliver", "execute"],
  write: ["compose", "draft", "author", "craft", "pen"],
  great: ["exceptional", "outstanding", "remarkable", "superb", "excellent"],
  new: ["fresh", "novel", "emerging", "modern", "innovative"],
  many: ["numerous", "countless", "multiple", "various", "several"],
  need: ["require", "demand", "call for", "necessitate"],
  want: ["seek", "aim for", "desire", "aspire to"],
};

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function countWords(text: string) {
  const t = text.trim();
  if (!t) return 0;
  return t.split(/\s+/).filter(Boolean).length;
}

function sentencesOf(text: string) {
  return text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

function paragraphsOf(text: string) {
  return text
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);
}

export function analyzeWriting(text: string): WritingInsights {
  const words = text.trim() ? text.trim().split(/\s+/).filter(Boolean) : [];
  const wordCount = words.length;
  const charCount = text.length;
  const sents = sentencesOf(text);
  const paras = paragraphsOf(text);
  const sentenceCount = sents.length || (wordCount ? 1 : 0);
  const paragraphCount = paras.length || (wordCount ? 1 : 0);
  const avgWordsPerSentence =
    sentenceCount > 0 ? Math.round((wordCount / sentenceCount) * 10) / 10 : 0;

  // Approximate syllable count
  let syllables = 0;
  for (const w of words) {
    const clean = w.toLowerCase().replace(/[^a-z]/g, "");
    if (!clean) continue;
    const groups = clean.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, "").match(/[aeiouy]{1,2}/g);
    syllables += groups ? groups.length : 1;
  }

  const flesch =
    wordCount === 0 || sentenceCount === 0
      ? 100
      : Math.max(
          0,
          Math.min(
            100,
            Math.round(
              206.835 -
                1.015 * (wordCount / sentenceCount) -
                84.6 * (syllables / Math.max(wordCount, 1))
            )
          )
        );

  let gradeLevel = "College";
  if (flesch >= 90) gradeLevel = "5th grade";
  else if (flesch >= 80) gradeLevel = "6th grade";
  else if (flesch >= 70) gradeLevel = "7th grade";
  else if (flesch >= 60) gradeLevel = "8th–9th grade";
  else if (flesch >= 50) gradeLevel = "10th–12th grade";
  else if (flesch >= 30) gradeLevel = "College";
  else gradeLevel = "Graduate";

  const lower = text.toLowerCase();
  const formalSignals = (
    lower.match(
      /\b(therefore|thus|moreover|furthermore|consequently|regarding|pursuant|hereby|aforementioned)\b/g
    ) || []
  ).length;
  const friendlySignals = (
    lower.match(/\b(thanks|please|happy|glad|love|excited|hey|wonderful|great)\b/g) || []
  ).length;
  const confidentSignals = (
    lower.match(/\b(will|must|proven|clearly|definitely|certainly|guarantee|ensure|always)\b/g) ||
    []
  ).length;
  const analyticalSignals = (
    lower.match(
      /\b(analyze|data|evidence|because|result|metric|compare|evaluate|hypothesis|trend)\b/g
    ) || []
  ).length;

  const toneBase = Math.max(wordCount / 40, 1);
  const tone = {
    formal: Math.min(100, Math.round((formalSignals / toneBase) * 55 + 25)),
    confident: Math.min(100, Math.round((confidentSignals / toneBase) * 55 + 30)),
    friendly: Math.min(100, Math.round((friendlySignals / toneBase) * 55 + 20)),
    analytical: Math.min(100, Math.round((analyticalSignals / toneBase) * 55 + 25)),
  };

  let passiveHits = 0;
  for (const re of PASSIVE_PATTERNS) {
    const m = text.match(re);
    if (m) passiveHits += m.length;
  }
  const passiveVoicePct =
    sentenceCount > 0 ? Math.min(100, Math.round((passiveHits / sentenceCount) * 100)) : 0;

  const freq = new Map<string, number>();
  const stop = new Set([
    "the",
    "a",
    "an",
    "and",
    "or",
    "but",
    "in",
    "on",
    "at",
    "to",
    "for",
    "of",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "have",
    "has",
    "had",
    "do",
    "does",
    "did",
    "will",
    "would",
    "could",
    "should",
    "may",
    "might",
    "must",
    "shall",
    "can",
    "this",
    "that",
    "these",
    "those",
    "i",
    "you",
    "he",
    "she",
    "it",
    "we",
    "they",
    "me",
    "him",
    "her",
    "us",
    "them",
    "my",
    "your",
    "his",
    "its",
    "our",
    "their",
    "with",
    "from",
    "by",
    "as",
    "into",
    "about",
    "than",
    "then",
    "so",
    "if",
    "not",
    "no",
    "yes",
    "all",
    "any",
    "more",
    "most",
    "other",
    "some",
    "such",
    "only",
    "own",
    "same",
    "too",
    "very",
    "just",
    "also",
    "how",
    "what",
    "when",
    "where",
    "who",
    "which",
    "why",
    "there",
    "here",
    "up",
    "out",
    "over",
    "after",
    "before",
    "between",
    "under",
    "again",
    "further",
    "once",
  ]);
  for (const w of words) {
    const clean = w.toLowerCase().replace(/[^a-z'-]/g, "");
    if (clean.length < 3 || stop.has(clean)) continue;
    freq.set(clean, (freq.get(clean) || 0) + 1);
  }
  const topWords = [...freq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([word, count]) => ({ word, count }));

  const uniqueWordPct =
    wordCount > 0 ? Math.round((freq.size / Math.max(wordCount, 1)) * 100) : 0;

  const posWords = (lower.match(/\b(great|excellent|success|love|happy|win|growth|improve|benefit|opportunity|strong|best)\b/g) || []).length;
  const negWords = (lower.match(/\b(fail|bad|poor|problem|risk|loss|hate|weak|worst|decline|issue|crisis)\b/g) || []).length;
  let sentiment: WritingInsights["sentiment"] = "neutral";
  if (posWords > negWords + 1) sentiment = "positive";
  else if (negWords > posWords + 1) sentiment = "negative";
  else if (posWords > 0 && negWords > 0) sentiment = "mixed";

  return {
    wordCount,
    charCount,
    sentenceCount,
    paragraphCount,
    avgWordsPerSentence,
    readingTimeMin: Math.max(1, Math.ceil(wordCount / 230)),
    speakingTimeMin: Math.max(1, Math.ceil(wordCount / 150)),
    fleschReadingEase: flesch,
    gradeLevel,
    tone,
    passiveVoicePct,
    uniqueWordPct,
    topWords,
    sentiment,
  };
}

export function runGrammarCheck(text: string): GrammarIssue[] {
  const issues: GrammarIssue[] = [];
  if (!text.trim()) return issues;

  // Spelling
  const wordRe = /\b[A-Za-z']+\b/g;
  let m: RegExpExecArray | null;
  while ((m = wordRe.exec(text)) !== null) {
    const raw = m[0];
    const lower = raw.toLowerCase();
    if (COMMON_MISSPELLINGS[lower]) {
      let suggestion = COMMON_MISSPELLINGS[lower];
      if (raw[0] === raw[0].toUpperCase()) {
        suggestion = suggestion.charAt(0).toUpperCase() + suggestion.slice(1);
      }
      issues.push({
        id: uid(),
        type: "spelling",
        original: raw,
        suggestion,
        explanation: `"${raw}" looks misspelled. Did you mean "${suggestion}"?`,
        severity: "error",
        start: m.index,
        end: m.index + raw.length,
      });
    }
  }

  // Double spaces
  const ds = / {2,}/g;
  while ((m = ds.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "punctuation",
      original: m[0],
      suggestion: " ",
      explanation: "Multiple consecutive spaces detected.",
      severity: "warning",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // Repeated words
  const rw = /\b(\w+)\s+\1\b/gi;
  while ((m = rw.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "repetition",
      original: m[0],
      suggestion: m[1],
      explanation: `Repeated word "${m[1]}".`,
      severity: "warning",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // its / it's heuristic
  const itsRe = /\bits\s+(a|an|the|my|your|his|her|our|their|not|going|been|time)\b/gi;
  while ((m = itsRe.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "grammar",
      original: m[0],
      suggestion: m[0].replace(/its/i, "it's"),
      explanation: 'Consider "it\'s" (it is / it has) instead of possessive "its".',
      severity: "suggestion",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // your / you're
  const yourRe = /\byour\s+(a|an|the|going|not|welcome|right|wrong)\b/gi;
  while ((m = yourRe.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "grammar",
      original: m[0],
      suggestion: m[0].replace(/your/i, "you're"),
      explanation: 'Consider "you\'re" (you are) instead of possessive "your".',
      severity: "suggestion",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // Subject-verb: "he don't" etc.
  const sv = /\b(he|she|it)\s+don't\b/gi;
  while ((m = sv.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "grammar",
      original: m[0],
      suggestion: m[0].replace(/don't/i, "doesn't"),
      explanation: 'Use "doesn\'t" with he/she/it.',
      severity: "error",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // there/their/they're common mix
  const thr = /\bthere\s+(is|are|was|were|will|can|could)\b/gi;
  // not always wrong — skip auto unless "there house" style
  const thr2 = /\bthere\s+(house|car|idea|team|project|document|work)\b/gi;
  while ((m = thr2.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "grammar",
      original: m[0],
      suggestion: m[0].replace(/there/i, "their"),
      explanation: 'Possessive "their" is likely intended here.',
      severity: "error",
      start: m.index,
      end: m.index + m[0].length,
    });
  }
  void thr;

  // Weak / wordy phrases
  for (const [phrase, alt] of Object.entries(WEAK_WORDS)) {
    const re = new RegExp(`\\b${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    while ((m = re.exec(text)) !== null) {
      issues.push({
        id: uid(),
        type: alt ? "style" : "conciseness",
        original: m[0],
        suggestion: alt || "(remove)",
        explanation: alt
          ? `"${phrase}" is weak or vague. Try: ${alt}.`
          : `"${phrase}" adds little value — consider removing it.`,
        severity: "suggestion",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // Passive voice
  for (const re of PASSIVE_PATTERNS) {
    re.lastIndex = 0;
    while ((m = re.exec(text)) !== null) {
      // skip very short contexts
      if (m[0].length < 8) continue;
      issues.push({
        id: uid(),
        type: "passive",
        original: m[0],
        suggestion: m[0],
        explanation:
          "Passive voice detected. Prefer active voice for clearer, more direct writing.",
        severity: "suggestion",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // Long sentences
  let offset = 0;
  for (const sent of sentencesOf(text)) {
    const idx = text.indexOf(sent, offset);
    if (idx === -1) continue;
    offset = idx + sent.length;
    const wc = countWords(sent);
    if (wc >= 35) {
      issues.push({
        id: uid(),
        type: "readability",
        original: sent.slice(0, 80) + (sent.length > 80 ? "…" : ""),
        suggestion: "Split into 2–3 shorter sentences.",
        explanation: `This sentence is long (${wc} words). Shorter sentences improve clarity and scan-ability.`,
        severity: "warning",
        start: idx,
        end: idx + sent.length,
      });
    }
  }

  // Missing space after punctuation
  const msp = /[.,:;!?][A-Za-z]/g;
  while ((m = msp.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "punctuation",
      original: m[0],
      suggestion: m[0][0] + " " + m[0][1],
      explanation: "Add a space after punctuation.",
      severity: "error",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // Sentence start capitalization
  const lines = text.split(/(?<=[.!?])\s+/);
  let pos = 0;
  for (const line of lines) {
    const idx = text.indexOf(line, pos);
    if (idx === -1) continue;
    pos = idx + line.length;
    const trimmed = line.trimStart();
    const lead = line.length - trimmed.length;
    if (trimmed && /^[a-z]/.test(trimmed)) {
      issues.push({
        id: uid(),
        type: "grammar",
        original: trimmed[0],
        suggestion: trimmed[0].toUpperCase(),
        explanation: "Sentences should start with a capital letter.",
        severity: "error",
        start: idx + lead,
        end: idx + lead + 1,
      });
    }
  }

  // Dedupe overlapping by start
  const seen = new Set<string>();
  return issues
    .filter((i) => {
      const key = `${i.start}-${i.end}-${i.type}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => a.start - b.start)
    .slice(0, 80);
}

function replaceAllWords(text: string, map: Record<string, string>) {
  let out = text;
  for (const [from, to] of Object.entries(map)) {
    const re = new RegExp(`\\b${from.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    out = out.replace(re, (match) => {
      if (!to) return "";
      if (match[0] === match[0].toUpperCase()) {
        return to.charAt(0).toUpperCase() + to.slice(1);
      }
      return to;
    });
  }
  return out.replace(/ {2,}/g, " ").replace(/ \./g, ".");
}

function synonymize(text: string, intensity = 0.45) {
  return text.replace(/\b[A-Za-z']+\b/g, (word) => {
    const lower = word.toLowerCase();
    const list = SYNONYMS[lower];
    if (!list || Math.random() > intensity) return word;
    const pick = list[Math.floor(Math.random() * list.length)];
    if (word[0] === word[0].toUpperCase()) {
      return pick.charAt(0).toUpperCase() + pick.slice(1);
    }
    return pick;
  });
}

function expandSentences(text: string) {
  const sents = sentencesOf(text);
  if (!sents.length) {
    return (
      text +
      " This idea deserves deeper context, concrete examples, and a clear next step so readers can act with confidence."
    );
  }
  return sents
    .map((s, i) => {
      const extras = [
        " This strengthens the overall argument with clearer context.",
        " In practice, teams that apply this see faster alignment and fewer revisions.",
        " The result is writing that feels intentional, credible, and easy to act on.",
        " Supporting detail here helps the reader connect insight to outcome.",
      ];
      if (s.length < 120) return s + extras[i % extras.length];
      return s;
    })
    .join(" ");
}

function shortenText(text: string) {
  let out = text;
  out = replaceAllWords(out, {
    "in order to": "to",
    "due to the fact that": "because",
    "at this point in time": "now",
    "in the event that": "if",
    "for the purpose of": "to",
    "with regard to": "about",
    "in spite of the fact that": "although",
    "it is important to note that": "",
    "needless to say": "",
    "as a matter of fact": "",
    "the fact that": "that",
    "a large number of": "many",
    "a majority of": "most",
    "in the near future": "soon",
    "at the present time": "now",
  });
  // Drop filler adjectives lightly
  out = out.replace(/\b(very|really|basically|actually|literally|quite|rather)\s+/gi, "");
  // Keep shorter sentences preferentially
  const sents = sentencesOf(out);
  if (sents.length > 3) {
    out = sents
      .filter((s) => countWords(s) <= 28 || sents.length <= 4)
      .slice(0, Math.max(2, Math.ceil(sents.length * 0.7)))
      .join(" ");
  }
  return out.trim();
}

function makeFormal(text: string) {
  let out = replaceAllWords(text, FORMAL_REPLACEMENTS);
  out = out.replace(/\bcan't\b/gi, "cannot");
  out = out.replace(/\bwon't\b/gi, "will not");
  out = out.replace(/\bdon't\b/gi, "do not");
  out = out.replace(/\bisn't\b/gi, "is not");
  out = out.replace(/\baren't\b/gi, "are not");
  out = out.replace(/\bI'm\b/g, "I am");
  out = out.replace(/\b!+/g, ".");
  return out;
}

function makeCasual(text: string) {
  let out = text;
  out = out.replace(/\bdo not\b/gi, "don't");
  out = out.replace(/\bcannot\b/gi, "can't");
  out = out.replace(/\bwill not\b/gi, "won't");
  out = out.replace(/\bI am\b/g, "I'm");
  out = out.replace(/\btherefore\b/gi, "so");
  out = out.replace(/\bfurthermore\b/gi, "also");
  out = out.replace(/\bhowever\b/gi, "but");
  return out;
}

function makeAcademic(text: string) {
  let out = makeFormal(text);
  out = replaceAllWords(out, {
    show: "demonstrate",
    use: "employ",
    help: "facilitate",
    get: "obtain",
    make: "construct",
    big: "substantial",
    start: "commence",
    end: "conclude",
    "look at": "examine",
    find: "identify",
  });
  if (!/this (paper|study|analysis)/i.test(out)) {
    out =
      "This analysis examines the following points with supporting reasoning. " + out;
  }
  return out;
}

function makePersuasive(text: string) {
  const lead =
    "Here's why this matters now: readers who act on clear, compelling writing move faster and decide with confidence. ";
  let out = synonymize(text, 0.35);
  out = out.replace(/\bI think\b/gi, "The evidence shows");
  out = out.replace(/\bmaybe\b/gi, "likely");
  out = out.replace(/\bmight\b/gi, "can");
  if (!out.toLowerCase().includes("you")) {
    out += " You can apply this immediately and measure the impact within days.";
  }
  return lead + out;
}

function makeConfident(text: string) {
  let out = text;
  out = out.replace(/\bI think\b/gi, "I know");
  out = out.replace(/\bmaybe\b/gi, "");
  out = out.replace(/\bperhaps\b/gi, "");
  out = out.replace(/\bmight\b/gi, "will");
  out = out.replace(/\bcould\b/gi, "can");
  out = out.replace(/\btry to\b/gi, "");
  out = out.replace(/\bseem to\b/gi, "");
  out = out.replace(/ {2,}/g, " ").trim();
  return out;
}

function makeEmpathetic(text: string) {
  return (
    "I hear the challenge in this, and your concerns are valid. " +
    text.replace(/\byou must\b/gi, "you may want to").replace(/\bdo this\b/gi, "consider this approach") +
    " Together, we can shape a path that feels practical and respectful of your goals."
  );
}

function makeSeo(text: string) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const topic = words.slice(0, 6).join(" ") || "this topic";
  return (
    `${topic}: a practical guide\n\n` +
    text +
    `\n\nKey takeaways on ${topic.toLowerCase()}: clarify the problem, outline the solution, and close with a clear call to action. ` +
    `Readers searching for ${topic.toLowerCase()} want actionable steps, credible examples, and scannable structure.`
  );
}

export function rewriteText(text: string, style: RewriteStyle): string {
  const base = text.trim();
  if (!base) return "";

  switch (style) {
    case "fluency":
      return synonymize(base.replace(/\s+/g, " ").trim(), 0.25);
    case "formal":
      return makeFormal(base);
    case "simple":
      return replaceAllWords(base, SIMPLE_REPLACEMENTS);
    case "creative":
      return synonymize(base, 0.7);
    case "expand":
      return expandSentences(base);
    case "shorten":
      return shortenText(base);
    case "academic":
      return makeAcademic(base);
    case "casual":
      return makeCasual(base);
    case "persuasive":
      return makePersuasive(base);
    case "confident":
      return makeConfident(base);
    case "empathetic":
      return makeEmpathetic(base);
    case "seo":
      return makeSeo(base);
    case "standard":
    default:
      return synonymize(shortenText(makeFormal(base)), 0.3);
  }
}

export function generateRewriteVariants(text: string, style: RewriteStyle): string[] {
  const primary = rewriteText(text, style);
  const second = rewriteText(synonymize(text, 0.5), style);
  const third = rewriteText(text, style === "shorten" ? "simple" : "fluency");
  const uniq = [primary, second, third].filter((v, i, a) => v && a.indexOf(v) === i);
  while (uniq.length < 3) {
    uniq.push(synonymize(primary || text, 0.55 + uniq.length * 0.1));
  }
  return uniq.slice(0, 3);
}

export function extractOutlineFromHtml(html: string): OutlineItem[] {
  const items: OutlineItem[] = [];
  const re = /<h([1-4])[^>]*>(.*?)<\/h\1>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) !== null) {
    const text = m[2].replace(/<[^>]+>/g, "").trim();
    if (!text) continue;
    items.push({ id: uid(), level: Number(m[1]), text });
  }
  return items;
}

export function extractOutlineFromText(text: string): OutlineItem[] {
  const lines = text.split("\n");
  const items: OutlineItem[] = [];
  for (const line of lines) {
    const t = line.trim();
    if (!t) continue;
    if (/^#{1,4}\s+/.test(t)) {
      const level = (t.match(/^#+/) || ["#"])[0].length;
      items.push({ id: uid(), level, text: t.replace(/^#+\s+/, "") });
    } else if (/^\d+\.\s+\S/.test(t)) {
      items.push({ id: uid(), level: 2, text: t });
    } else if (/^[-*]\s+\S/.test(t)) {
      items.push({ id: uid(), level: 3, text: t.replace(/^[-*]\s+/, "") });
    }
  }
  if (!items.length) {
    // Derive from first sentences of paragraphs
    paragraphsOf(text)
      .slice(0, 8)
      .forEach((p, i) => {
        const first = sentencesOf(p)[0] || p;
        items.push({
          id: uid(),
          level: i === 0 ? 1 : 2,
          text: first.slice(0, 90) + (first.length > 90 ? "…" : ""),
        });
      });
  }
  return items;
}

const MODE_PROMPTS: Record<
  AiMode,
  (input: string, context?: string) => string
> = {
  write: (input) => {
    const topic = input || "a clear, useful document";
    return [
      `<h1>${escapeHtml(topic.replace(/^write\s+(about\s+)?/i, "").slice(0, 80) || "New Document")}</h1>`,
      `<p>${escapeHtml(topic)} is more than a topic — it is an opportunity to create clarity for your reader. Strong documents open with context, deliver insight in a logical arc, and close with a decisive next step.</p>`,
      `<h2>Why this matters</h2>`,
      `<p>Audiences decide in seconds whether content is worth their attention. Lead with the outcome, support it with evidence, and remove anything that does not serve the reader.</p>`,
      `<h2>Core points</h2>`,
      `<ul><li><p>Define the problem in concrete terms.</p></li><li><p>Present a practical framework or narrative.</p></li><li><p>Show an example that makes the idea tangible.</p></li><li><p>End with actions the reader can take today.</p></li></ul>`,
      `<h2>Recommended approach</h2>`,
      `<p>Draft freely first, then refine for tone, structure, and precision. Use Aether's grammar and rewrite tools to polish every paragraph until it feels inevitable — clear, confident, and human.</p>`,
      `<p></p>`,
    ].join("");
  },
  continue: (input, context) => {
    const seed = (context || input || "").replace(/<[^>]+>/g, " ").trim();
    const tail = seed.split(/\s+/).slice(-40).join(" ");
    return `<p>Building on the ideas above${tail ? ` — especially around “${escapeHtml(tail.slice(0, 80))}”` : ""} — the next movement should deepen the argument without repeating it. Introduce a concrete example, quantify the impact where possible, and bridge to a practical recommendation the reader can apply immediately.</p><p>When the narrative is tight, finish the section with a short synthesis: what changed, why it matters, and what decision should follow.</p>`;
  },
  improve: (input) => {
    const plain = strip(input);
    const improved = rewriteText(plain || "Your draft", "fluency");
    return `<p>${escapeHtml(improved)}</p><p>Refined for clarity, stronger verbs, and tighter flow while preserving your original intent.</p>`;
  },
  summarize: (input) => {
    const plain = strip(input);
    const sents = sentencesOf(plain);
    const top = sents.slice(0, 3);
    const words = plain.split(/\s+/).filter(Boolean).slice(0, 12).join(" ");
    return [
      `<h2>Executive summary</h2>`,
      `<p>${escapeHtml(top.join(" ") || `Summary of: ${words}`)}</p>`,
      `<ul>`,
      ...sents.slice(0, 5).map((s) => `<li><p>${escapeHtml(s.slice(0, 140))}</p></li>`),
      `</ul>`,
      `<p><strong>Bottom line:</strong> Focus on the highest-leverage insight and the clearest next action.</p>`,
    ].join("");
  },
  expand: (input) => {
    const plain = strip(input);
    return `<p>${escapeHtml(expandSentences(plain || input))}</p><p>Additional context: successful documents pair claims with examples, acknowledge constraints, and guide the reader toward a specific outcome.</p>`;
  },
  shorten: (input) => {
    const plain = strip(input);
    return `<p>${escapeHtml(shortenText(plain || input))}</p>`;
  },
  outline: (input) => {
    const topic = strip(input) || "Document";
    return [
      `<h1>${escapeHtml(topic)}</h1>`,
      `<h2>1. Opening & context</h2><p>Frame the problem and stake of the reader.</p>`,
      `<h2>2. Key insights</h2><p>Present 3–5 evidence-backed points.</p>`,
      `<h2>3. Framework or process</h2><p>Give a repeatable method.</p>`,
      `<h2>4. Case example</h2><p>Show the idea in action.</p>`,
      `<h2>5. Recommendations</h2><p>List prioritized next steps.</p>`,
      `<h2>6. Closing</h2><p>Restate the outcome and call to action.</p>`,
    ].join("");
  },
  brainstorm: (input) => {
    const topic = strip(input) || "this topic";
    return [
      `<h2>Brainstorm: ${escapeHtml(topic)}</h2>`,
      `<ul>`,
      `<li><p>Contrarian angle — what if the common advice is incomplete?</p></li>`,
      `<li><p>Personal story that makes the stakes human.</p></li>`,
      `<li><p>Data-backed claim a skeptical reader would respect.</p></li>`,
      `<li><p>Step-by-step playbook a beginner could follow today.</p></li>`,
      `<li><p>Checklist or scorecard format for skimmability.</p></li>`,
      `<li><p>Before/after narrative showing transformation.</p></li>`,
      `<li><p>FAQ section that preempts objections.</p></li>`,
      `<li><p>Visual metaphor that makes the abstract memorable.</p></li>`,
      `</ul>`,
    ].join("");
  },
  translate: (input) => {
    // Lightweight "translation" demo: structured bilingual-style presentation
    const plain = strip(input) || "Hello";
    return `<h2>Translation draft</h2><p><strong>Source</strong></p><p>${escapeHtml(plain)}</p><p><strong>Target (clear international English)</strong></p><p>${escapeHtml(replaceAllWords(makeSimpleIntl(plain), SIMPLE_REPLACEMENTS))}</p><p><em>Tip: For production translation, connect a dedicated multilingual model in Settings.</em></p>`;
  },
  tone: (input) => {
    const plain = strip(input);
    return [
      `<h3>Tone variants</h3>`,
      `<p><strong>Formal:</strong> ${escapeHtml(rewriteText(plain, "formal"))}</p>`,
      `<p><strong>Friendly:</strong> ${escapeHtml(rewriteText(plain, "casual"))}</p>`,
      `<p><strong>Confident:</strong> ${escapeHtml(rewriteText(plain, "confident"))}</p>`,
      `<p><strong>Empathetic:</strong> ${escapeHtml(rewriteText(plain, "empathetic"))}</p>`,
    ].join("");
  },
  explain: (input) => {
    const plain = strip(input) || "this concept";
    return `<h2>Plain-language explanation</h2><p>${escapeHtml(replaceAllWords(plain, SIMPLE_REPLACEMENTS))}</p><p>In simpler terms: break the idea into the problem it solves, how it works in one sentence, and a tiny example someone could try in under five minutes.</p>`;
  },
  fix: (input) => {
    const plain = strip(input);
    const issues = runGrammarCheck(plain);
    let fixed = plain;
    // Apply spelling fixes from end to start
    const spelling = issues
      .filter((i) => i.type === "spelling" || i.type === "grammar" || i.type === "punctuation")
      .sort((a, b) => b.start - a.start);
    for (const issue of spelling) {
      if (issue.suggestion.startsWith("(")) continue;
      fixed =
        fixed.slice(0, issue.start) + issue.suggestion + fixed.slice(issue.end);
    }
    fixed = fixed.replace(/ {2,}/g, " ");
    return `<p>${escapeHtml(fixed)}</p>`;
  },
  "meeting-notes": (input) => {
    const topic = strip(input) || "Team sync";
    return [
      `<h1>Meeting notes — ${escapeHtml(topic)}</h1>`,
      `<p><strong>Date:</strong> ${new Date().toLocaleDateString()} &nbsp;|&nbsp; <strong>Attendees:</strong> </p>`,
      `<h2>Agenda</h2><ol><li><p>Updates</p></li><li><p>Decisions</p></li><li><p>Risks</p></li><li><p>Next steps</p></li></ol>`,
      `<h2>Discussion</h2><p></p>`,
      `<h2>Decisions</h2><ul><li><p></p></li></ul>`,
      `<h2>Action items</h2><ul data-type="taskList"><li data-type="taskItem" data-checked="false"><p>Owner — task — due date</p></li></ul>`,
    ].join("");
  },
  email: (input) => {
    const topic = strip(input) || "Quick update";
    return [
      `<p><strong>Subject:</strong> ${escapeHtml(topic)}</p>`,
      `<p>Hi {{Name}},</p>`,
      `<p>I wanted to share a concise update on ${escapeHtml(topic.toLowerCase())}. The goal is to keep you informed and make the next decision easy.</p>`,
      `<p><strong>Status:</strong> On track<br/><strong>Need from you:</strong> A quick review by EOD Thursday<br/><strong>Impact:</strong> Unblocks the next milestone</p>`,
      `<p>Happy to jump on a 10-minute call if useful.</p>`,
      `<p>Best regards,<br/>{{Your name}}</p>`,
    ].join("");
  },
  blog: (input) => {
    const topic = strip(input) || "Untitled insight";
    return [
      `<h1>${escapeHtml(topic)}</h1>`,
      `<p><em>A practical take for people who care about craft and outcomes.</em></p>`,
      `<h2>The hook</h2><p>Most advice on ${escapeHtml(topic.toLowerCase())} is either too vague or too complex. Here is a clearer path.</p>`,
      `<h2>The insight</h2><p>Focus on the smallest change that creates the largest reader impact. Clarity beats cleverness.</p>`,
      `<h2>How to apply it</h2><ol><li><p>Start with the reader outcome.</p></li><li><p>Cut anything that does not serve that outcome.</p></li><li><p>End with one memorable action.</p></li></ol>`,
      `<h2>Closing</h2><p>Great writing is a product decision. Ship the version that respects your reader's time.</p>`,
    ].join("");
  },
  proposal: (input) => {
    const topic = strip(input) || "Project proposal";
    return [
      `<h1>${escapeHtml(topic)}</h1>`,
      `<h2>Executive summary</h2><p>We propose a focused engagement to deliver measurable outcomes with transparent milestones and clear ownership.</p>`,
      `<h2>Problem</h2><p></p>`,
      `<h2>Proposed solution</h2><p></p>`,
      `<h2>Scope</h2><ul><li><p>Discovery & alignment</p></li><li><p>Build & iterate</p></li><li><p>Launch & measure</p></li></ul>`,
      `<h2>Timeline & investment</h2><p></p>`,
      `<h2>Success metrics</h2><p></p>`,
      `<h2>Next step</h2><p>Approve scope to begin kickoff within five business days.</p>`,
    ].join("");
  },
  resume: (input) => {
    const name = strip(input) || "Your Name";
    return [
      `<h1>${escapeHtml(name)}</h1>`,
      `<p>Email · Phone · City · Portfolio</p>`,
      `<h2>Professional summary</h2><p>Results-driven professional who turns ambiguous problems into shipped outcomes. Known for clear communication, systems thinking, and high-quality execution.</p>`,
      `<h2>Experience</h2><h3>Role · Company</h3><p><em>Dates</em></p><ul><li><p>Impact bullet with metric</p></li><li><p>Impact bullet with metric</p></li></ul>`,
      `<h2>Skills</h2><p>Strategy · Writing · Analysis · Collaboration · Tools</p>`,
      `<h2>Education</h2><p>Degree · Institution · Year</p>`,
    ].join("");
  },
  research: (input) => {
    const topic = strip(input) || "Research topic";
    return [
      `<h1>Research brief: ${escapeHtml(topic)}</h1>`,
      `<h2>Question</h2><p>What are the most credible insights and open questions around ${escapeHtml(topic)}?</p>`,
      `<h2>Key findings</h2><ul><li><p>Finding one with implication</p></li><li><p>Finding two with implication</p></li><li><p>Finding three with implication</p></li></ul>`,
      `<h2>Evidence map</h2><p>Source quality, recency, and bias notes go here.</p>`,
      `<h2>Counterpoints</h2><p></p>`,
      `<h2>Implications for action</h2><p></p>`,
      `<h2>Open questions</h2><ul><li><p></p></li></ul>`,
    ].join("");
  },
};

function makeSimpleIntl(text: string) {
  return replaceAllWords(text, SIMPLE_REPLACEMENTS);
}

function strip(htmlOrText: string) {
  return htmlOrText.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function runAiGenerate(params: {
  mode: AiMode;
  prompt: string;
  selection?: string;
  documentText?: string;
}): { html: string; plain: string; title?: string } {
  const { mode, prompt, selection, documentText } = params;
  const input = selection?.trim() || prompt.trim() || documentText?.slice(0, 2000) || "";
  const fn = MODE_PROMPTS[mode] || MODE_PROMPTS.write;
  const html = fn(input, documentText);
  const plain = strip(html);
  let title: string | undefined;
  const h1 = html.match(/<h1[^>]*>(.*?)<\/h1>/i);
  if (h1) title = h1[1].replace(/<[^>]+>/g, "").trim();
  return { html, plain, title };
}

export function htmlToPlain(html: string) {
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/h[1-6]>/gi, "\n\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function plainToHtml(text: string) {
  if (!text.trim()) return "<p></p>";
  if (/<[a-z][\s\S]*>/i.test(text)) return text;
  return text
    .split(/\n{2,}/)
    .map((p) => `<p>${escapeHtml(p).replace(/\n/g, "<br>")}</p>`)
    .join("");
}

export function applyIssueToText(text: string, issue: GrammarIssue) {
  if (issue.suggestion.startsWith("(")) {
    return text.slice(0, issue.start) + text.slice(issue.end);
  }
  return text.slice(0, issue.start) + issue.suggestion + text.slice(issue.end);
}
