import "server-only";

import { createHash } from "node:crypto";
import type { GrammarIssue, GrammarIssueType, RewriteStyle, AiMode } from "./types";

export type CloudProvider = "openai" | "anthropic" | "gemini";

export interface ProviderStatus {
  onlineGrammar: {
    available: boolean;
    name: string;
    automatic: boolean;
    authenticated: boolean;
  };
  freeApis: {
    available: boolean;
    lexical: "Datamuse";
    research: "Wikipedia";
  };
  cloudAi: {
    available: boolean;
    provider: CloudProvider | null;
    model: string | null;
  };
}

const DEFAULT_LT_URL = "https://api.languagetool.org/v2/check";
const LT_TIMEOUT_MS = 12_000;
const LLM_TIMEOUT_MS = 45_000;
const MAX_LT_CHARS = 19_000; // public endpoint documents a 20KB request limit

type CacheEntry<T> = { expiresAt: number; value: T };
const globalOnline = globalThis as typeof globalThis & {
  __aetherOnlineCache?: Map<string, CacheEntry<unknown>>;
  __aetherLtLastCall?: number;
};
const cache =
  globalOnline.__aetherOnlineCache ?? new Map<string, CacheEntry<unknown>>();
globalOnline.__aetherOnlineCache = cache;

function env(name: string): string | undefined {
  const value = process.env[name]?.trim();
  return value || undefined;
}

function selectedProvider(): CloudProvider | null {
  const preferred = env("AETHER_AI_PROVIDER")?.toLowerCase();
  if (preferred === "openai" && env("OPENAI_API_KEY")) return "openai";
  if (preferred === "anthropic" && env("ANTHROPIC_API_KEY")) return "anthropic";
  if (preferred === "gemini" && (env("GEMINI_API_KEY") || env("GOOGLE_API_KEY"))) {
    return "gemini";
  }
  if (env("OPENAI_API_KEY")) return "openai";
  if (env("ANTHROPIC_API_KEY")) return "anthropic";
  if (env("GEMINI_API_KEY") || env("GOOGLE_API_KEY")) return "gemini";
  return null;
}

function providerModel(provider: CloudProvider): string {
  if (provider === "openai") return env("OPENAI_MODEL") || "gpt-4.1-mini";
  if (provider === "anthropic") {
    return env("ANTHROPIC_MODEL") || "claude-3-5-haiku-latest";
  }
  return env("GEMINI_MODEL") || "gemini-2.5-flash";
}

export function getProviderStatus(): ProviderStatus {
  const provider = selectedProvider();
  const ltUrl = env("LANGUAGETOOL_API_URL") || DEFAULT_LT_URL;
  const authenticated = Boolean(
    env("LANGUAGETOOL_USERNAME") && env("LANGUAGETOOL_API_KEY")
  );
  const automatic =
    env("LANGUAGETOOL_AUTOMATIC") === "1" ||
    authenticated ||
    !ltUrl.includes("api.languagetool.org");

  return {
    onlineGrammar: {
      available: env("AETHER_ONLINE_GRAMMAR") !== "0",
      name: "LanguageTool",
      automatic,
      authenticated,
    },
    freeApis: {
      available: env("AETHER_FREE_APIS") !== "0",
      lexical: "Datamuse",
      research: "Wikipedia",
    },
    cloudAi: {
      available: provider !== null,
      provider,
      model: provider ? providerModel(provider) : null,
    },
  };
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
      cache: "no-store",
    });
  } finally {
    clearTimeout(timer);
  }
}

function hash(input: string): string {
  return createHash("sha256").update(input).digest("hex").slice(0, 24);
}

function categoryToType(
  categoryId: string,
  issueType: string | undefined
): GrammarIssueType {
  const id = categoryId.toUpperCase();
  const issue = (issueType || "").toLowerCase();
  if (id.includes("TYPOS") || id.includes("SPELL") || issue === "misspelling") {
    return "spelling";
  }
  if (id.includes("PUNCTUATION") || issue === "typographical") {
    return "punctuation";
  }
  if (id.includes("STYLE")) return "style";
  if (id.includes("REDUNDANCY")) return "conciseness";
  if (id.includes("CASING")) return "grammar";
  if (issue === "style") return "style";
  if (issue === "duplication") return "repetition";
  if (issue === "grammar") return "grammar";
  return "clarity";
}

function categoryToSeverity(
  categoryId: string,
  issueType: string | undefined
): GrammarIssue["severity"] {
  const id = categoryId.toUpperCase();
  const issue = (issueType || "").toLowerCase();
  if (
    id.includes("TYPOS") ||
    id.includes("SPELL") ||
    id.includes("GRAMMAR") ||
    issue === "misspelling" ||
    issue === "grammar"
  ) {
    return "error";
  }
  if (id.includes("PUNCTUATION") || issue === "typographical") {
    return "warning";
  }
  return "suggestion";
}

interface LanguageToolResponse {
  matches?: Array<{
    message?: string;
    shortMessage?: string;
    offset?: number;
    length?: number;
    replacements?: Array<{ value?: string }>;
    rule?: {
      id?: string;
      description?: string;
      issueType?: string;
      category?: { id?: string; name?: string };
    };
  }>;
}

export interface OnlineGrammarResult {
  issues: GrammarIssue[];
  provider: "LanguageTool";
  online: boolean;
  truncated: boolean;
  cached: boolean;
  error?: string;
}

/**
 * User-triggered online grammar check.
 *
 * The free public LanguageTool endpoint explicitly disallows automated use,
 * so callers should set `explicitUserAction=true`. Automatic checking is only
 * permitted for authenticated or self-hosted LanguageTool installations.
 */
export async function checkOnlineGrammar(
  text: string,
  options: {
    language?: string;
    explicitUserAction?: boolean;
  } = {}
): Promise<OnlineGrammarResult> {
  const status = getProviderStatus();
  if (!status.onlineGrammar.available) {
    return {
      issues: [],
      provider: "LanguageTool",
      online: false,
      truncated: false,
      cached: false,
      error: "Online grammar is disabled.",
    };
  }

  if (!options.explicitUserAction && !status.onlineGrammar.automatic) {
    return {
      issues: [],
      provider: "LanguageTool",
      online: false,
      truncated: false,
      cached: false,
      error: "Click Check online to use LanguageTool cloud.",
    };
  }

  const truncated = text.length > MAX_LT_CHARS;
  const checkedText = text.slice(0, MAX_LT_CHARS);
  const language = options.language || env("AETHER_LANGUAGE") || "en-US";
  const cacheKey = `lt:${hash(language + "\u0000" + checkedText)}`;
  const existing = cache.get(cacheKey) as CacheEntry<OnlineGrammarResult> | undefined;
  if (existing && existing.expiresAt > Date.now()) {
    return { ...existing.value, cached: true };
  }

  // A small server-level guard protects paid/self-hosted endpoints from bursts.
  const now = Date.now();
  const elapsed = now - (globalOnline.__aetherLtLastCall || 0);
  if (!options.explicitUserAction && elapsed < 2_500) {
    return {
      issues: [],
      provider: "LanguageTool",
      online: false,
      truncated,
      cached: false,
      error: "Online check throttled; local proofing is still active.",
    };
  }
  globalOnline.__aetherLtLastCall = now;

  const form = new URLSearchParams({
    text: checkedText,
    language,
    level: "picky",
  });
  const username = env("LANGUAGETOOL_USERNAME");
  const apiKey = env("LANGUAGETOOL_API_KEY");
  if (username && apiKey) {
    form.set("username", username);
    form.set("apiKey", apiKey);
  }

  const url = env("LANGUAGETOOL_API_URL") || DEFAULT_LT_URL;
  try {
    const response = await fetchWithTimeout(
      url,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "Aether-Document-OS/1.0",
        },
        body: form,
      },
      LT_TIMEOUT_MS
    );

    if (!response.ok) {
      const detail = (await response.text()).slice(0, 240);
      throw new Error(`LanguageTool ${response.status}: ${detail}`);
    }

    const data = (await response.json()) as LanguageToolResponse;
    const issues: GrammarIssue[] = [];
    for (const [index, match] of (data.matches || []).entries()) {
      const start = Number(match.offset || 0);
      const length = Number(match.length || 0);
      if (length <= 0 || start < 0 || start + length > checkedText.length) {
        continue;
      }
      const original = checkedText.slice(start, start + length);
      const categoryId = match.rule?.category?.id || "STYLE";
      const firstReplacement = match.replacements?.find((r) => r.value)?.value;
      const suggestion = firstReplacement || original;
      const ruleId = match.rule?.id || `rule-${index}`;
      issues.push({
        id: `lt-${ruleId}-${start}-${length}`,
        type: categoryToType(categoryId, match.rule?.issueType),
        original,
        suggestion,
        explanation:
          match.message || match.shortMessage || match.rule?.description || "Online writing suggestion.",
        severity: categoryToSeverity(categoryId, match.rule?.issueType),
        start,
        end: start + length,
      });
    }

    const result: OnlineGrammarResult = {
      issues,
      provider: "LanguageTool",
      online: true,
      truncated,
      cached: false,
    };
    cache.set(cacheKey, { expiresAt: Date.now() + 5 * 60_000, value: result });
    return result;
  } catch (error) {
    return {
      issues: [],
      provider: "LanguageTool",
      online: false,
      truncated,
      cached: false,
      error:
        error instanceof Error && error.name === "AbortError"
          ? "LanguageTool timed out; local proofing is still active."
          : error instanceof Error
            ? error.message
            : "LanguageTool is unavailable.",
    };
  }
}

export function mergeGrammarIssues(
  local: GrammarIssue[],
  online: GrammarIssue[]
): GrammarIssue[] {
  const combined: GrammarIssue[] = [];
  const overlaps = (a: GrammarIssue, b: GrammarIssue) =>
    Math.max(a.start, b.start) < Math.min(a.end, b.end) ||
    (a.start === b.start && a.end === b.end);

  // Prefer LanguageTool when it identifies the same span.
  for (const issue of online) combined.push(issue);
  for (const issue of local) {
    const duplicate = combined.some(
      (existing) =>
        overlaps(existing, issue) &&
        (existing.original.toLowerCase() === issue.original.toLowerCase() ||
          existing.type === issue.type)
    );
    if (!duplicate) combined.push(issue);
  }

  return combined
    .sort((a, b) => a.start - b.start || a.end - b.end)
    .slice(0, 120);
}

/* ------------------------------------------------------------------ */
/* Free no-key APIs: Datamuse + Wikipedia                              */
/* ------------------------------------------------------------------ */

const DATAMUSE_TIMEOUT_MS = 8_000;
const WIKIPEDIA_TIMEOUT_MS = 10_000;

const LEXICAL_TARGETS = new Set([
  "good",
  "bad",
  "great",
  "important",
  "help",
  "helps",
  "use",
  "uses",
  "show",
  "shows",
  "improve",
  "improves",
  "problem",
  "problems",
  "big",
  "small",
  "many",
  "clear",
  "nice",
]);

// Curated safe replacements. Datamuse is great for candidate discovery, but
// raw top synonyms can be awkward in prose (e.g. “citizenry” for “people”),
// so we only use web suggestions if they pass this conservative safe list.
const SAFE_SYNONYMS: Record<string, string[]> = {
  good: ["strong", "useful", "solid", "effective", "valuable"],
  bad: ["weak", "poor", "harmful", "ineffective"],
  great: ["excellent", "strong", "notable"],
  important: ["essential", "key", "significant", "critical"],
  help: ["support", "assist", "guide", "enable"],
  helps: ["supports", "assists", "guides", "enables"],
  use: ["apply", "use"],
  uses: ["applies", "uses"],
  show: ["demonstrate", "show", "highlight"],
  shows: ["demonstrates", "shows", "highlights"],
  improve: ["strengthen", "improve", "refine"],
  improves: ["strengthens", "improves", "refines"],
  problem: ["challenge", "issue", "problem"],
  problems: ["challenges", "issues", "problems"],
  big: ["major", "large", "significant"],
  small: ["minor", "small", "limited"],
  many: ["many", "several", "various"],
  clear: ["clear", "precise", "direct"],
  nice: ["polished", "useful", "thoughtful"],
};

const DIRECT_SIMPLE: Record<string, string> = {
  utilize: "use",
  facilitate: "help",
  leverage: "use",
  commence: "start",
  terminate: "end",
  approximately: "about",
  sufficient: "enough",
  individuals: "people",
  regarding: "about",
  consequently: "so",
  subsequently: "then",
};

interface DatamuseWord {
  word?: string;
  score?: number;
  tags?: string[];
}

function lexicalStyleWord(original: string, candidate: string): string {
  if (!candidate || /\s/.test(candidate)) return original;
  if (original.endsWith("s") && !candidate.endsWith("s")) {
    candidate += "s";
  }
  if (original[0] === original[0].toUpperCase()) {
    candidate = candidate.charAt(0).toUpperCase() + candidate.slice(1);
  }
  return candidate;
}

async function datamuseSynonym(word: string): Promise<string | null> {
  const clean = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!clean || clean.length < 4) return null;
  const cacheKey = `dm:${clean}`;
  const cached = cache.get(cacheKey) as CacheEntry<string | null> | undefined;
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  try {
    const url = `https://api.datamuse.com/words?ml=${encodeURIComponent(clean)}&max=12`;
    const res = await fetchWithTimeout(url, { method: "GET" }, DATAMUSE_TIMEOUT_MS);
    if (!res.ok) throw new Error(`Datamuse ${res.status}`);
    const data = (await res.json()) as DatamuseWord[];
    const safe = new Set(SAFE_SYNONYMS[clean] || []);
    const pick = data
      .map((x) => x.word || "")
      .filter(
        (w) =>
          w &&
          /^[a-z]+$/i.test(w) &&
          w.length >= 4 &&
          w.toLowerCase() !== clean &&
          safe.has(w.toLowerCase())
      )[0];
    const value = pick || safe.values().next().value || null;
    cache.set(cacheKey, { expiresAt: Date.now() + 24 * 60 * 60_000, value });
    return value;
  } catch {
    cache.set(cacheKey, { expiresAt: Date.now() + 10 * 60_000, value: null });
    return null;
  }
}

export async function rewriteWithFreeLexical(
  text: string,
  style: RewriteStyle
): Promise<CloudTextResult> {
  const status = getProviderStatus();
  if (!status.freeApis.available) {
    return { text: "", online: false, provider: null, model: null, error: "Free APIs disabled." };
  }

  let output = text;
  let changed = false;

  // High-quality phrase improvements first — these are safer than blind
  // word-level synonyms and avoid the "synonym salad" problem.
  const phrasePairs: Array<[RegExp, string]> = [
    [/\bhelp many people improve their work\b/gi, "help a wider audience strengthen their work"],
    [/\bgood idea\b/gi, "strong idea"],
    [/\bvery good\b/gi, "strong"],
    [/\bhelp many people\b/gi, "support a wider audience"],
    [/\bimprove their work\b/gi, "strengthen their work"],
    [/\bmake it better\b/gi, "improve it"],
    [/\ba lot of\b/gi, "many"],
  ];
  for (const [re, replacement] of phrasePairs) {
    output = output.replace(re, (m) => {
      changed = true;
      return /^[A-Z]/.test(m)
        ? replacement.charAt(0).toUpperCase() + replacement.slice(1)
        : replacement;
    });
  }

  // Direct simplification/clarity replacements never need a network call.
  for (const [from, to] of Object.entries(DIRECT_SIMPLE)) {
    const re = new RegExp(`\\b${from}\\b`, "gi");
    output = output.replace(re, (m) => {
      changed = true;
      return m[0] === m[0].toUpperCase() ? to.charAt(0).toUpperCase() + to.slice(1) : to;
    });
  }

  // Use Datamuse to improve a few generic words. Keep this conservative so it
  // never becomes synonym-salad.
  const words = [...new Set(output.match(/\b[A-Za-z]{4,}\b/g) || [])]
    .filter((w) => LEXICAL_TARGETS.has(w.toLowerCase()))
    .slice(0, style === "creative" ? 8 : 5);

  for (const word of words) {
    const syn = await datamuseSynonym(word);
    if (!syn) continue;
    const replacement = lexicalStyleWord(word, syn);
    if (!replacement || replacement.toLowerCase() === word.toLowerCase()) continue;
    const re = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i");
    output = output.replace(re, replacement);
    changed = true;
  }

  if (!changed || output.trim() === text.trim()) {
    return {
      text: "",
      online: false,
      provider: "Datamuse",
      model: "free-lexical-api",
      error: "No useful lexical improvements found.",
    };
  }

  return {
    text: output,
    online: true,
    provider: "Datamuse",
    model: "free-lexical-api",
  };
}

interface WikiOpenSearch extends Array<unknown> {
  1?: string[];
}
interface WikiSummary {
  title?: string;
  extract?: string;
  description?: string;
  content_urls?: { desktop?: { page?: string } };
}

export async function getFreeResearchContext(query: string): Promise<CloudTextResult> {
  const status = getProviderStatus();
  if (!status.freeApis.available) {
    return { text: "", online: false, provider: null, model: null, error: "Free APIs disabled." };
  }
  const q = query.trim().slice(0, 120);
  if (!q) {
    return { text: "", online: false, provider: "Wikipedia", model: "opensearch+summary", error: "No research query." };
  }
  const cacheKey = `wiki:${hash(q.toLowerCase())}`;
  const cached = cache.get(cacheKey) as CacheEntry<CloudTextResult> | undefined;
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=opensearch&namespace=0&limit=3&format=json&search=${encodeURIComponent(q)}`;
    const searchRes = await fetchWithTimeout(searchUrl, { method: "GET" }, WIKIPEDIA_TIMEOUT_MS);
    if (!searchRes.ok) throw new Error(`Wikipedia search ${searchRes.status}`);
    const search = (await searchRes.json()) as WikiOpenSearch;
    const title = search[1]?.[0];
    if (!title) throw new Error("No Wikipedia topic found.");

    const summaryUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
    const summaryRes = await fetchWithTimeout(summaryUrl, { method: "GET" }, WIKIPEDIA_TIMEOUT_MS);
    if (!summaryRes.ok) throw new Error(`Wikipedia summary ${summaryRes.status}`);
    const summary = (await summaryRes.json()) as WikiSummary;
    const text = [
      `Free web context from Wikipedia: ${summary.title || title}`,
      summary.description ? `Description: ${summary.description}` : "",
      summary.extract ? `Summary: ${summary.extract}` : "",
      summary.content_urls?.desktop?.page ? `Source: ${summary.content_urls.desktop.page}` : "",
    ]
      .filter(Boolean)
      .join("\n");

    const result: CloudTextResult = {
      text,
      online: true,
      provider: "Wikipedia",
      model: "opensearch+summary",
    };
    cache.set(cacheKey, { expiresAt: Date.now() + 12 * 60 * 60_000, value: result });
    return result;
  } catch (error) {
    return {
      text: "",
      online: false,
      provider: "Wikipedia",
      model: "opensearch+summary",
      error: error instanceof Error ? error.message : "Wikipedia lookup failed.",
    };
  }
}

function cloudInstructions(task: "rewrite" | "generate"): string {
  if (task === "rewrite") {
    return [
      "You are Aether Rewrite, a precise professional editor.",
      "Preserve every fact, name, number, citation, and intended meaning.",
      "Do not invent information. Do not add generic AI filler.",
      "Avoid phrases such as delve into, tapestry, pivotal, crucial role, in today's world, furthermore, and moreover unless essential.",
      "Return only the requested final text. No preamble, labels, markdown fences, or explanation.",
    ].join(" ");
  }
  return [
    "You are Aether Copilot, an expert human-sounding document author.",
    "Write specific, natural prose with varied sentence rhythm and concrete detail.",
    "Avoid generic AI filler and repetitive transitions.",
    "When HTML is requested, return only clean semantic HTML using h1-h3, p, ul, ol, li, strong, em, blockquote, and hr.",
    "Never include scripts, styles, iframe, or markdown fences.",
  ].join(" ");
}

async function callOpenAI(
  model: string,
  system: string,
  prompt: string
): Promise<string> {
  const response = await fetchWithTimeout(
    "https://api.openai.com/v1/responses",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env("OPENAI_API_KEY")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        instructions: system,
        input: prompt,
        store: false,
      }),
    },
    LLM_TIMEOUT_MS
  );
  const data = (await response.json()) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(
      `OpenAI ${response.status}: ${JSON.stringify(data).slice(0, 300)}`
    );
  }
  if (typeof data.output_text === "string" && data.output_text.trim()) {
    return data.output_text.trim();
  }
  const output = Array.isArray(data.output) ? data.output : [];
  const parts: string[] = [];
  for (const item of output as Array<Record<string, unknown>>) {
    const content = Array.isArray(item.content) ? item.content : [];
    for (const block of content as Array<Record<string, unknown>>) {
      if (typeof block.text === "string") parts.push(block.text);
    }
  }
  if (!parts.length) throw new Error("OpenAI returned no text.");
  return parts.join("\n").trim();
}

async function callAnthropic(
  model: string,
  system: string,
  prompt: string
): Promise<string> {
  const response = await fetchWithTimeout(
    "https://api.anthropic.com/v1/messages",
    {
      method: "POST",
      headers: {
        "x-api-key": env("ANTHROPIC_API_KEY") || "",
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        max_tokens: 4096,
        temperature: 0.55,
        system,
        messages: [{ role: "user", content: prompt }],
      }),
    },
    LLM_TIMEOUT_MS
  );
  const data = (await response.json()) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(
      `Anthropic ${response.status}: ${JSON.stringify(data).slice(0, 300)}`
    );
  }
  const content = Array.isArray(data.content) ? data.content : [];
  const text = (content as Array<Record<string, unknown>>)
    .filter((block) => block.type === "text" && typeof block.text === "string")
    .map((block) => block.text as string)
    .join("\n")
    .trim();
  if (!text) throw new Error("Anthropic returned no text.");
  return text;
}

async function callGemini(
  model: string,
  system: string,
  prompt: string
): Promise<string> {
  const key = env("GEMINI_API_KEY") || env("GOOGLE_API_KEY") || "";
  const response = await fetchWithTimeout(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: "POST",
      headers: {
        "x-goog-api-key": key,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.55,
          maxOutputTokens: 4096,
        },
      }),
    },
    LLM_TIMEOUT_MS
  );
  const data = (await response.json()) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(
      `Gemini ${response.status}: ${JSON.stringify(data).slice(0, 300)}`
    );
  }
  const candidates = Array.isArray(data.candidates) ? data.candidates : [];
  const first = candidates[0] as Record<string, unknown> | undefined;
  const content = first?.content as Record<string, unknown> | undefined;
  const parts = Array.isArray(content?.parts) ? content.parts : [];
  const text = (parts as Array<Record<string, unknown>>)
    .map((part) => (typeof part.text === "string" ? part.text : ""))
    .filter(Boolean)
    .join("\n")
    .trim();
  if (!text) throw new Error("Gemini returned no text.");
  return text;
}

export interface CloudTextResult {
  text: string;
  online: boolean;
  provider: CloudProvider | "Datamuse" | "Wikipedia" | "AetherFree" | null;
  model: string | null;
  error?: string;
}

export async function generateCloudText(
  task: "rewrite" | "generate",
  prompt: string
): Promise<CloudTextResult> {
  const provider = selectedProvider();
  if (!provider) {
    return {
      text: "",
      online: false,
      provider: null,
      model: null,
      error: "No cloud AI provider is configured.",
    };
  }
  const model = providerModel(provider);
  const system = cloudInstructions(task);
  try {
    let text = "";
    if (provider === "openai") text = await callOpenAI(model, system, prompt);
    else if (provider === "anthropic") {
      text = await callAnthropic(model, system, prompt);
    } else text = await callGemini(model, system, prompt);
    return { text, online: true, provider, model };
  } catch (error) {
    return {
      text: "",
      online: false,
      provider,
      model,
      error: error instanceof Error ? error.message : "Cloud AI request failed.",
    };
  }
}

const STYLE_GUIDANCE: Record<RewriteStyle, string> = {
  standard: "Improve clarity, flow, grammar, and precision while preserving tone.",
  fluency: "Make the language fluid, idiomatic, and natural without changing meaning.",
  formal: "Use polished, professional language and a measured formal tone.",
  simple: "Use plain language, short sentences, and accessible vocabulary.",
  creative: "Use vivid, original language and varied rhythm without inventing facts.",
  expand: "Expand with useful clarification and examples grounded only in the supplied text.",
  shorten: "Cut repetition and filler; keep every essential fact and conclusion.",
  academic: "Use precise academic prose, disciplined claims, and logical transitions.",
  casual: "Use warm, conversational language and natural contractions.",
  persuasive: "Strengthen the argument, benefits, and call to action without exaggeration.",
  confident: "Remove hedging and use direct, decisive phrasing without overclaiming.",
  empathetic: "Use considerate, emotionally intelligent, respectful language.",
  seo: "Improve scannability and natural keyword relevance without keyword stuffing.",
};

export async function checkCloudGrammar(text: string): Promise<CloudTextResult> {
  const prompt = [
    "You are a professional grammar and clarity editor. Correct every spelling, grammar, punctuation, style, and clarity issue. Return ONLY valid JSON in this exact format, with no markdown fences or extra text:",
    '{"issues":[{"original":"the error","suggestion":"the fix","type":"spelling|grammar|punctuation|style|clarity|conciseness|passive|readability|repetition","severity":"error|warning|suggestion","explanation":"Why"}]}',
    "TEXT:",
    text,
  ].join("\n\n");
  const result = await generateCloudText("generate", prompt);
  if (!result.online || !result.text.trim()) return result;

  try {
    let cleaned = result.text.trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "");
    const parsed = JSON.parse(cleaned);
    if (Array.isArray(parsed.issues)) {
      return { ...result, text: JSON.stringify(parsed.issues) };
    }
  } catch {
    // If the LLM returns non-JSON, treat as raw text rewrite fallback.
  }
  return result;
}

export async function rewriteWithCloud(
  text: string,
  style: RewriteStyle
): Promise<CloudTextResult> {
  const prompt = [
    `Rewrite the text in ${style} mode.`,
    STYLE_GUIDANCE[style],
    "Return one final version only.",
    "TEXT:",
    text,
  ].join("\n\n");
  return generateCloudText("rewrite", prompt);
}

const MODE_GUIDANCE: Record<AiMode, string> = {
  write: "Write a complete, useful document from the request.",
  continue: "Continue naturally from the supplied document context without repeating it.",
  improve: "Improve clarity, structure, grammar, specificity, and flow.",
  summarize: "Create a concise executive summary and key takeaways.",
  expand: "Expand the supplied material with useful detail grounded in the context.",
  shorten: "Condense aggressively while retaining every important fact.",
  outline: "Create a clear hierarchical outline with useful headings.",
  brainstorm: "Generate varied, specific ideas organized for quick evaluation.",
  translate: "Translate into the requested language, preserving meaning and register.",
  tone: "Rewrite in the requested tone while preserving content.",
  explain: "Explain in plain language with a concrete example.",
  fix: "Correct grammar, spelling, punctuation, and awkward phrasing.",
  "meeting-notes": "Create structured meeting notes with decisions and action items.",
  email: "Write a concise professional email with a clear subject, request, and close.",
  blog: "Write a compelling, human-sounding blog post with useful headings.",
  proposal: "Write an executive-ready proposal with problem, solution, scope, metrics, and next steps.",
  resume: "Write concise, achievement-led resume content with measurable impact where supplied.",
  research: "Create a careful research brief; label uncertainty and never invent sources.",
};

export async function generateWithCloud(params: {
  mode: AiMode;
  prompt: string;
  selection?: string;
  documentText?: string;
}): Promise<CloudTextResult> {
  const { mode, prompt, selection, documentText } = params;
  const request = [
    MODE_GUIDANCE[mode],
    "Return clean semantic HTML only.",
    prompt ? `REQUEST:\n${prompt}` : "",
    selection ? `SELECTED TEXT:\n${selection}` : "",
    documentText ? `DOCUMENT CONTEXT:\n${documentText.slice(0, 16_000)}` : "",
  ]
    .filter(Boolean)
    .join("\n\n");
  return generateCloudText("generate", request);
}
