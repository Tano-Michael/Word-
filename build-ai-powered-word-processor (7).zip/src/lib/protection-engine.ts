import { Shield, AlertTriangle, CheckCircle, Sparkles, FileText, Lock, Eye } from "lucide-react";

export interface ProtectionResult {
  score: number; // 0 = very AI-like, 100 = very human-like
  grade: "Strong human" | "Mostly human" | "Mixed" | "Likely AI-influenced" | "Very AI-like";
  patterns: PatternInfo[];
  suggestions: string[];
  vocabularyScore: number; // 0-100
  burstiness: number; // sentence length variance 0-100
  repetitionScore: number; // 0-100 (low repetition = high score)
}

export interface PatternInfo {
  type: "low_perplexity" | "high_repetition" | "uniform_length" | "common_ai_phrase" | "low_variance" | "predictable_structure";
  message: string;
  severity: "low" | "medium" | "high";
  count: number;
  originalPhrase?: string;
  suggestedPhrase?: string;
}

export const AI_PHRASE_HUMANIZERS: Record<string, string> = {
  "it's important to note that": "simply note that",
  "It's important to note that": "Simply note that",
  "as mentioned earlier": "as we saw",
  "As mentioned earlier": "As we saw",
  "in today's world": "nowadays",
  "In today's world": "Nowadays",
  "delves into": "looks closely at",
  "delve into": "look at",
  "Delve into": "Look at",
  "in conclusion": "finally",
  "In conclusion": "Finally",
  "furthermore": "also",
  "Furthermore": "Also",
  "moreover": "what's more",
  "Moreover": "What's more",
  "it's worth noting": "note",
  "It's worth noting": "Note",
  "as previously stated": "as discussed",
  "As previously stated": "As discussed",
  "in the realm of": "in",
  "In the realm of": "In",
  "it's essential to understand": "we need to know",
  "It's essential to understand": "We need to know",
  "with that being said": "still",
  "With that being said": "Still",
  "this underscores the importance": "this shows why it matters",
  "This underscores the importance": "This shows why it matters",
  "at the end of the day": "ultimately",
  "At the end of the day": "Ultimately",
  "going forward": "next",
  "Going forward": "Next",
};

export function analyzeProtection(text: string): ProtectionResult {
  const cleanText = text.trim();
  if (!cleanText || cleanText.length < 20) {
    return {
      score: 0,
      grade: "Mixed",
      patterns: [],
      suggestions: [
        "Add at least 3-4 full sentences (about 40+ words) before the analysis can be trusted.",
      ],
      vocabularyScore: 0,
      burstiness: 0,
      repetitionScore: 0,
    };
  }

  const sentenceList = cleanText
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const words = cleanText
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2);

  // Sentence length measured in WORDS (more meaningful than characters).
  const sentenceWordCounts = sentenceList.map(
    (s) => s.split(/\s+/).filter(Boolean).length
  );
  const wordFreq = new Map<string, number>();
  for (const w of words) wordFreq.set(w, (wordFreq.get(w) || 0) + 1);

  const uniqueWords = wordFreq.size;

  // Type-token ratio. Human writing at typical lengths lands ~0.45-0.7.
  // AI text is often lower (more repetition of key terms). Calibrated so a
  // genuinely repetitive passage scores low instead of defaulting high.
  const ttr = uniqueWords / Math.max(1, words.length);
  const vocabScore = Math.max(
    0,
    Math.min(100, Math.round((ttr - 0.25) * 200))
  );

  // Burstiness = coefficient of variation of sentence length in words.
  // Humans vary a lot (high CV). AI tends toward uniform medium-length
  // sentences (low CV). This is the single strongest tell, so it is weighted.
  const meanWords =
    sentenceWordCounts.reduce((a, b) => a + b, 0) /
    Math.max(1, sentenceWordCounts.length);
  const wordVariance =
    sentenceWordCounts.reduce((acc, n) => acc + Math.pow(n - meanWords, 2), 0) /
    Math.max(1, sentenceWordCounts.length);
  const cv = Math.sqrt(wordVariance) / Math.max(1, meanWords);
  const burstScore = Math.max(0, Math.min(100, Math.round(cv * 180)));

  // Repetition penalty scales with how many content words repeat heavily.
  const repeatedWords = [...wordFreq.entries()].filter(([, c]) => c >= 3);
  const repetitionScore = Math.max(
    0,
    Math.round(100 - (repeatedWords.length / Math.max(6, uniqueWords)) * 220)
  );

  let phraseMatches = 0;
  const patterns: PatternInfo[] = [];

  for (const [aiPhrase, humanAlternative] of Object.entries(AI_PHRASE_HUMANIZERS)) {
    const regex = new RegExp(`\\b${aiPhrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "g");
    const occurrences = (cleanText.match(regex) || []).length;
    if (occurrences > 0) {
      phraseMatches += occurrences;
      patterns.push({
        type: "common_ai_phrase",
        message: `Overly generic AI phrase pattern "${aiPhrase}" detected.`,
        severity: "medium",
        count: occurrences,
        originalPhrase: aiPhrase,
        suggestedPhrase: humanAlternative,
      });
    }
  }

  const paragraphs = cleanText.split(/\n\n+/).filter((p) => p.trim().length > 5);
  const paragraphLengths = paragraphs.map((p) => p.length);
  const paraMean = paragraphLengths.reduce((a, b) => a + b, 0) / Math.max(1, paragraphLengths.length);
  const paraVar = paragraphLengths.reduce((acc, l) => acc + Math.pow(l - paraMean, 2), 0) / Math.max(1, paragraphLengths.length);
  const paraScore = Math.min(100, Math.round(Math.sqrt(paraVar) / Math.max(10, paraMean) * 250));

  // Each detected AI phrase is a strong signal. Penalize heavily and per-hit.
  const phrasePenalty = Math.min(45, phraseMatches * 15);

  // Uniform sentence length is the classic AI signature.
  if (burstScore < 30) {
    patterns.push({
      type: "uniform_length",
      message:
        "Sentence lengths are very uniform — a common machine-writing signature. Mix short and long sentences.",
      severity: burstScore < 18 ? "high" : "medium",
      count: 1,
    });
  }

  if (repetitionScore < 55) {
    patterns.push({
      type: "high_repetition",
      message:
        "Key words repeat often. Vary vocabulary; human writing reuses fewer exact terms.",
      severity: repetitionScore < 35 ? "high" : "medium",
      count: repeatedWords.length,
    });
  }

  if (vocabScore < 45) {
    patterns.push({
      type: "low_variance",
      message:
        "Low vocabulary diversity relative to length. Introduce more varied, specific word choices.",
      severity: vocabScore < 25 ? "high" : "medium",
      count: 1,
    });
  }

  // Honest weighted score. Burstiness weighted highest (best real signal),
  // then vocabulary, then repetition, minus a direct AI-phrase penalty.
  // No artificial floor: genuinely AI-like text will score low.
  const finalScore = Math.max(
    0,
    Math.min(
      100,
      Math.round(
        burstScore * 0.4 +
          vocabScore * 0.32 +
          repetitionScore * 0.28 -
          phrasePenalty
      )
    )
  );

  const grades: ProtectionResult["grade"][] = [
    "Very AI-like",
    "Likely AI-influenced",
    "Mixed",
    "Mostly human",
    "Strong human",
  ];

  const gradeIndex = Math.min(4, Math.max(0, Math.floor(finalScore / 20)));
  const correctedGrade = grades[gradeIndex];

  const suggestions: string[] = [];
  if (phraseMatches > 0) {
    suggestions.push(
      `Remove ${phraseMatches} generic AI phrase${phraseMatches === 1 ? "" : "s"} (e.g. "furthermore", "delve into", "it's important to note").`
    );
  }
  if (burstScore < 30) {
    suggestions.push(
      "Vary sentence length — combine short punchy sentences with longer descriptive ones."
    );
  }
  if (repetitionScore < 55) {
    suggestions.push(
      "Reduce repeated key terms; use synonyms or restructure sentences."
    );
  }
  if (vocabScore < 45) {
    suggestions.push(
      "Add specific, concrete vocabulary and personal detail to raise diversity."
    );
  }
  if (finalScore >= 70 && suggestions.length === 0) {
    suggestions.push(
      "Strong human characteristics: varied rhythm, diverse vocabulary, low predictability."
    );
  } else if (suggestions.length === 0) {
    suggestions.push(
      "Reasonable variety, but add specific detail and vary sentence rhythm to strengthen it."
    );
  }

  return {
    score: finalScore,
    grade: correctedGrade,
    patterns,
    suggestions,
    vocabularyScore: vocabScore,
    burstiness: burstScore,
    repetitionScore,
  };
}
export { Shield, AlertTriangle, CheckCircle, Sparkles, FileText, Lock, Eye };
