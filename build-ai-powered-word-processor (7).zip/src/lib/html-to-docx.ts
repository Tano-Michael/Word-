import {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType,
  ExternalHyperlink,
} from "docx";
import { parse, type HTMLElement as ParsedElement, type Node } from "node-html-parser";

type InlineStyle = {
  bold?: boolean;
  italics?: boolean;
  underline?: boolean;
  strike?: boolean;
  code?: boolean;
  color?: string;
  highlight?: boolean;
  superScript?: boolean;
  subScript?: boolean;
  link?: string;
};

const HEADING_MAP: Record<string, (typeof HeadingLevel)[keyof typeof HeadingLevel]> = {
  h1: HeadingLevel.HEADING_1,
  h2: HeadingLevel.HEADING_2,
  h3: HeadingLevel.HEADING_3,
  h4: HeadingLevel.HEADING_4,
  h5: HeadingLevel.HEADING_5,
  h6: HeadingLevel.HEADING_6,
};

const ALIGN_MAP: Record<string, (typeof AlignmentType)[keyof typeof AlignmentType]> = {
  left: AlignmentType.LEFT,
  center: AlignmentType.CENTER,
  right: AlignmentType.RIGHT,
  justify: AlignmentType.JUSTIFIED,
};

function isElement(node: Node): node is ParsedElement {
  return node.nodeType === 1;
}

function decode(text: string) {
  return text
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function styleFromTag(tag: string, el: ParsedElement, base: InlineStyle): InlineStyle {
  const next: InlineStyle = { ...base };
  switch (tag) {
    case "strong":
    case "b":
      next.bold = true;
      break;
    case "em":
    case "i":
      next.italics = true;
      break;
    case "u":
      next.underline = true;
      break;
    case "s":
    case "strike":
    case "del":
      next.strike = true;
      break;
    case "code":
      next.code = true;
      break;
    case "mark":
      next.highlight = true;
      break;
    case "sup":
      next.superScript = true;
      break;
    case "sub":
      next.subScript = true;
      break;
    case "a":
      next.link = el.getAttribute("href") || undefined;
      break;
  }

  const style = el.getAttribute("style") || "";
  const colorMatch = style.match(/(?:^|;)\s*color\s*:\s*([^;]+)/i);
  if (colorMatch) {
    const c = colorMatch[1].trim();
    const hex = c.startsWith("#")
      ? c.slice(1)
      : c.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/i)
        ? [1, 2, 3]
            .map((i) =>
              Number(c.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/i)![i])
                .toString(16)
                .padStart(2, "0")
            )
            .join("")
        : null;
    if (hex && /^[0-9a-f]{6}$/i.test(hex)) next.color = hex.toUpperCase();
  }
  if (/background-color/i.test(style)) next.highlight = true;
  return next;
}

function makeRuns(nodes: Node[], base: InlineStyle): (TextRun | ExternalHyperlink | ImageRun)[] {
  const runs: (TextRun | ExternalHyperlink | ImageRun)[] = [];

  for (const node of nodes) {
    if (!isElement(node)) {
      const text = decode(node.rawText || "");
      if (!text) continue;
      if (!text.trim() && !runs.length) continue;
      runs.push(buildTextRun(text, base));
      continue;
    }

    const tag = node.tagName?.toLowerCase() || "";

    if (tag === "br") {
      runs.push(new TextRun({ break: 1 }));
      continue;
    }

    if (tag === "img") {
      const image = buildImageRun(node);
      if (image) runs.push(image);
      continue;
    }

    const nextStyle = styleFromTag(tag, node, base);
    const childRuns = makeRuns(node.childNodes, nextStyle);

    if (tag === "a" && nextStyle.link) {
      runs.push(
        new ExternalHyperlink({
          link: nextStyle.link,
          children: childRuns.filter(
            (r): r is TextRun => r instanceof TextRun
          ),
        })
      );
      continue;
    }
    runs.push(...childRuns);
  }

  return runs;
}

function buildTextRun(text: string, style: InlineStyle) {
  return new TextRun({
    text,
    bold: style.bold,
    italics: style.italics,
    underline: style.underline ? {} : undefined,
    strike: style.strike,
    color: style.link ? "1F5EDB" : style.color,
    highlight: style.highlight ? "yellow" : undefined,
    superScript: style.superScript,
    subScript: style.subScript,
    font: style.code ? "Consolas" : undefined,
    size: style.code ? 20 : undefined,
  });
}

function buildImageRun(el: ParsedElement): ImageRun | null {
  const src = el.getAttribute("src") || "";
  const match = src.match(/^data:image\/(png|jpe?g|gif|bmp);base64,(.+)$/i);
  if (!match) return null;
  try {
    const data = Buffer.from(match[2], "base64");
    const ext = match[1].toLowerCase();
    const type = ext === "jpeg" ? "jpg" : ext;
    return new ImageRun({
      data,
      transformation: { width: 480, height: 320 },
      type: type as "png" | "jpg" | "gif" | "bmp",
    });
  } catch {
    return null;
  }
}

function alignmentOf(el: ParsedElement) {
  const style = el.getAttribute("style") || "";
  const m = style.match(/text-align\s*:\s*(left|center|right|justify)/i);
  if (m) return ALIGN_MAP[m[1].toLowerCase()];
  const attr = el.getAttribute("data-text-align");
  if (attr && ALIGN_MAP[attr]) return ALIGN_MAP[attr];
  return undefined;
}

/** Convert an em hanging indent into DOCX twips (1 em ≈ 240 twips at 12pt). */
function hangingIndentOf(el: ParsedElement) {
  const raw = el.getAttribute("data-hanging-indent");
  if (!raw) return undefined;
  const em = parseFloat(raw);
  if (!em || em <= 0) return undefined;
  const twips = Math.round(em * 240);
  return { left: twips, hanging: twips };
}

function blockToParagraphs(
  el: ParsedElement,
  ctx: { listLevel: number; ordered: boolean }
): (Paragraph | Table)[] {
  const tag = el.tagName?.toLowerCase() || "";
  const out: (Paragraph | Table)[] = [];

  if (HEADING_MAP[tag]) {
    out.push(
      new Paragraph({
        heading: HEADING_MAP[tag],
        alignment: alignmentOf(el),
        spacing: { before: 240, after: 120 },
        children: makeRuns(el.childNodes, {}),
      })
    );
    return out;
  }

  switch (tag) {
    case "p": {
      out.push(
        new Paragraph({
          alignment: alignmentOf(el),
          spacing: { after: 160, line: 300 },
          indent: hangingIndentOf(el),
          children: makeRuns(el.childNodes, {}),
        })
      );
      return out;
    }
    case "blockquote": {
      for (const child of el.childNodes) {
        if (isElement(child)) {
          out.push(
            new Paragraph({
              indent: { left: 480 },
              spacing: { after: 140 },
              border: {
                left: { style: BorderStyle.SINGLE, size: 12, color: "9CA3AF", space: 12 },
              },
              children: makeRuns(child.childNodes, { italics: true }),
            })
          );
        }
      }
      if (!out.length) {
        out.push(
          new Paragraph({
            indent: { left: 480 },
            children: makeRuns(el.childNodes, { italics: true }),
          })
        );
      }
      return out;
    }
    case "pre": {
      const text = decode(el.text || "");
      for (const line of text.split("\n")) {
        out.push(
          new Paragraph({
            spacing: { after: 0 },
            shading: { fill: "F1F5F9" },
            children: [
              new TextRun({ text: line || " ", font: "Consolas", size: 20 }),
            ],
          })
        );
      }
      return out;
    }
    case "hr": {
      out.push(
        new Paragraph({
          spacing: { before: 200, after: 200 },
          border: {
            bottom: { style: BorderStyle.SINGLE, size: 6, color: "CBD5E1", space: 1 },
          },
          children: [],
        })
      );
      return out;
    }
    case "ul":
    case "ol": {
      const ordered = tag === "ol";
      for (const li of el.childNodes.filter(isElement)) {
        if (li.tagName?.toLowerCase() !== "li") continue;
        const nestedLists = li
          .childNodes.filter(isElement)
          .filter((c) => ["ul", "ol"].includes(c.tagName?.toLowerCase() || ""));
        const inlineNodes = li.childNodes.filter(
          (c) =>
            !isElement(c) ||
            !["ul", "ol"].includes(c.tagName?.toLowerCase() || "")
        );

        const checkbox = li.getAttribute("data-checked");
        const isTask = checkbox === "true" || checkbox === "false";
        const prefix = checkbox === "true" ? "☑ " : checkbox === "false" ? "☐ " : "";

        const runs = makeRuns(inlineNodes, {});
        out.push(
          new Paragraph({
            spacing: { after: 80 },
            ...(isTask
              ? { indent: { left: 360 + ctx.listLevel * 360 } }
              : ordered
                ? { numbering: { reference: "aether-ordered", level: ctx.listLevel } }
                : { bullet: { level: ctx.listLevel } }),
            children: prefix
              ? [new TextRun({ text: prefix }), ...(runs as TextRun[])]
              : runs,
          })
        );

        for (const nested of nestedLists) {
          out.push(
            ...blockToParagraphs(nested, {
              listLevel: Math.min(ctx.listLevel + 1, 4),
              ordered: nested.tagName?.toLowerCase() === "ol",
            })
          );
        }
      }
      return out;
    }
    case "table": {
      const rows: TableRow[] = [];
      const trs = el.querySelectorAll("tr");
      for (const tr of trs) {
        const cells = tr
          .childNodes.filter(isElement)
          .filter((c) => ["td", "th"].includes(c.tagName?.toLowerCase() || ""));
        if (!cells.length) continue;
        rows.push(
          new TableRow({
            children: cells.map((cell) => {
              const isHeader = cell.tagName?.toLowerCase() === "th";
              const inner = cell.childNodes.filter(isElement);
              const paragraphs =
                inner.length > 0
                  ? inner.flatMap((c) =>
                      blockToParagraphs(c, { listLevel: 0, ordered: false })
                    )
                  : [
                      new Paragraph({
                        children: makeRuns(cell.childNodes, {
                          bold: isHeader,
                        }),
                      }),
                    ];
              return new TableCell({
                shading: isHeader ? { fill: "F1F5F9" } : undefined,
                children: paragraphs.filter(
                  (p): p is Paragraph => p instanceof Paragraph
                ),
              });
            }),
          })
        );
      }
      if (rows.length) {
        out.push(
          new Table({
            rows,
            width: { size: 100, type: WidthType.PERCENTAGE },
          })
        );
        out.push(new Paragraph({ text: "", spacing: { after: 120 } }));
      }
      return out;
    }
    case "img": {
      const image = buildImageRun(el);
      if (image) out.push(new Paragraph({ children: [image] }));
      return out;
    }
    case "div":
    case "section":
    case "article":
    case "body": {
      for (const child of el.childNodes) {
        if (isElement(child)) out.push(...blockToParagraphs(child, ctx));
        else if (child.rawText?.trim()) {
          out.push(new Paragraph({ children: makeRuns([child], {}) }));
        }
      }
      return out;
    }
    default: {
      const runs = makeRuns([el], {});
      if (runs.length) out.push(new Paragraph({ children: runs }));
      return out;
    }
  }
}

export async function htmlToDocxBuffer(
  html: string,
  title: string
): Promise<Buffer> {
  const root = parse(html || "<p></p>", {
    lowerCaseTagName: true,
    comment: false,
  });

  const blocks: (Paragraph | Table)[] = [];
  for (const node of root.childNodes) {
    if (isElement(node)) {
      blocks.push(...blockToParagraphs(node, { listLevel: 0, ordered: false }));
    } else if (node.rawText?.trim()) {
      blocks.push(
        new Paragraph({ children: makeRuns([node], {}) })
      );
    }
  }

  if (!blocks.length) blocks.push(new Paragraph({ text: "" }));

  const doc = new Document({
    title,
    creator: "Aether Document OS",
    description: "Exported from Aether",
    numbering: {
      config: [
        {
          reference: "aether-ordered",
          levels: [0, 1, 2, 3, 4].map((level) => ({
            level,
            format: "decimal" as const,
            text: `%${level + 1}.`,
            alignment: AlignmentType.START,
            style: {
              paragraph: { indent: { left: 720 + level * 360, hanging: 360 } },
            },
          })),
        },
      ],
    },
    styles: {
      default: {
        document: {
          run: { font: "Calibri", size: 22 },
          paragraph: { spacing: { line: 300 } },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
          },
        },
        children: blocks,
      },
    ],
  });

  return Packer.toBuffer(doc);
}
