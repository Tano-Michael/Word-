/* eslint-disable @typescript-eslint/no-explicit-any */
export function plainOffsetToPos(doc: any, plainOffset: number): number | null {
  let cursor = 0;
  let blockSeen = 0;
  let result: number | null = null;

  doc.descendants((node: any, pos: number) => {
    if (result !== null) return false;
    if (node.isText && node.text) {
      const end = cursor + node.text.length;
      if (plainOffset >= cursor && plainOffset <= end) {
        result = pos + plainOffset - cursor;
        return false;
      }
      cursor = end;
      return false;
    }
    if (node.isTextblock) {
      if (blockSeen > 0) cursor += 1;
      blockSeen += 1;
    }
    return true;
  });

  return result;
}
