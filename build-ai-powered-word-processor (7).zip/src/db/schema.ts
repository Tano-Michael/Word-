import {
  pgTable,
  text,
  timestamp,
  uuid,
  integer,
  jsonb,
  boolean,
  varchar,
} from "drizzle-orm/pg-core";

export const documents = pgTable("documents", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 500 }).notNull().default("Untitled Document"),
  content: text("content").notNull().default(""),
  contentJson: jsonb("content_json"),
  plainText: text("plain_text").notNull().default(""),
  wordCount: integer("word_count").notNull().default(0),
  charCount: integer("char_count").notNull().default(0),
  status: varchar("status", { length: 50 }).notNull().default("draft"),
  folder: varchar("folder", { length: 200 }).default("My Documents"),
  tags: jsonb("tags").$type<string[]>().default([]),
  coverColor: varchar("cover_color", { length: 30 }).default("#2563eb"),
  aiSummary: text("ai_summary"),
  readingLevel: varchar("reading_level", { length: 50 }),
  toneScore: jsonb("tone_score").$type<Record<string, number>>(),
  isStarred: boolean("is_starred").notNull().default(false),
  isTemplate: boolean("is_template").notNull().default(false),
  templateCategory: varchar("template_category", { length: 100 }),
  lastOpenedAt: timestamp("last_opened_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const documentVersions = pgTable("document_versions", {
  id: uuid("id").defaultRandom().primaryKey(),
  documentId: uuid("document_id")
    .notNull()
    .references(() => documents.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(),
  contentJson: jsonb("content_json"),
  plainText: text("plain_text").notNull().default(""),
  label: varchar("label", { length: 200 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const comments = pgTable("comments", {
  id: uuid("id").defaultRandom().primaryKey(),
  documentId: uuid("document_id")
    .notNull()
    .references(() => documents.id, { onDelete: "cascade" }),
  anchorText: text("anchor_text"),
  body: text("body").notNull(),
  author: varchar("author", { length: 120 }).notNull().default("You"),
  resolved: boolean("resolved").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiSuggestions = pgTable("ai_suggestions", {
  id: uuid("id").defaultRandom().primaryKey(),
  documentId: uuid("document_id")
    .notNull()
    .references(() => documents.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 50 }).notNull(),
  originalText: text("original_text").notNull(),
  suggestedText: text("suggested_text").notNull(),
  explanation: text("explanation"),
  severity: varchar("severity", { length: 20 }).default("info"),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  startOffset: integer("start_offset"),
  endOffset: integer("end_offset"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const writingGoals = pgTable("writing_goals", {
  id: uuid("id").defaultRandom().primaryKey(),
  documentId: uuid("document_id")
    .notNull()
    .references(() => documents.id, { onDelete: "cascade" }),
  goalType: varchar("goal_type", { length: 50 }).notNull(),
  targetValue: integer("target_value").notNull(),
  currentValue: integer("current_value").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type NewDocument = typeof documents.$inferInsert;
export type DocumentVersion = typeof documentVersions.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type AiSuggestion = typeof aiSuggestions.$inferSelect;
