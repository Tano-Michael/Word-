/**
 * Schema bootstrap for the embedded (PGlite) database.
 *
 * When Aether runs in zero-setup mode there is no `drizzle-kit push` step,
 * so the tables are created here on first launch. This mirrors
 * `src/db/schema.ts` exactly and is safe to run repeatedly.
 */
export const BOOTSTRAP_SQL = `
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title varchar(500) NOT NULL DEFAULT 'Untitled Document',
  content text NOT NULL DEFAULT '',
  content_json jsonb,
  plain_text text NOT NULL DEFAULT '',
  word_count integer NOT NULL DEFAULT 0,
  char_count integer NOT NULL DEFAULT 0,
  status varchar(50) NOT NULL DEFAULT 'draft',
  folder varchar(200) DEFAULT 'My Documents',
  tags jsonb DEFAULT '[]'::jsonb,
  cover_color varchar(30) DEFAULT '#2563eb',
  ai_summary text,
  reading_level varchar(50),
  tone_score jsonb,
  is_starred boolean NOT NULL DEFAULT false,
  is_template boolean NOT NULL DEFAULT false,
  template_category varchar(100),
  last_opened_at timestamp DEFAULT now(),
  created_at timestamp NOT NULL DEFAULT now(),
  updated_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS document_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  title varchar(500) NOT NULL,
  content text NOT NULL,
  content_json jsonb,
  plain_text text NOT NULL DEFAULT '',
  label varchar(200),
  created_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  anchor_text text,
  body text NOT NULL,
  author varchar(120) NOT NULL DEFAULT 'You',
  resolved boolean NOT NULL DEFAULT false,
  created_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  type varchar(50) NOT NULL,
  original_text text NOT NULL,
  suggested_text text NOT NULL,
  explanation text,
  severity varchar(20) DEFAULT 'info',
  status varchar(20) NOT NULL DEFAULT 'pending',
  start_offset integer,
  end_offset integer,
  created_at timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS writing_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  goal_type varchar(50) NOT NULL,
  target_value integer NOT NULL,
  current_value integer NOT NULL DEFAULT 0,
  completed boolean NOT NULL DEFAULT false,
  created_at timestamp NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS documents_updated_at_idx ON documents (updated_at DESC);
CREATE INDEX IF NOT EXISTS document_versions_doc_idx ON document_versions (document_id);
CREATE INDEX IF NOT EXISTS comments_doc_idx ON comments (document_id);
`;
