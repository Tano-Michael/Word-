"use client";

import { useEffect, useState } from "react";
import { Download, X, Monitor } from "lucide-react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export function InstallPrompt() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Register service worker
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }

    // Already running as installed app?
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setInstalled(true);
    }

    if (sessionStorage.getItem("aether-install-dismissed") === "1") {
      setDismissed(true);
    }

    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
    };

    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (installed || dismissed || !deferred) return null;

  return (
    <div className="fixed bottom-5 left-1/2 z-50 w-[min(92vw,26rem)] -translate-x-1/2 rounded-2xl border border-white/15 bg-slate-900/95 p-4 shadow-2xl shadow-black/40 backdrop-blur-xl">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-lg font-black text-white">
          Æ
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-white">Install Aether on your PC</p>
          <p className="mt-0.5 text-xs leading-relaxed text-slate-400">
            Runs in its own window, works offline, and opens .docx files like a
            native desktop app.
          </p>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={async () => {
                await deferred.prompt();
                const choice = await deferred.userChoice;
                if (choice.outcome === "accepted") setInstalled(true);
                setDeferred(null);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-slate-900 hover:bg-indigo-50"
            >
              <Download className="h-3.5 w-3.5" />
              Install app
            </button>
            <button
              type="button"
              onClick={() => {
                setDismissed(true);
                sessionStorage.setItem("aether-install-dismissed", "1");
              }}
              className="rounded-lg px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-white"
            >
              Not now
            </button>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            setDismissed(true);
            sessionStorage.setItem("aether-install-dismissed", "1");
          }}
          className="rounded p-1 text-slate-500 hover:text-white"
          aria-label="Dismiss"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function InstalledBadge() {
  const [installed, setInstalled] = useState(false);
  useEffect(() => {
    setInstalled(window.matchMedia("(display-mode: standalone)").matches);
  }, []);
  if (!installed) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-medium text-emerald-300">
      <Monitor className="h-3 w-3" />
      Desktop app
    </span>
  );
}
