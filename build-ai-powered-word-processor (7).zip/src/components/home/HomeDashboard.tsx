"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Plus,
  Upload,
  Download,
  Search,
  Star,
  FileText,
  Sparkles,
  Trash2,
  Clock,
  LayoutTemplate,
  Wand2,
  ArrowRight,
  Filter,
  BookOpen,
  PenLine,
  Brain,
  Languages,
  FileOutput,
  ShieldCheck,
  X,
} from "lucide-react";
import { BUILT_IN_TEMPLATES } from "@/lib/templates";
import type { DocumentListItem } from "@/lib/types";
import { cn, formatRelativeDate } from "@/lib/utils";

const FEATURES = [
  {
    icon: Brain,
    title: "Intent-aware Copilot",
    desc: "Drafts, continues, and restructures with document-level memory — not a bolted-on chat pane.",
  },
  {
    icon: ShieldCheck,
    title: "Grammarly-class clarity",
    desc: "Spelling, grammar, passive voice, tone, and concision scored live as you type.",
  },
  {
    icon: Languages,
    title: "Rewrite Studio",
    desc: "13 QuillBot-style modes: formal, SEO, empathetic, academic, shorten, expand, and more.",
  },
  {
    icon: FileOutput,
    title: "True DOCX in & out",
    desc: "Open real Word .docx and PDF files with styles, lists and tables intact — export back to genuine OOXML.",
  },
  {
    icon: BookOpen,
    title: "Living outline + research",
    desc: "Headings stay navigable; research desk builds structured briefs you can drop in-place.",
  },
  {
    icon: PenLine,
    title: "Writing intelligence",
    desc: "Flesch score, tone spectrum, reading time, and actionable recommendations on every doc.",
  },
];

export function HomeDashboard() {
  const router = useRouter();
  const [docs, setDocs] = useState<DocumentListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "starred" | "recent">("all");
  const [creating, setCreating] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [selectedFeature, setSelectedFeature] = useState<(typeof FEATURES)[number] | null>(null);
  const uploadRef = useRef<HTMLInputElement>(null);

  async function openFile(file: File) {
    setUploading(true);
    setUploadError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("createDocument", "1");
      const res = await fetch("/api/import", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) {
        setUploadError(data.error || "Could not open this file.");
        return;
      }
      if (data.document?.id) router.push(`/doc/${data.document.id}`);
    } catch {
      setUploadError("Upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  }

  const load = async (query?: string) => {
    setLoading(true);
    setLoadError(null);
    try {
      const params = new URLSearchParams();
      if (query) params.set("q", query);
      if (filter === "starred") params.set("starred", "1");
      const res = await fetch(`/api/documents?${params.toString()}`);
      const data = await res.json();
      if (!res.ok) {
        setLoadError(
          data.error ||
            `The server answered with status ${res.status}. Your documents could not be loaded.`
        );
        setDocs([]);
        return;
      }
      setDocs(data.documents || []);
    } catch {
      setLoadError(
        "Could not reach the Aether server. Make sure Aether.bat (or start.sh) is still running, then click Retry."
      );
      setDocs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load(q);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const filtered = useMemo(() => {
    let list = docs;
    if (filter === "recent") {
      list = [...list].sort(
        (a, b) =>
          new Date(b.lastOpenedAt || b.updatedAt).getTime() -
          new Date(a.lastOpenedAt || a.updatedAt).getTime()
      );
    }
    return list;
  }, [docs, filter]);

  async function createDoc(opts?: {
    title?: string;
    content?: string;
    coverColor?: string;
    aiPrompt?: string;
  }) {
    setCreating(true);
    try {
      let title = opts?.title || "Untitled Document";
      let content = opts?.content || "<p></p>";
      let aiSummary: string | undefined;

      if (opts?.aiPrompt) {
        const gen = await fetch("/api/ai/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ mode: "write", prompt: opts.aiPrompt }),
        });
        const data = await gen.json();
        content = data.html || content;
        if (data.title) title = data.title;
        aiSummary = data.plain?.slice(0, 240);
      }

      const res = await fetch("/api/documents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          content,
          coverColor: opts?.coverColor || "#4f46e5",
          aiSummary,
        }),
      });
      const data = await res.json();
      if (data.document?.id) {
        router.push(`/doc/${data.document.id}`);
      }
    } finally {
      setCreating(false);
    }
  }

  async function removeDoc(id: string) {
    if (!confirm("Delete this document?")) return;
    await fetch(`/api/documents/${id}`, { method: "DELETE" });
    setDocs((d) => d.filter((x) => x.id !== id));
  }

  async function toggleStar(doc: DocumentListItem) {
    const full = await fetch(`/api/documents/${doc.id}`);
    const data = await full.json();
    if (!data.document) return;
    await fetch(`/api/documents/${doc.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: data.document.content,
        title: data.document.title,
        isStarred: !doc.isStarred,
      }),
    });
    setDocs((list) =>
      list.map((d) =>
        d.id === doc.id ? { ...d, isStarred: !d.isStarred } : d
      )
    );
  }

  return (
    <div className="min-h-screen bg-[#0b1020] text-white">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-32 top-0 h-[480px] w-[480px] rounded-full bg-indigo-600/30 blur-[120px]" />
        <div className="absolute right-0 top-40 h-[420px] w-[420px] rounded-full bg-fuchsia-600/20 blur-[120px]" />
        <div className="absolute bottom-0 left-1/3 h-[360px] w-[360px] rounded-full bg-cyan-500/10 blur-[100px]" />
      </div>

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-lg font-black shadow-lg shadow-indigo-500/40">
            Æ
          </div>
          <div>
            <div className="text-sm font-bold tracking-tight">Aether</div>
            <div className="text-[11px] text-slate-400">
              Document OS · beyond Microsoft Word
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <input
            ref={uploadRef}
            type="file"
            accept=".docx,.pdf,.rtf,.txt,.md,.markdown,.html,.htm,.json,.csv"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void openFile(f);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            disabled={uploading}
            onClick={() => uploadRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/10 disabled:opacity-60"
          >
            <Upload className="h-4 w-4" />
            {uploading ? "Opening…" : "Open .docx / .pdf"}
          </button>
          <button
            type="button"
            disabled={creating}
            onClick={() => void createDoc()}
            className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-lg shadow-white/10 transition hover:bg-indigo-50 disabled:opacity-60"
          >
            <Plus className="h-4 w-4" />
            New document
          </button>
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-6xl px-6 pb-24">
        {/* Hero */}
        <section className="mb-12 pt-6 text-center md:pt-10">
          <div className="mb-4 flex flex-wrap items-center justify-center gap-2">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-medium text-indigo-200 backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" />
              The AI-native document OS Word should have become
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[11px] font-medium text-emerald-300">
              <Download className="h-3.5 w-3.5" />
              Installable on Windows & macOS
            </span>
          </div>
          <h1 className="mx-auto max-w-3xl text-4xl font-semibold tracking-tight md:text-6xl md:leading-[1.05]">
            Write once.{" "}
            <span className="bg-gradient-to-r from-indigo-300 via-fuchsia-300 to-cyan-300 bg-clip-text text-transparent">
              Think with the page.
            </span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-slate-400 md:text-lg">
            Aether fuses a full Word-class editor with copilot drafting,
            Grammarly-depth clarity, QuillBot-style rewriting, research briefs,
            living outlines, version intelligence, and multi-format export —
            one surface, many jobs.
          </p>

          <div className="mx-auto mt-8 max-w-2xl rounded-2xl border border-white/10 bg-white/5 p-2 shadow-2xl shadow-indigo-500/10 backdrop-blur">
            <div className="flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <Wand2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-indigo-300" />
                <input
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && prompt.trim()) {
                      void createDoc({ aiPrompt: prompt.trim() });
                    }
                  }}
                  placeholder="Describe a document and Aether will draft it…"
                  className="w-full rounded-xl border-0 bg-slate-950/50 py-3 pl-10 pr-3 text-sm text-white outline-none ring-1 ring-white/10 placeholder:text-slate-500 focus:ring-indigo-400/50"
                />
              </div>
              <button
                type="button"
                disabled={creating || !prompt.trim()}
                onClick={() => void createDoc({ aiPrompt: prompt.trim() })}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 px-5 py-3 text-sm font-semibold shadow-lg shadow-indigo-500/30 disabled:opacity-50"
              >
                Generate
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </section>

        {uploadError && (
          <div className="mb-6 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
            {uploadError}
          </div>
        )}

        {loadError && (
          <div className="mb-6 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
            <p className="font-semibold">Couldn't load your documents</p>
            <p className="mt-1 text-amber-200/80">{loadError}</p>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => void load(q)}
                className="rounded-lg bg-amber-400/20 px-3 py-1.5 text-xs font-semibold text-amber-100 hover:bg-amber-400/30"
              >
                Retry
              </button>
              <a
                href="/api/diagnose"
                target="_blank"
                className="rounded-lg px-3 py-1.5 text-xs text-amber-200/70 underline hover:text-amber-100"
              >
                Run diagnostics
              </a>
            </div>
          </div>
        )}

        {/* Features */}
        <section className="mb-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <button
              key={f.title}
              type="button"
              onClick={() => setSelectedFeature(f)}
              className="group w-full rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-left backdrop-blur transition hover:border-indigo-400/50 hover:bg-white/[0.08] focus:outline-none focus:ring-2 focus:ring-indigo-400/60"
              aria-label={`Learn about ${f.title}`}
            >
              <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-300">
                <f.icon className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-white">{f.title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-400">
                {f.desc}
              </p>
            </button>
          ))}
        </section>

        {/* Templates */}
        <section className="mb-12">
          <div className="mb-4 flex items-center gap-2">
            <LayoutTemplate className="h-4 w-4 text-indigo-300" />
            <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300">
              Start from a template
            </h2>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {BUILT_IN_TEMPLATES.slice(0, 8).map((t) => (
              <button
                key={t.id}
                type="button"
                disabled={creating}
                onClick={() =>
                  void createDoc({
                    title: t.title,
                    content: t.content,
                    coverColor: t.coverColor,
                  })
                }
                className="group min-w-[160px] max-w-[160px] shrink-0 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] text-left transition hover:border-white/25 hover:bg-white/[0.08]"
              >
                <div
                  className="h-20 w-full transition group-hover:brightness-110"
                  style={{
                    background: `linear-gradient(135deg, ${t.coverColor}, #0f172a)`,
                  }}
                />
                <div className="p-3">
                  <div className="text-xs font-semibold text-white">
                    {t.title}
                  </div>
                  <div className="mt-0.5 text-[10px] text-slate-400">
                    {t.category}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Library */}
        <section>
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-indigo-300" />
              <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300">
                Your library
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void load(q);
                  }}
                  placeholder="Search documents…"
                  className="w-56 rounded-lg border border-white/10 bg-white/5 py-1.5 pl-8 pr-3 text-xs text-white outline-none placeholder:text-slate-500 focus:border-indigo-400/40"
                />
              </div>
              <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 p-0.5">
                {(
                  [
                    ["all", "All"],
                    ["recent", "Recent"],
                    ["starred", "Starred"],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setFilter(id)}
                    className={cn(
                      "inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-medium",
                      filter === id
                        ? "bg-white text-slate-900"
                        : "text-slate-400 hover:text-white"
                    )}
                  >
                    {id === "starred" ? (
                      <Star className="h-3 w-3" />
                    ) : id === "recent" ? (
                      <Clock className="h-3 w-3" />
                    ) : (
                      <Filter className="h-3 w-3" />
                    )}
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {loading ? (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="h-36 animate-pulse rounded-2xl bg-white/5"
                />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-16 text-center">
              <FileText className="mx-auto mb-3 h-8 w-8 text-slate-500" />
              <p className="text-sm text-slate-400">
                No documents yet. Create one or generate from a prompt above.
              </p>
              <button
                type="button"
                onClick={() => void createDoc()}
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-indigo-500 px-4 py-2 text-xs font-semibold"
              >
                <Plus className="h-3.5 w-3.5" />
                Blank document
              </button>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((doc) => (
                <article
                  key={doc.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => router.push(`/doc/${doc.id}`)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      router.push(`/doc/${doc.id}`);
                    }
                  }}
                  className="group relative cursor-pointer overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] transition hover:border-indigo-400/40 hover:bg-white/[0.07] focus:outline-none focus:ring-2 focus:ring-indigo-400/50"
                >
                  <div
                    className="h-2 w-full"
                    style={{ background: doc.coverColor || "#4f46e5" }}
                  />
                  <div className="p-4">
                    <div className="mb-2 flex items-start justify-between gap-2">
                      <h3 className="line-clamp-1 text-sm font-semibold text-white">
                        {doc.title}
                      </h3>
                      <div className="relative z-20 flex items-center gap-1">
                        <button
                          type="button"
                          className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-amber-400"
                          onClick={(e) => {
                            e.stopPropagation();
                            void toggleStar(doc);
                          }}
                        >
                          <Star
                            className={cn(
                              "h-3.5 w-3.5",
                              doc.isStarred && "fill-amber-400 text-amber-400"
                            )}
                          />
                        </button>
                        <button
                          type="button"
                          className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-rose-400"
                          onClick={(e) => {
                            e.stopPropagation();
                            void removeDoc(doc.id);
                          }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="line-clamp-2 min-h-[2.5rem] text-xs leading-relaxed text-slate-400">
                      {doc.aiSummary ||
                        doc.plainText?.slice(0, 140) ||
                        "Empty document"}
                    </p>
                    <div className="mt-3 flex items-center justify-between text-[10px] text-slate-500">
                      <span>
                        {doc.wordCount} words
                        {doc.readingLevel ? ` · ${doc.readingLevel}` : ""}
                      </span>
                      <span>{formatRelativeDate(doc.updatedAt)}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {selectedFeature && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-label={selectedFeature.title}
            onMouseDown={(e) => {
              if (e.target === e.currentTarget) setSelectedFeature(null);
            }}
          >
            <div className="w-full max-w-md rounded-3xl border border-white/15 bg-slate-900 p-6 text-left shadow-2xl shadow-black/40">
              <div className="flex items-start justify-between gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-300">
                  <selectedFeature.icon className="h-5 w-5" />
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedFeature(null)}
                  className="rounded-lg p-2 text-slate-400 hover:bg-white/10 hover:text-white"
                  aria-label="Close feature details"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <h2 className="mt-4 text-xl font-semibold text-white">
                {selectedFeature.title}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-slate-300">
                {selectedFeature.desc}
              </p>
              <div className="mt-4 rounded-xl border border-indigo-400/20 bg-indigo-400/10 p-3 text-xs leading-relaxed text-indigo-100">
                This capability is available inside the document editor. Create a
                document and use the editor ribbon to activate it.
              </div>
              <div className="mt-5 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFeature(null);
                    void createDoc({
                      aiPrompt: `Create a document using ${selectedFeature.title}. ${selectedFeature.desc}`,
                    });
                  }}
                  className="flex-1 rounded-xl bg-indigo-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-400"
                >
                  Try it in a document
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedFeature(null)}
                  className="rounded-xl px-4 py-2.5 text-sm font-medium text-slate-400 hover:bg-white/10 hover:text-white"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
