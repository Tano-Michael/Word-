"use client";

import { useEffect, useState } from "react";
import {
  Sparkles,
  SpellCheck2,
  RefreshCw,
  ListTree,
  MessageSquare,
  History,
  Download,
  BarChart3,
  LayoutTemplate,
  Search,
  X,
  Check,
  Loader2,
  Wand2,
  Copy,
  ArrowRight,
  Lightbulb,
  AlertCircle,
  AlertTriangle,
  Info,
  Shield,
  CheckCircle,
  Wifi,
  WifiOff,
  LockKeyhole,
} from "lucide-react";
import { analyzeProtection, type ProtectionResult } from "@/lib/protection-engine";
import type { Editor } from "@tiptap/react";
import type {
  AiMode,
  GrammarIssue,
  OutlineItem,
  PanelId,
  RewriteStyle,
  WritingInsights,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { BUILT_IN_TEMPLATES } from "@/lib/templates";

const REWRITE_STYLES: { id: RewriteStyle; label: string; desc: string }[] = [
  { id: "standard", label: "Standard", desc: "Balanced polish" },
  { id: "fluency", label: "Fluency", desc: "Natural flow" },
  { id: "formal", label: "Formal", desc: "Professional" },
  { id: "simple", label: "Simple", desc: "Easy reading" },
  { id: "creative", label: "Creative", desc: "Vivid language" },
  { id: "expand", label: "Expand", desc: "More detail" },
  { id: "shorten", label: "Shorten", desc: "Condense" },
  { id: "academic", label: "Academic", desc: "Scholarly" },
  { id: "casual", label: "Casual", desc: "Conversational" },
  { id: "persuasive", label: "Persuasive", desc: "Compelling" },
  { id: "confident", label: "Confident", desc: "Decisive" },
  { id: "empathetic", label: "Empathetic", desc: "Warm tone" },
  { id: "seo", label: "SEO", desc: "Discoverable" },
];

const AI_MODES: { id: AiMode; label: string }[] = [
  { id: "write", label: "Write" },
  { id: "continue", label: "Continue" },
  { id: "improve", label: "Improve" },
  { id: "summarize", label: "Summarize" },
  { id: "expand", label: "Expand" },
  { id: "shorten", label: "Shorten" },
  { id: "outline", label: "Outline" },
  { id: "brainstorm", label: "Brainstorm" },
  { id: "tone", label: "Tone shift" },
  { id: "fix", label: "Fix writing" },
  { id: "explain", label: "Explain" },
  { id: "email", label: "Email" },
  { id: "blog", label: "Blog" },
  { id: "proposal", label: "Proposal" },
  { id: "meeting-notes", label: "Meeting" },
  { id: "resume", label: "Resume" },
  { id: "research", label: "Research" },
  { id: "translate", label: "Translate" },
];

function severityIcon(s: GrammarIssue["severity"]) {
  if (s === "error") return <AlertCircle className="h-3.5 w-3.5 text-rose-500" />;
  if (s === "warning")
    return <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />;
  return <Info className="h-3.5 w-3.5 text-sky-500" />;
}

type EngineInfo = {
  mode?: string;
  provider?: string | null;
  ai?: string | null;
  model?: string | null;
  online?: string | null;
  message?: string;
};

function EngineBadge({ engine }: { engine: EngineInfo | null }) {
  if (!engine) {
    return (
      <div className="flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[10px] text-slate-500">
        <LockKeyhole className="h-3 w-3" />
        Private local engine ready
      </div>
    );
  }
  const online = engine.mode === "cloud" || engine.mode === "hybrid-online" || engine.mode === "ai-enhanced" || engine.mode === "free-online";
  const name =
    engine.ai || engine.provider || engine.online || (online ? "AI cloud" : "Aether local");
  return (
    <div
      className={cn(
        "rounded-lg border px-2.5 py-2",
        online
          ? "border-emerald-100 bg-emerald-50/70"
          : "border-slate-200 bg-slate-50"
      )}
    >
      <div
        className={cn(
          "flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider",
          online ? "text-emerald-700" : "text-slate-500"
        )}
      >
        {online ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
        {online ? "Online" : "Local fallback"} · {name}
        {engine.model && (
          <span className="ml-auto max-w-[110px] truncate font-medium normal-case tracking-normal opacity-75">
            {engine.model}
          </span>
        )}
      </div>
      {engine.message && (
        <p className="mt-1 text-[10px] leading-relaxed text-slate-500">
          {engine.message}
        </p>
      )}
    </div>
  );
}

export function SidePanel({
  panel,
  onClose,
  editor,
  documentId,
  title,
  plainText,
  html,
  selection,
  insights,
  onInsights,
  onApplyHtml,
  onApplyText,
  onReplacePhrase,
  onLoadTemplate,
  comments,
  onAddComment,
  onToggleComment,
  versions,
  onRestoreVersion,
  onCreateVersion,
}: {
  panel: PanelId;
  onClose: () => void;
  editor: Editor | null;
  documentId: string;
  title: string;
  plainText: string;
  html: string;
  selection: string;
  insights: WritingInsights | null;
  onInsights: (i: WritingInsights) => void;
  onApplyHtml: (html: string, mode?: "replace" | "insert") => void;
  onApplyText: (text: string) => void;
  onReplacePhrase: (original: string, suggestion: string) => boolean;
  onLoadTemplate: (content: string, title?: string) => void;
  comments: {
    id: string;
    body: string;
    author: string;
    anchorText: string | null;
    resolved: boolean;
    createdAt: string | Date;
  }[];
  onAddComment: (body: string, anchorText?: string) => void;
  onToggleComment: (id: string, resolved: boolean) => void;
  versions: {
    id: string;
    label: string | null;
    title: string;
    createdAt: string | Date;
    content: string;
  }[];
  onRestoreVersion: (content: string, title: string) => void;
  onCreateVersion: () => void;
}) {
  const [aiMode, setAiMode] = useState<AiMode>("write");
  const [prompt, setPrompt] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<string | null>(null);
  const [aiEngine, setAiEngine] = useState<EngineInfo | null>(null);

  const [grammarLoading, setGrammarLoading] = useState(false);
  const [issues, setIssues] = useState<GrammarIssue[]>([]);
  const [grammarScore, setGrammarScore] = useState<number | null>(null);
  const [grammarFilter, setGrammarFilter] = useState<string>("all");
  const [grammarEngine, setGrammarEngine] = useState<EngineInfo | null>(null);
  const [useAiGrammar, setUseAiGrammar] = useState(false);

  const [rewriteStyle, setRewriteStyle] = useState<RewriteStyle>("standard");
  const [rewriteLoading, setRewriteLoading] = useState(false);
  const [variants, setVariants] = useState<string[]>([]);
  const [rewriteEngine, setRewriteEngine] = useState<EngineInfo | null>(null);
  const [useAiRewrite, setUseAiRewrite] = useState(true);

  const [protectionLoading, setProtectionLoading] = useState(false);
  const [protectionResult, setProtectionResult] = useState<ProtectionResult | null>(null);
  const [humanizeLoading, setHumanizeLoading] = useState(false);
  const [humanizedText, setHumanizedText] = useState<string | null>(null);
  const [useAiHumanize, setUseAiHumanize] = useState(true);

  const [outline, setOutline] = useState<OutlineItem[]>([]);
  const [recs, setRecs] = useState<string[]>([]);
  const [insightsLoading, setInsightsLoading] = useState(false);

  const [commentBody, setCommentBody] = useState("");
  const [exporting, setExporting] = useState<string | null>(null);
  const [researchQ, setResearchQ] = useState("");

  useEffect(() => {
    if (panel === "grammar" && plainText) {
      const timer = setTimeout(() => void runGrammar(), 350);
      return () => clearTimeout(timer);
    }
    if (panel === "protection" && plainText) {
      const timer = setTimeout(() => void runProtection(), 350);
      return () => clearTimeout(timer);
    }
    if (panel === "insights" || panel === "outline") void runInsights();
    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panel, plainText]);

  if (panel === "none") return null;

  const titles: Record<Exclude<PanelId, "none">, string> = {
    ai: "Aether Copilot",
    grammar: "Grammar & Clarity",
    rewrite: "Rewrite Studio",
    protection: "Writing Protection (AI Bypass)",
    outline: "Living Outline",
    comments: "Comments",
    versions: "Version history",
    export: "Export & share",
    insights: "Writing intelligence",
    templates: "Templates",
    research: "Research desk",
  };

  async function runAi() {
    setAiLoading(true);
    setAiResult(null);
    try {
      const res = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: aiMode,
          prompt,
          selection,
          documentText: plainText,
        }),
      });
      const data = await res.json();
      setAiResult(data.html || "");
      setAiEngine(data.engine || null);
      if (data.insights) onInsights(data.insights);
    } finally {
      setAiLoading(false);
    }
  }

  async function runGrammar(online = false, useAi = useAiGrammar) {
    setGrammarLoading(true);
    try {
      const res = await fetch("/api/ai/grammar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: plainText, online, useAi, language: "en-US" }),
      });
      const data = await res.json();
      setIssues(data.issues || []);
      setGrammarScore(data.score ?? null);
      setGrammarEngine(data.engine || null);
      if (data.insights) onInsights(data.insights);
    } finally {
      setGrammarLoading(false);
    }
  }

  async function runRewrite() {
    const text = selection || plainText;
    if (!text.trim()) return;
    setRewriteLoading(true);
    try {
      const res = await fetch("/api/ai/rewrite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, style: rewriteStyle, online: useAiRewrite }),
      });
      const data = await res.json();
      setVariants(data.variants || []);
      setRewriteEngine(data.engine || null);
    } finally {
      setRewriteLoading(false);
    }
  }

  async function runInsights() {
    setInsightsLoading(true);
    try {
      const res = await fetch("/api/ai/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: plainText, html }),
      });
      const data = await res.json();
      if (data.insights) onInsights(data.insights);
      setOutline(data.outline || []);
      setRecs(data.recommendations || []);
    } finally {
      setInsightsLoading(false);
    }
  }

  async function runProtection() {
    setProtectionLoading(true);
    try {
      const res = await fetch("/api/ai/protection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: plainText }),
      });
      const data = await res.json();
      setProtectionResult(data);
    } catch (err) {
      console.error("Protection analyze failed", err);
    } finally {
      setProtectionLoading(false);
    }
  }

  async function runAiHumanize() {
    const text = selection || plainText;
    if (!text.trim()) return;
    setHumanizeLoading(true);
    setHumanizedText(null);
    try {
      const prompt = [
        "Rewrite this text so it sounds completely human, with varied sentence lengths, natural vocabulary, and personal voice. Remove all generic AI phrases like 'furthermore', 'delve into', 'it is important to note', 'robust', 'seamless'. Use specific, concrete language. Keep every fact and number intact.",
        text,
      ].join("\n\n");
      const res = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "improve", prompt, online: true }),
      });
      const data = await res.json();
      setHumanizedText(data.plain || data.html || "");
    } catch (err) {
      console.error("AI humanize failed", err);
    } finally {
      setHumanizeLoading(false);
    }
  }

  async function exportDoc(format: string) {
    setExporting(format);
    try {
      if (format === "pdf") {
        const { jsPDF } = await import("jspdf");
        const doc = new jsPDF({ unit: "pt", format: "letter" });
        const margin = 56;
        const pageWidth = doc.internal.pageSize.getWidth() - margin * 2;
        doc.setFont("times", "normal");
        doc.setFontSize(11);
        const lines = doc.splitTextToSize(
          `${title}\n\n${plainText}`,
          pageWidth
        ) as string[];
        let y = margin;
        const lineHeight = 16;
        const pageHeight = doc.internal.pageSize.getHeight() - margin;
        for (const line of lines) {
          if (y > pageHeight) {
            doc.addPage();
            y = margin;
          }
          doc.text(line, margin, y);
          y += lineHeight;
        }
        doc.save(`${title || "document"}.pdf`);
        return;
      }

      const res = await fetch("/api/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, html, format }),
      });
      if (format === "json") {
        const data = await res.json();
        const blob = new Blob([JSON.stringify(data, null, 2)], {
          type: "application/json",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${title || "document"}.json`;
        a.click();
        URL.revokeObjectURL(url);
        return;
      }
      const blob = await res.blob();
      const cd = res.headers.get("Content-Disposition") || "";
      const match = cd.match(/filename="([^"]+)"/);
      const filename = match?.[1] || `document.${format}`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setExporting(null);
    }
  }

  const filteredIssues =
    grammarFilter === "all"
      ? issues
      : issues.filter((i) => i.severity === grammarFilter || i.type === grammarFilter);

  return (
    <aside className="flex h-full w-full max-w-[380px] flex-col border-l border-slate-200 bg-white shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 text-white">
            {panel === "ai" && <Sparkles className="h-4 w-4" />}
            {panel === "grammar" && <SpellCheck2 className="h-4 w-4" />}
            {panel === "rewrite" && <RefreshCw className="h-4 w-4" />}
            {panel === "protection" && <Shield className="h-4 w-4" />}
            {panel === "outline" && <ListTree className="h-4 w-4" />}
            {panel === "comments" && <MessageSquare className="h-4 w-4" />}
            {panel === "versions" && <History className="h-4 w-4" />}
            {panel === "export" && <Download className="h-4 w-4" />}
            {panel === "insights" && <BarChart3 className="h-4 w-4" />}
            {panel === "templates" && <LayoutTemplate className="h-4 w-4" />}
            {panel === "research" && <Search className="h-4 w-4" />}
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              {titles[panel]}
            </h2>
            <p className="text-[11px] text-slate-500">Beyond Word · AI-native</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {panel === "ai" && (
          <div className="space-y-4">
            <p className="text-xs leading-relaxed text-slate-500">
              Copilot drafts, continues, structures, and transforms your document
              in place — the update Word should have shipped first.
            </p>
            <EngineBadge engine={aiEngine} />
            <div className="flex flex-wrap gap-1.5">
              {AI_MODES.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setAiMode(m.id)}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[11px] font-medium transition",
                    aiMode === m.id
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  )}
                >
                  {m.label}
                </button>
              ))}
            </div>
            {selection && (
              <div className="rounded-lg border border-indigo-100 bg-indigo-50/60 p-2 text-[11px] text-indigo-900">
                <span className="font-semibold">Selection:</span>{" "}
                {selection.slice(0, 160)}
                {selection.length > 160 ? "…" : ""}
              </div>
            )}
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe what you need… e.g. Write a product launch announcement for Aether"
              className="min-h-[100px] w-full resize-y rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none ring-indigo-500/30 focus:bg-white focus:ring-2"
            />
            <button
              type="button"
              onClick={() => void runAi()}
              disabled={aiLoading}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:from-indigo-500 hover:to-violet-500 disabled:opacity-60"
            >
              {aiLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Wand2 className="h-4 w-4" />
              )}
              Generate with Aether
            </button>
            {aiResult && (
              <div className="space-y-2">
                <div
                  className="prose prose-sm max-w-none rounded-xl border border-slate-200 bg-white p-3 text-slate-800 shadow-sm"
                  dangerouslySetInnerHTML={{ __html: aiResult }}
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white"
                    onClick={() => onApplyHtml(aiResult, "replace")}
                  >
                    Replace doc
                  </button>
                  <button
                    type="button"
                    className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700"
                    onClick={() => onApplyHtml(aiResult, "insert")}
                  >
                    Insert at cursor
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {panel === "grammar" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500">
                  Grammarly-class checks: spelling, grammar, clarity, tone &
                  concision.
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => void runGrammar(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-100"
                  title="Send this document to LanguageTool for a deeper online check"
                >
                  {grammarLoading ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Wifi className="h-3.5 w-3.5" />
                  )}
                  Check online
                </button>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setUseAiGrammar((s) => !s);
                void runGrammar(false, !useAiGrammar);
              }}
              className={cn(
                "flex w-full items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium transition",
                useAiGrammar
                  ? "border-indigo-200 bg-indigo-50 text-indigo-700"
                  : "border-slate-200 text-slate-500 hover:bg-slate-50"
              )}
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span className="flex-1 text-left">
                {useAiGrammar ? "AI-enhanced grammar ON" : "Use AI provider for grammar"}
              </span>
              <div
                className={cn(
                  "h-4 w-7 rounded-full transition-colors",
                  useAiGrammar ? "bg-indigo-500" : "bg-slate-300"
                )}
              >
                <div
                  className={cn(
                    "h-3.5 w-3.5 translate-y-[1px] rounded-full bg-white transition-transform",
                    useAiGrammar ? "translate-x-[14px]" : "translate-x-[2px]"
                  )}
                />
              </div>
            </button>
            <EngineBadge engine={grammarEngine} />
            {grammarEngine?.mode === "hybrid-online" && (
              <p className="text-[10px] leading-relaxed text-slate-400">
                Cloud proofreading powered by{" "}
                <a
                  href="https://languagetool.org"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium text-indigo-600 underline"
                >
                  LanguageTool
                </a>
                . Text is sent only when you click Check online.
              </p>
            )}
            {grammarScore !== null && (
              <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-900 p-4 text-white">
                <div className="text-[11px] uppercase tracking-wider text-indigo-200">
                  Writing score
                </div>
                <div className="mt-1 flex items-end gap-2">
                  <span className="text-4xl font-bold">{grammarScore}</span>
                  <span className="mb-1 text-sm text-indigo-200">/ 100</span>
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/20">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-cyan-300"
                    style={{ width: `${grammarScore}%` }}
                  />
                </div>
              </div>
            )}
            <div className="flex flex-wrap gap-1">
              {["all", "error", "warning", "suggestion", "spelling", "style"].map(
                (f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setGrammarFilter(f)}
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[10px] font-medium capitalize",
                      grammarFilter === f
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 text-slate-600"
                    )}
                  >
                    {f}
                  </button>
                )
              )}
            </div>
            <div className="space-y-2">
              {filteredIssues.length === 0 && !grammarLoading && (
                <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-4 text-center text-sm text-emerald-800">
                  <Check className="mx-auto mb-1 h-5 w-5" />
                  Looking sharp — no issues in this filter.
                </div>
              )}
              {filteredIssues.map((issue) => (
                <div
                  key={issue.id}
                  className="rounded-xl border border-slate-150 border-slate-200 p-3 shadow-sm"
                >
                  <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                    {severityIcon(issue.severity)}
                    {issue.type}
                  </div>
                  <p className="text-sm text-slate-800">
                    <span className="rounded bg-rose-50 px-1 text-rose-700 line-through decoration-rose-300">
                      {issue.original}
                    </span>
                    {issue.suggestion && !issue.suggestion.startsWith("(") && (
                      <>
                        <ArrowRight className="mx-1 inline h-3 w-3 text-slate-400" />
                        <span className="rounded bg-emerald-50 px-1 text-emerald-800">
                          {issue.suggestion}
                        </span>
                      </>
                    )}
                  </p>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-500">
                    {issue.explanation}
                  </p>
                  <div className="mt-2 flex items-center gap-3">
                    <button
                      type="button"
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      onClick={() => {
                        const applied = onReplacePhrase(
                          issue.original,
                          issue.suggestion
                        );
                        if (applied) {
                          setIssues((prev) =>
                            prev.filter((x) => x.id !== issue.id)
                          );
                        } else {
                          // Phrase no longer present (already edited) — just clear it
                          setIssues((prev) =>
                            prev.filter((x) => x.id !== issue.id)
                          );
                        }
                      }}
                    >
                      Apply fix
                    </button>
                    <button
                      type="button"
                      className="text-xs font-medium text-slate-400 hover:text-slate-600"
                      onClick={() =>
                        setIssues((prev) =>
                          prev.filter((x) => x.id !== issue.id)
                        )
                      }
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {panel === "protection" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500">
                Advanced AI bypass analysis: protects original intent while breaking generic AI predictability patterns.
              </p>
              <button
                type="button"
                onClick={() => void runProtection()}
                className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                {protectionLoading ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  "Analyze"
                )}
              </button>
            </div>

            {protectionResult && (
              <div className="space-y-4">
                {/* Score badge */}
                <div className="rounded-2xl bg-gradient-to-br from-indigo-900 to-slate-900 p-4 text-white">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] uppercase tracking-wider text-indigo-200">
                      Human Protection Score
                    </span>
                    <span className={cn(
                      "rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider",
                      protectionResult.score >= 70 ? "bg-emerald-500/20 text-emerald-300" :
                      protectionResult.score >= 40 ? "bg-amber-500/20 text-amber-300" :
                      "bg-rose-500/20 text-rose-300"
                    )}>
                      {protectionResult.grade}
                    </span>
                  </div>
                  <div className="mt-1 flex items-end gap-2">
                    <span className="text-4xl font-bold">{protectionResult.score}%</span>
                    <span className="mb-1 text-xs text-indigo-200">resistant to AI detectors</span>
                  </div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/15">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        protectionResult.score >= 70 ? "bg-emerald-400" :
                        protectionResult.score >= 40 ? "bg-amber-400" :
                        "bg-rose-400"
                      )}
                      style={{ width: `${protectionResult.score}%` }}
                    />
                  </div>
                </div>

                {/* Subscores */}
                <div className="grid grid-cols-3 gap-1.5">
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 text-center">
                    <div className="text-[10px] text-slate-400 uppercase font-medium">Vocab</div>
                    <div className="text-sm font-semibold text-slate-800">{protectionResult.vocabularyScore}%</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 text-center">
                    <div className="text-[10px] text-slate-400 uppercase font-medium">Burstiness</div>
                    <div className="text-sm font-semibold text-slate-800">{protectionResult.burstiness}%</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 text-center">
                    <div className="text-[10px] text-slate-400 uppercase font-medium">Repetition</div>
                    <div className="text-sm font-semibold text-slate-800">{protectionResult.repetitionScore}%</div>
                  </div>
                </div>

                {/* Actionable humanizer fixes */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    One-click humanizer fixes
                  </h4>
                  {protectionResult.patterns.filter(p => p.type === "common_ai_phrase").map((p, idx) => (
                    <div key={idx} className="rounded-xl border border-slate-200 p-3 shadow-sm bg-white">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-amber-600">
                        <Shield className="h-3.5 w-3.5" />
                        Common AI Phrase detected
                      </div>
                      <p className="mt-1 text-sm text-slate-800">
                        Replace <span className="font-semibold line-through text-rose-600 bg-rose-50 px-1 rounded">{p.originalPhrase}</span>
                        {" "}with{" "}
                        <span className="font-semibold text-emerald-800 bg-emerald-50 px-1 rounded">{p.suggestedPhrase}</span>
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          if (p.originalPhrase && p.suggestedPhrase) {
                            const applied = onReplacePhrase(p.originalPhrase, p.suggestedPhrase);
                            if (applied) {
                              // Re-run protection after small timeout
                              setTimeout(() => void runProtection(), 200);
                            }
                          }
                        }}
                        className="mt-2.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        Apply protection fix
                      </button>
                    </div>
                  ))}
                  {protectionResult.patterns.filter(p => p.type !== "common_ai_phrase").map((p, idx) => (
                    <div key={idx} className="rounded-xl border border-slate-200 p-3 bg-slate-50">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        <AlertTriangle className="h-3.5 w-3.5 text-slate-500" />
                        {p.type}
                      </div>
                      <p className="mt-1 text-xs leading-relaxed text-slate-600">
                        {p.message}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Suggestions */}
                <div className="rounded-xl border border-indigo-50 bg-indigo-50/40 p-3">
                  <div className="flex items-center gap-1 text-xs font-bold text-indigo-900 uppercase">
                    <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
                    How to protect your style
                  </div>
                  <ul className="mt-1.5 space-y-1 text-xs text-indigo-950/80">
                    {protectionResult.suggestions.map((s, idx) => (
                      <li key={idx}>• {s}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* AI-powered humanization */}
            <div className="rounded-2xl border border-violet-200 bg-violet-50/60 p-3">
              <div className="mb-2 flex items-center gap-1.5 text-xs font-bold text-violet-900">
                <Sparkles className="h-3.5 w-3.5 text-violet-600" />
                AI-powered humanization
              </div>
              <p className="mb-2.5 text-[11px] leading-relaxed text-violet-800/80">
                When connected to an AI provider, this rewrites the text to
                score strongly human — preserving every fact, number, and intent.
              </p>
              <button
                type="button"
                onClick={() => setUseAiHumanize((s) => !s)}
                className={cn(
                  "mb-2.5 flex w-full items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium transition",
                  useAiHumanize
                    ? "border-violet-300 bg-violet-100 text-violet-800"
                    : "border-slate-200 text-slate-500 hover:bg-white"
                )}
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span className="flex-1 text-left">
                  {useAiHumanize ? "AI provider ON" : "Enable AI provider"}
                </span>
                <div
                  className={cn(
                    "h-4 w-7 rounded-full transition-colors",
                    useAiHumanize ? "bg-violet-500" : "bg-slate-300"
                  )}
                >
                  <div
                    className={cn(
                      "h-3.5 w-3.5 translate-y-[1px] rounded-full bg-white transition-transform",
                      useAiHumanize ? "translate-x-[14px]" : "translate-x-[2px]"
                    )}
                  />
                </div>
              </button>
              <button
                type="button"
                onClick={() => void runAiHumanize()}
                disabled={humanizeLoading}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-violet-600 px-3 py-2 text-xs font-semibold text-white hover:bg-violet-500 disabled:opacity-60"
              >
                {humanizeLoading ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Wand2 className="h-3.5 w-3.5" />
                )}
                Humanize with AI
              </button>
              {humanizedText && (
                <div className="mt-2.5 space-y-2">
                  <div className="max-h-48 overflow-y-auto rounded-lg bg-white p-2.5 text-xs leading-relaxed text-slate-700">
                    {humanizedText}
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => onApplyText(humanizedText)}
                      className="flex-1 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
                    >
                      Apply to document
                    </button>
                    <button
                      type="button"
                      onClick={() => setHumanizedText(null)}
                      className="rounded-lg px-3 py-2 text-xs font-medium text-slate-500 hover:bg-white"
                    >
                      Discard
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {panel === "rewrite" && (
          <div className="space-y-4">
            <p className="text-xs text-slate-500">
              QuillBot-class rewriting with 13 modes. Uses your selection when
              available, otherwise the full document.
            </p>
            <EngineBadge engine={rewriteEngine} />
            <div className="grid grid-cols-2 gap-1.5">
              {REWRITE_STYLES.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setRewriteStyle(s.id)}
                  className={cn(
                    "rounded-xl border px-2.5 py-2 text-left transition",
                    rewriteStyle === s.id
                      ? "border-indigo-300 bg-indigo-50"
                      : "border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="text-xs font-semibold text-slate-800">
                    {s.label}
                  </div>
                  <div className="text-[10px] text-slate-500">{s.desc}</div>
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                setUseAiRewrite((s) => !s);
              }}
              className={cn(
                "flex w-full items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium transition",
                useAiRewrite
                  ? "border-indigo-200 bg-indigo-50 text-indigo-700"
                  : "border-slate-200 text-slate-500 hover:bg-slate-50"
              )}
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span className="flex-1 text-left">
                {useAiRewrite ? "AI-powered rewrite ON" : "Use AI provider for rewrite"}
              </span>
              <div
                className={cn(
                  "h-4 w-7 rounded-full transition-colors",
                  useAiRewrite ? "bg-indigo-500" : "bg-slate-300"
                )}
              >
                <div
                  className={cn(
                    "h-3.5 w-3.5 translate-y-[1px] rounded-full bg-white transition-transform",
                    useAiRewrite ? "translate-x-[14px]" : "translate-x-[2px]"
                  )}
                />
              </div>
            </button>
            <button
              type="button"
              onClick={() => void runRewrite()}
              disabled={rewriteLoading}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              {rewriteLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              Generate variants
            </button>
            <div className="space-y-3">
              {variants.map((v, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-slate-200 bg-slate-50 p-3"
                >
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Variant {i + 1}
                    </span>
                    <button
                      type="button"
                      className="text-slate-400 hover:text-slate-700"
                      onClick={() => void navigator.clipboard.writeText(v)}
                      title="Copy"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <p className="text-sm leading-relaxed text-slate-800">{v}</p>
                  <button
                    type="button"
                    className="mt-2 text-xs font-semibold text-indigo-600"
                    onClick={() => onApplyText(v)}
                  >
                    Use this version
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {panel === "outline" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500">
                Structure extracted from headings — click to jump.
              </p>
              <button
                type="button"
                onClick={() => void runInsights()}
                className="text-xs font-medium text-indigo-600"
              >
                Refresh
              </button>
            </div>
            {insightsLoading && (
              <Loader2 className="mx-auto h-5 w-5 animate-spin text-slate-400" />
            )}
            {outline.map((item) => (
              <button
                key={item.id}
                type="button"
                className="block w-full rounded-lg px-2 py-1.5 text-left text-sm text-slate-700 hover:bg-slate-50"
                style={{ paddingLeft: 8 + (item.level - 1) * 14 }}
                onClick={() => {
                  if (!editor) return;
                  const { doc } = editor.state;
                  let pos = 0;
                  doc.descendants((node, p) => {
                    if (
                      node.isTextblock &&
                      node.textContent.includes(item.text.slice(0, 40))
                    ) {
                      pos = p;
                      return false;
                    }
                  });
                  if (pos) {
                    editor.chain().focus().setTextSelection(pos + 1).run();
                  }
                }}
              >
                <span className="mr-2 text-[10px] font-bold text-slate-400">
                  H{item.level}
                </span>
                {item.text}
              </button>
            ))}
            {!outline.length && !insightsLoading && (
              <p className="text-sm text-slate-500">
                Add headings (H1–H3) to build a living outline.
              </p>
            )}
          </div>
        )}

        {panel === "insights" && (
          <div className="space-y-4">
            <button
              type="button"
              onClick={() => void runInsights()}
              className="text-xs font-medium text-indigo-600"
            >
              {insightsLoading ? "Analyzing…" : "Refresh analysis"}
            </button>
            {insights && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    ["Words", insights.wordCount],
                    ["Sentences", insights.sentenceCount],
                    ["Read time", `${insights.readingTimeMin}m`],
                    ["Grade", insights.gradeLevel],
                    ["Flesch", insights.fleschReadingEase],
                    ["Passive", `${insights.passiveVoicePct}%`],
                  ].map(([k, v]) => (
                    <div
                      key={String(k)}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2"
                    >
                      <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                        {k}
                      </div>
                      <div className="text-sm font-semibold text-slate-900">
                        {v}
                      </div>
                    </div>
                  ))}
                </div>
                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Tone spectrum
                  </h3>
                  {Object.entries(insights.tone).map(([k, v]) => (
                    <div key={k} className="mb-2">
                      <div className="mb-0.5 flex justify-between text-[11px] capitalize text-slate-600">
                        <span>{k}</span>
                        <span>{v}</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-fuchsia-500"
                          style={{ width: `${v}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Top words
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {insights.topWords.map((w) => (
                      <span
                        key={w.word}
                        className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-700"
                      >
                        {w.word} · {w.count}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="rounded-xl border border-amber-100 bg-amber-50 p-3">
                  <div className="mb-1 flex items-center gap-1 text-xs font-semibold text-amber-900">
                    <Lightbulb className="h-3.5 w-3.5" />
                    Recommendations
                  </div>
                  <ul className="space-y-1.5 text-[12px] leading-relaxed text-amber-950/80">
                    {recs.map((r, i) => (
                      <li key={i}>• {r}</li>
                    ))}
                  </ul>
                </div>
              </>
            )}
          </div>
        )}

        {panel === "comments" && (
          <div className="space-y-4">
            <textarea
              value={commentBody}
              onChange={(e) => setCommentBody(e.target.value)}
              placeholder="Add a comment…"
              className="min-h-[80px] w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30"
            />
            <button
              type="button"
              className="w-full rounded-xl bg-indigo-600 py-2 text-sm font-semibold text-white"
              onClick={() => {
                if (!commentBody.trim()) return;
                onAddComment(commentBody, selection || undefined);
                setCommentBody("");
              }}
            >
              Post comment
            </button>
            <div className="space-y-2">
              {comments.map((c) => (
                <div
                  key={c.id}
                  className={cn(
                    "rounded-xl border p-3",
                    c.resolved
                      ? "border-slate-100 bg-slate-50 opacity-70"
                      : "border-slate-200 bg-white"
                  )}
                >
                  <div className="mb-1 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="font-semibold text-slate-700">
                      {c.author}
                    </span>
                    <button
                      type="button"
                      className="text-indigo-600"
                      onClick={() => onToggleComment(c.id, !c.resolved)}
                    >
                      {c.resolved ? "Reopen" : "Resolve"}
                    </button>
                  </div>
                  {c.anchorText && (
                    <p className="mb-1 truncate text-[11px] italic text-slate-400">
                      “{c.anchorText}”
                    </p>
                  )}
                  <p className="text-sm text-slate-800">{c.body}</p>
                </div>
              ))}
              {!comments.length && (
                <p className="text-sm text-slate-500">No comments yet.</p>
              )}
            </div>
          </div>
        )}

        {panel === "versions" && (
          <div className="space-y-3">
            <button
              type="button"
              onClick={onCreateVersion}
              className="w-full rounded-xl border border-dashed border-indigo-300 bg-indigo-50 py-2 text-sm font-semibold text-indigo-700"
            >
              Save checkpoint now
            </button>
            {versions.map((v) => (
              <div
                key={v.id}
                className="rounded-xl border border-slate-200 p-3"
              >
                <div className="text-sm font-semibold text-slate-800">
                  {v.label || "Checkpoint"}
                </div>
                <div className="text-[11px] text-slate-500">
                  {new Date(v.createdAt).toLocaleString()} · {v.title}
                </div>
                <button
                  type="button"
                  className="mt-2 text-xs font-semibold text-indigo-600"
                  onClick={() => onRestoreVersion(v.content, v.title)}
                >
                  Restore this version
                </button>
              </div>
            ))}
            {!versions.length && (
              <p className="text-sm text-slate-500">
                Checkpoints appear as you make large edits or save manually.
              </p>
            )}
          </div>
        )}

        {panel === "export" && (
          <div className="space-y-3">
            <p className="text-xs text-slate-500">
              Multi-format export — PDF, Word-compatible DOC, Markdown, HTML,
              plain text, and JSON.
            </p>
            {[
              ["docx", "Word (.docx)", "True OOXML — styles, lists, tables"],
              ["pdf", "PDF document", "Print-ready pages"],
              ["md", "Markdown", "Developer & notes apps"],
              ["html", "HTML", "Web-ready single file"],
              ["doc", "Word 97 (.doc)", "Legacy compatibility"],
              ["txt", "Plain text", "Universal fallback"],
              ["json", "Aether JSON", "Full fidelity backup"],
            ].map(([fmt, label, desc]) => (
              <button
                key={fmt}
                type="button"
                disabled={exporting === fmt}
                onClick={() => void exportDoc(fmt)}
                className="flex w-full items-center justify-between rounded-xl border border-slate-200 px-3 py-3 text-left hover:border-indigo-300 hover:bg-indigo-50/40 disabled:opacity-60"
              >
                <div>
                  <div className="text-sm font-semibold text-slate-800">
                    {label}
                  </div>
                  <div className="text-[11px] text-slate-500">{desc}</div>
                </div>
                {exporting === fmt ? (
                  <Loader2 className="h-4 w-4 animate-spin text-indigo-600" />
                ) : (
                  <Download className="h-4 w-4 text-slate-400" />
                )}
              </button>
            ))}
            <p className="text-[11px] text-slate-400">
              Document id: {documentId.slice(0, 8)}…
            </p>
          </div>
        )}

        {panel === "templates" && (
          <div className="space-y-2">
            {BUILT_IN_TEMPLATES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => onLoadTemplate(t.content, t.title)}
                className="flex w-full gap-3 rounded-xl border border-slate-200 p-3 text-left hover:border-indigo-300 hover:bg-slate-50"
              >
                <div
                  className="h-10 w-10 shrink-0 rounded-lg"
                  style={{ background: t.coverColor }}
                />
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    {t.title}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {t.category} · {t.description}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {panel === "research" && (
          <div className="space-y-4">
            <p className="text-xs text-slate-500">
              Research desk turns a question into a structured brief you can
              drop into the doc — sources, counterpoints, and actions.
            </p>
            <input
              value={researchQ}
              onChange={(e) => setResearchQ(e.target.value)}
              placeholder="Research question…"
              className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30"
            />
            <button
              type="button"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 py-2.5 text-sm font-semibold text-white"
              onClick={async () => {
                setAiLoading(true);
                try {
                  const res = await fetch("/api/ai/generate", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      mode: "research",
                      prompt: researchQ || title,
                      documentText: plainText,
                    }),
                  });
                  const data = await res.json();
                  setAiResult(data.html);
                } finally {
                  setAiLoading(false);
                }
              }}
            >
              {aiLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
              Build research brief
            </button>
            {aiResult && (
              <div className="space-y-2">
                <div
                  className="prose prose-sm max-w-none rounded-xl border border-slate-200 p-3"
                  dangerouslySetInnerHTML={{ __html: aiResult }}
                />
                <button
                  type="button"
                  className="w-full rounded-lg bg-indigo-600 py-2 text-xs font-semibold text-white"
                  onClick={() => onApplyHtml(aiResult, "insert")}
                >
                  Insert into document
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}
