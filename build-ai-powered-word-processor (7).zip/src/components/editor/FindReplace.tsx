"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import {
  Search,
  ChevronDown,
  ChevronUp,
  Replace,
  ReplaceAll,
  X,
  CaseSensitive,
  WholeWord,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Match = { from: number; to: number };

export function FindReplace({
  visible,
  onClose,
  getText,
  highlightMatches,
  jumpTo,
  replaceText,
}: {
  visible: boolean;
  onClose: () => void;
  getText: () => string;
  highlightMatches: (matches: Match[]) => void;
  jumpTo: (from: number, to: number) => void;
  replaceText: (from: number, to: number, replacement: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [replacement, setReplacement] = useState("");
  const [showReplace, setShowReplace] = useState(false);
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [wholeWord, setWholeWord] = useState(false);
  const [matches, setMatches] = useState<Match[]>([]);
  const [activeIdx, setActiveIdx] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);

  const findMatches = useCallback(() => {
    const text = getText();
    if (!query) {
      setMatches([]);
      setActiveIdx(-1);
      highlightMatches([]);
      return;
    }
    const found: Match[] = [];
    let flags = "gi";
    if (caseSensitive) flags = "g";
    let pattern = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (wholeWord) pattern = `\\b${pattern}\\b`;
    const re = new RegExp(pattern, flags);
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      if (m[0].length === 0) break;
      found.push({ from: m.index, to: m.index + m[0].length });
    }
    setMatches(found);
    setActiveIdx(found.length ? 0 : -1);
    highlightMatches(found);
    if (found.length) jumpTo(found[0].from, found[0].to);
  }, [query, caseSensitive, wholeWord, getText, highlightMatches, jumpTo]);

  useEffect(() => {
    if (visible) {
      findMatches();
      setTimeout(() => inputRef.current?.focus(), 50);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  useEffect(() => {
    findMatches();
  }, [findMatches]);

  useEffect(() => {
    if (activeIdx >= 0 && activeIdx < matches.length) {
      jumpTo(matches[activeIdx].from, matches[activeIdx].to);
    }
  }, [activeIdx, matches, jumpTo]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        if (e.shiftKey) {
          if (visible) onClose();
        } else if (!visible) {
          // parent handles opening
        }
      }
      if (e.key === "Escape" && visible) {
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [visible, onClose]);

  if (!visible) return null;

  return (
    <div className="absolute left-1/2 top-2 z-30 -translate-x-1/2 rounded-xl border border-slate-200 bg-white/95 p-3 shadow-2xl shadow-black/10 backdrop-blur-lg">
      <div className="mb-2 flex items-center gap-1">
        <button
          type="button"
          onClick={() => setShowReplace(!showReplace)}
          className={cn(
            "rounded-md px-2 py-1 text-xs font-medium transition",
            showReplace
              ? "bg-indigo-50 text-indigo-700"
              : "text-slate-500 hover:bg-slate-100"
          )}
        >
          Replace
        </button>
        <div className="ml-auto flex items-center gap-0.5">
          <button
            type="button"
            onClick={() => setCaseSensitive(!caseSensitive)}
            className={cn(
              "rounded-md p-1.5 text-xs transition",
              caseSensitive
                ? "bg-indigo-50 text-indigo-700"
                : "text-slate-400 hover:bg-slate-100"
            )}
            title="Match case"
          >
            <CaseSensitive className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setWholeWord(!wholeWord)}
            className={cn(
              "rounded-md p-1.5 text-xs transition",
              wholeWord
                ? "bg-indigo-50 text-indigo-700"
                : "text-slate-400 hover:bg-slate-100"
            )}
            title="Whole word"
          >
            <WholeWord className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            className="ml-1 rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                if (e.shiftKey) {
                  setActiveIdx((i) => (i <= 0 ? matches.length - 1 : i - 1));
                } else {
                  setActiveIdx((i) => (i >= matches.length - 1 ? 0 : i + 1));
                }
              }
            }}
            placeholder="Find…"
            className="w-64 rounded-lg border border-slate-200 py-1.5 pl-8 pr-3 text-sm outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>
        <div className="min-w-[5rem] text-center text-xs text-slate-500">
          {matches.length > 0
            ? `${activeIdx + 1} of ${matches.length}`
            : query
              ? "No results"
              : ""}
        </div>
        <button
          type="button"
          onClick={() => setActiveIdx((i) => (i <= 0 ? matches.length - 1 : i - 1))}
          disabled={!matches.length}
          className="rounded-md p-1 text-slate-500 hover:bg-slate-100 disabled:opacity-30"
        >
          <ChevronUp className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => setActiveIdx((i) => (i >= matches.length - 1 ? 0 : i + 1))}
          disabled={!matches.length}
          className="rounded-md p-1 text-slate-500 hover:bg-slate-100 disabled:opacity-30"
        >
          <ChevronDown className="h-4 w-4" />
        </button>
      </div>

      {showReplace && (
        <div className="mt-2 flex items-center gap-2">
          <div className="relative">
            <Replace className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              value={replacement}
              onChange={(e) => setReplacement(e.target.value)}
              placeholder="Replace with…"
              className="w-64 rounded-lg border border-slate-200 py-1.5 pl-8 pr-3 text-sm outline-none focus:border-indigo-400"
            />
          </div>
          <button
            type="button"
            disabled={activeIdx < 0}
            onClick={() => {
              const m = matches[activeIdx];
              if (m) {
                replaceText(m.from, m.to, replacement);
                findMatches();
              }
            }}
            className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40"
            title="Replace"
          >
            <Replace className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            disabled={!matches.length}
            onClick={() => {
              const text = getText();
              if (!query || !matches.length) return;
              let offset = 0;
              for (const m of matches) {
                const from = m.from + offset;
                const to = m.to + offset;
                replaceText(from, to, replacement);
                offset += replacement.length - (to - from);
              }
              findMatches();
            }}
            className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40"
            title="Replace all"
          >
            <ReplaceAll className="h-3.5 w-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
