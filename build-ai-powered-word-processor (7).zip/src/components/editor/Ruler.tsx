"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

export function Ruler({
  marginLeft,
  marginRight,
  onMarginsChange,
  onInsertTab,
}: {
  marginLeft: number;
  marginRight: number;
  onMarginsChange: (left: number, right: number) => void;
  onInsertTab: (x: number) => void;
}) {
  const [dragging, setDragging] = useState<"left" | "right" | null>(null);
  const [hoverTick, setHoverTick] = useState<number | null>(null);
  const pageWidth = 816;
  const marginLeftPx = marginLeft * 96;
  const marginRightPx = marginRight * 96;

  const handleMouseDown = (side: "left" | "right") => (e: React.MouseEvent) => {
    e.preventDefault();
    setDragging(side);

    const onMove = (ev: MouseEvent) => {
      const ruler = (e.target as HTMLElement).closest(".ruler-container");
      if (!ruler) return;
      const rect = ruler.getBoundingClientRect();
      const x = Math.max(0, Math.min(ev.clientX - rect.left, pageWidth));
      if (side === "left") {
        const leftIn = Math.max(0.25, Math.min(4, x / 96));
        onMarginsChange(leftIn, marginRight);
      } else {
        const rightIn = Math.max(0.25, Math.min(4, (pageWidth - x) / 96));
        onMarginsChange(marginLeft, rightIn);
      }
    };
    const onUp = () => {
      setDragging(null);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    const ruler = (e.target as HTMLElement).closest(".ruler-container");
    if (!ruler) return;
    const rect = ruler.getBoundingClientRect();
    const x = e.clientX - rect.left;
    onInsertTab(x);
  };

  const inches: number[] = [];
  const maxInches = Math.ceil(pageWidth / 96);
  for (let i = 0; i <= maxInches; i++) inches.push(i);

  return (
    <div className="mx-auto mb-0" style={{ width: pageWidth, maxWidth: "calc(100% - 2rem)" }}>
      <div
        className="ruler-container relative h-6 select-none cursor-default border-b border-slate-200 bg-gradient-to-b from-slate-50 to-white"
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const tick = Math.round(x / 24) * 8;
          setHoverTick(tick);
        }}
        onMouseLeave={() => setHoverTick(null)}
        onDoubleClick={handleDoubleClick}
      >
        {/* Inch numbers */}
        {inches.map((inch) => (
          <div
            key={inch}
            className="absolute top-0 h-full flex items-end pointer-events-none"
            style={{ left: inch * 96, transform: "translateX(-50%)" }}
          >
            <span className="text-[8px] text-slate-400 mb-0.5 select-none">{inch}</span>
          </div>
        ))}

        {/* Major ticks every 96px, minor every 24px */}
        {Array.from({ length: maxInches * 4 + 1 }).map((_, i) => {
          const x = i * 24;
          const isMajor = i % 4 === 0;
          const isMid = i % 2 === 0 && !isMajor;
          const isActive = hoverTick !== null && Math.abs(hoverTick - x) < 4;
          return (
            <div
              key={i}
              className={cn(
                "absolute bottom-0 w-px transition-colors",
                isMajor ? "h-2.5 bg-slate-400" : isMid ? "h-1.5 bg-slate-300" : "h-1 bg-slate-200",
                isActive && "bg-indigo-400"
              )}
              style={{ left: x }}
            />
          );
        })}

        {/* Left margin handle */}
        <div
          className={cn(
            "absolute top-0 h-full cursor-ew-resize transition-colors",
            dragging === "left" ? "bg-indigo-200" : "bg-indigo-100/60 hover:bg-indigo-200"
          )}
          style={{ left: 0, width: marginLeftPx }}
          onMouseDown={handleMouseDown("left")}
          title="Left margin"
        >
          <div className="absolute right-0 top-0 h-full w-1 bg-indigo-400" />
        </div>

        {/* Right margin handle */}
        <div
          className={cn(
            "absolute top-0 h-full cursor-ew-resize transition-colors",
            dragging === "right" ? "bg-indigo-200" : "bg-indigo-100/60 hover:bg-indigo-200"
          )}
          style={{ left: pageWidth - marginRightPx, width: marginRightPx }}
          onMouseDown={handleMouseDown("right")}
          title="Right margin"
        >
          <div className="absolute left-0 top-0 h-full w-1 bg-indigo-400" />
        </div>
      </div>
    </div>
  );
}
