"use client";

import { Editor } from "@tiptap/react";
import {
  Plus,
  Trash2,
  Columns,
  Rows,
  Merge,
  Split,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
} from "lucide-react";
import { chain } from "@/lib/tiptap-commands";
import { cn } from "@/lib/utils";

function TBtn({
  onClick,
  title,
  children,
}: {
  onClick?: () => void;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      title={title}
      onMouseDown={(e) => {
        e.preventDefault();
        onClick?.();
      }}
      className="inline-flex h-7 items-center gap-1 rounded-md px-2 text-[11px] text-slate-600 hover:bg-slate-100"
    >
      {children}
    </button>
  );
}

export function TableControls({ editor }: { editor: Editor | null }) {
  if (!editor || !editor.isActive("table")) return null;

  return (
    <div className="flex flex-wrap items-center gap-0.5 border-b border-slate-200 bg-amber-50/60 px-2 py-1">
      <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-amber-800">
        Table
      </span>
      <TBtn title="Add row above" onClick={() => chain(editor).addRowBefore().run()}>
        <ArrowUp className="h-3 w-3" /> Row
      </TBtn>
      <TBtn title="Add row below" onClick={() => chain(editor).addRowAfter().run()}>
        <ArrowDown className="h-3 w-3" /> Row
      </TBtn>
      <TBtn title="Add column left" onClick={() => chain(editor).addColumnBefore().run()}>
        <ArrowLeft className="h-3 w-3" /> Col
      </TBtn>
      <TBtn title="Add column right" onClick={() => chain(editor).addColumnAfter().run()}>
        <ArrowRight className="h-3 w-3" /> Col
      </TBtn>
      <div className="mx-1 h-5 w-px bg-amber-200" />
      <TBtn title="Merge cells" onClick={() => chain(editor).mergeCells().run()}>
        <Merge className="h-3 w-3" /> Merge
      </TBtn>
      <TBtn title="Split cell" onClick={() => chain(editor).splitCell().run()}>
        <Split className="h-3 w-3" /> Split
      </TBtn>
      <TBtn
        title="Toggle header row"
        onClick={() => chain(editor).toggleHeaderRow().run()}
      >
        <Rows className="h-3 w-3" /> Header
      </TBtn>
      <TBtn
        title="Toggle header column"
        onClick={() => chain(editor).toggleHeaderColumn().run()}
      >
        <Columns className="h-3 w-3" /> Header col
      </TBtn>
      <div className="mx-1 h-5 w-px bg-amber-200" />
      <TBtn title="Delete row" onClick={() => chain(editor).deleteRow().run()}>
        <Trash2 className="h-3 w-3 text-rose-600" /> Del row
      </TBtn>
      <TBtn title="Delete column" onClick={() => chain(editor).deleteColumn().run()}>
        <Trash2 className="h-3 w-3 text-rose-600" /> Del col
      </TBtn>
      <TBtn title="Delete table" onClick={() => chain(editor).deleteTable().run()}>
        <Trash2 className="h-3 w-3 text-rose-600" /> Delete
      </TBtn>
    </div>
  );
}

export function CaseChangeMenu({ editor }: { editor: Editor | null }) {
  if (!editor) return null;

  const apply = (fn: (s: string) => string) => {
    const { from, to } = editor.state.selection;
    if (from === to) return;
    const text = editor.state.doc.textBetween(from, to, "");
    const transformed = fn(text);
    editor.chain().focus().insertContentAt({ from, to }, transformed).run();
  };

  const cases: { label: string; fn: (s: string) => string }[] = [
    { label: "UPPERCASE", fn: (s) => s.toUpperCase() },
    { label: "lowercase", fn: (s) => s.toLowerCase() },
    { label: "Title Case", fn: (s) => s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()) },
    { label: "Sentence case", fn: (s) => s.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g, (c) => c.toUpperCase()) },
    { label: "tOGGLE cASE", fn: (s) => s.split("").map((c) => (c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase())).join("") },
  ];

  return (
    <div className="relative">
      <button
        type="button"
        className="inline-flex h-8 items-center gap-1 rounded-md px-2 text-xs text-slate-600 hover:bg-slate-100"
        onClick={(e) => {
          const menu = e.currentTarget.nextElementSibling as HTMLElement | null;
          if (menu) menu.style.display = menu.style.display === "block" ? "none" : "block";
        }}
        title="Change case"
      >
        Aa
      </button>
      <div
        className="absolute left-0 top-full z-50 mt-1 hidden w-40 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"
        style={{ display: "none" }}
      >
        {cases.map((c) => (
          <button
            key={c.label}
            type="button"
            onMouseDown={(e) => {
              e.preventDefault();
              apply(c.fn);
              (e.currentTarget.parentElement as HTMLElement).style.display = "none";
            }}
            className="block w-full px-3 py-2 text-left text-xs hover:bg-slate-50"
          >
            {c.label}
          </button>
        ))}
      </div>
    </div>
  );
}
