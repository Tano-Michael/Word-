"use client";

import type { Editor } from "@tiptap/react";
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  Strikethrough,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Link2,
  ImageIcon,
  Table as TableIcon,
  Quote,
  Code,
  Undo2,
  Redo2,
  Highlighter,
  Minus,
  RemoveFormatting,
  CheckSquare,
  Pilcrow,
  Type,
  Subscript as SubscriptIcon,
  Superscript,
  ImagePlus,
  Upload,
  Columns,
  IndentDecrease,
  ArrowDownAZ,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { chain, can } from "@/lib/tiptap-commands";

function Btn({
  onClick,
  active,
  disabled,
  title,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onMouseDown={(e) => {
        e.preventDefault();
        onClick?.();
      }}
      className={cn(
        "inline-flex h-8 w-8 items-center justify-center rounded-md text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 disabled:opacity-40",
        active && "bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200"
      )}
    >
      {children}
    </button>
  );
}

function Divider() {
  return <div className="mx-1 h-6 w-px bg-slate-200" />;
}

export function Toolbar({
  editor,
  fontSize,
  onFontSize,
}: {
  editor: Editor | null;
  fontSize: string;
  onFontSize: (v: string) => void;
}) {
  if (!editor) {
    return (
      <div className="flex h-12 items-center border-b border-slate-200 bg-white px-3 text-sm text-slate-400">
        Loading toolbar…
      </div>
    );
  }

  const setLink = () => {
    const prev = editor.getAttributes("link").href as string | undefined;
    const url = window.prompt("Link URL", prev || "https://");
    if (url === null) return;
    if (url === "") {
      chain(editor).extendMarkRange("link").unsetLink().run();
      return;
    }
    chain(editor).extendMarkRange("link").setLink({ href: url }).run();
  };

  const addImage = () => {
    const url = window.prompt("Image URL");
    if (!url) return;
    chain(editor).setImage({ src: url }).run();
  };

  const insertTable = () => {
    chain(editor).insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
  };

  return (
    <div className="flex flex-wrap items-center gap-0.5 border-b border-slate-200 bg-white/95 px-2 py-1.5 backdrop-blur">
      <Btn
        title="Undo"
        onClick={() => chain(editor).undo().run()}
        disabled={!can(editor).undo()}
      >
        <Undo2 className="h-4 w-4" />
      </Btn>
      <Btn
        title="Redo"
        onClick={() => chain(editor).redo().run()}
        disabled={!can(editor).redo()}
      >
        <Redo2 className="h-4 w-4" />
      </Btn>
      <Divider />

      {/* Font family — reads the actual mark, writes with focus preserved */}
      <select
        className="h-8 rounded-md border border-slate-200 bg-white px-2 text-sm text-slate-700 outline-none focus:border-indigo-400"
        value={
          (editor.getAttributes("textStyle").fontFamily as string) || "__default"
        }
        onChange={(e) => {
          const value = e.target.value;
          if (value === "__default") {
            chain(editor).unsetFontFamily().run();
          } else {
            chain(editor).setFontFamily(value).run();
          }
        }}
        onMouseDown={(e) => e.stopPropagation()}
        title="Font family (applies to selection)"
      >
        <option value="__default">Default (Inter)</option>
        <option value="Inter, system-ui, sans-serif">Inter</option>
        <option value="Georgia, serif">Georgia</option>
        <option value="'Times New Roman', Times, serif">Times New Roman</option>
        <option value="Arial, Helvetica, sans-serif">Arial</option>
        <option value="Calibri, 'Helvetica Neue', Arial, sans-serif">Calibri</option>
        <option value="Cambria, Georgia, serif">Cambria</option>
        <option value="'Courier New', monospace">Courier New</option>
        <option value="Verdana, Geneva, sans-serif">Verdana</option>
        <option value="'Trebuchet MS', sans-serif">Trebuchet</option>
        <option value="Garamond, Baskerville, serif">Garamond</option>
        <option value="'Segoe UI', Roboto, sans-serif">Segoe UI</option>
        <option value="'Helvetica Neue', Helvetica, Arial, sans-serif">Helvetica</option>
        <option value="'Book Antiqua', Palatino, serif">Book Antiqua</option>
        <option value="Consolas, 'Courier New', monospace">Consolas</option>
      </select>

      {/* Font size — installs a real TipTap FontSize mark on the selection.
          Also mirrors to the outer state so the wrapper CSS default matches. */}
      <select
        className="h-8 rounded-md border border-slate-200 bg-white px-2 text-sm text-slate-700 outline-none focus:border-indigo-400"
        value={
          (editor.getAttributes("textStyle").fontSize as string) || fontSize
        }
        onChange={(e) => {
          const value = e.target.value;
          chain(editor).setFontSize(value).run();
          onFontSize(value);
        }}
        onMouseDown={(e) => e.stopPropagation()}
        title="Font size (applies to selection)"
      >
        {[
          "10px", "11px", "12px", "13px", "14px", "15px", "16px", "17px", "18px",
          "20px", "22px", "24px", "26px", "28px", "32px", "36px", "40px", "48px",
          "56px", "64px", "72px",
        ].map((s) => (
          <option key={s} value={s}>
            {s.replace("px", "")}
          </option>
        ))}
      </select>

      <Divider />

      <Btn
        title="Bold"
        active={editor.isActive("bold")}
        onClick={() => chain(editor).toggleBold().run()}
      >
        <Bold className="h-4 w-4" />
      </Btn>
      <Btn
        title="Italic"
        active={editor.isActive("italic")}
        onClick={() => chain(editor).toggleItalic().run()}
      >
        <Italic className="h-4 w-4" />
      </Btn>
      <Btn
        title="Underline"
        active={editor.isActive("underline")}
        onClick={() => chain(editor).toggleUnderline().run()}
      >
        <UnderlineIcon className="h-4 w-4" />
      </Btn>
      <Btn
        title="Strikethrough"
        active={editor.isActive("strike")}
        onClick={() => chain(editor).toggleStrike().run()}
      >
        <Strikethrough className="h-4 w-4" />
      </Btn>
      <Btn
        title="Highlight"
        active={editor.isActive("highlight")}
        onClick={() => chain(editor).toggleHighlight().run()}
      >
        <Highlighter className="h-4 w-4" />
      </Btn>

      <label
        className="relative inline-flex h-8 w-8 cursor-pointer items-center justify-center rounded-md hover:bg-slate-100"
        title="Text color"
      >
        <Type className="h-4 w-4 text-slate-600" />
        <input
          type="color"
          className="absolute inset-0 cursor-pointer opacity-0"
          onChange={(e) => chain(editor).setColor(e.target.value).run()}
        />
      </label>

      <Divider />

      <Btn
        title="Paragraph"
        active={editor.isActive("paragraph")}
        onClick={() => chain(editor).setParagraph().run()}
      >
        <Pilcrow className="h-4 w-4" />
      </Btn>
      <Btn
        title="Heading 1"
        active={editor.isActive("heading", { level: 1 })}
        onClick={() => chain(editor).toggleHeading({ level: 1 }).run()}
      >
        <Heading1 className="h-4 w-4" />
      </Btn>
      <Btn
        title="Heading 2"
        active={editor.isActive("heading", { level: 2 })}
        onClick={() => chain(editor).toggleHeading({ level: 2 }).run()}
      >
        <Heading2 className="h-4 w-4" />
      </Btn>
      <Btn
        title="Heading 3"
        active={editor.isActive("heading", { level: 3 })}
        onClick={() => chain(editor).toggleHeading({ level: 3 }).run()}
      >
        <Heading3 className="h-4 w-4" />
      </Btn>

      <Divider />

      <Btn
        title="Bullet list"
        active={editor.isActive("bulletList")}
        onClick={() => chain(editor).toggleBulletList().run()}
      >
        <List className="h-4 w-4" />
      </Btn>
      <Btn
        title="Numbered list"
        active={editor.isActive("orderedList")}
        onClick={() => chain(editor).toggleOrderedList().run()}
      >
        <ListOrdered className="h-4 w-4" />
      </Btn>
      <Btn
        title="Task list"
        active={editor.isActive("taskList")}
        onClick={() => chain(editor).toggleTaskList().run()}
      >
        <CheckSquare className="h-4 w-4" />
      </Btn>
      <Btn
        title="Quote"
        active={editor.isActive("blockquote")}
        onClick={() => chain(editor).toggleBlockquote().run()}
      >
        <Quote className="h-4 w-4" />
      </Btn>
      <Btn
        title="Code block"
        active={editor.isActive("codeBlock")}
        onClick={() => chain(editor).toggleCodeBlock().run()}
      >
        <Code className="h-4 w-4" />
      </Btn>
      <Btn
        title="Horizontal rule"
        onClick={() => chain(editor).setHorizontalRule().run()}
      >
        <Minus className="h-4 w-4" />
      </Btn>

      <Divider />

      <Btn
        title="Align left"
        active={editor.isActive({ textAlign: "left" })}
        onClick={() => chain(editor).setTextAlign("left").run()}
      >
        <AlignLeft className="h-4 w-4" />
      </Btn>
      <Btn
        title="Align center"
        active={editor.isActive({ textAlign: "center" })}
        onClick={() => chain(editor).setTextAlign("center").run()}
      >
        <AlignCenter className="h-4 w-4" />
      </Btn>
      <Btn
        title="Align right"
        active={editor.isActive({ textAlign: "right" })}
        onClick={() => chain(editor).setTextAlign("right").run()}
      >
        <AlignRight className="h-4 w-4" />
      </Btn>
      <Btn
        title="Justify"
        active={editor.isActive({ textAlign: "justify" })}
        onClick={() => chain(editor).setTextAlign("justify").run()}
      >
        <AlignJustify className="h-4 w-4" />
      </Btn>

      <Divider />

      <Btn title="Link" active={editor.isActive("link")} onClick={setLink}>
        <Link2 className="h-4 w-4" />
      </Btn>
      <Btn title="Image" onClick={addImage}>
        <ImageIcon className="h-4 w-4" />
      </Btn>
      <Btn title="Table" onClick={insertTable}>
        <TableIcon className="h-4 w-4" />
      </Btn>
      <Btn
        title="Subscript"
        active={editor.isActive("subscript")}
        onClick={() => chain(editor).toggleSubscript().run()}
      >
        <SubscriptIcon className="h-4 w-4" />
      </Btn>
      <Btn
        title="Superscript"
        active={editor.isActive("superscript")}
        onClick={() => chain(editor).toggleSuperscript().run()}
      >
        <Superscript className="h-4 w-4" />
      </Btn>

      <Divider />

      {/* Line spacing — real mark, applies to selected paragraph(s) */}
      <select
        className="h-8 rounded-md border border-slate-200 bg-white px-2 text-sm text-slate-700 outline-none focus:border-indigo-400"
        value={
          (editor.getAttributes("textStyle").lineHeight as string) || "__default"
        }
        onChange={(e) => {
          const value = e.target.value;
          if (value === "__default") {
            chain(editor).unsetLineHeight().run();
          } else {
            chain(editor).setLineHeight(value).run();
          }
        }}
        onMouseDown={(e) => e.stopPropagation()}
        title="Line spacing"
      >
        <option value="__default">Line spacing</option>
        <option value="1">Single (1.0)</option>
        <option value="1.15">1.15</option>
        <option value="1.5">1.5</option>
        <option value="2">Double (2.0)</option>
        <option value="2.5">2.5</option>
        <option value="3">Triple (3.0)</option>
      </select>

      <Btn
        title="Upload image from file"
        onClick={() => {
          const input = document.createElement("input");
          input.type = "file";
          input.accept = "image/*";
          input.onchange = async () => {
            const file = input.files?.[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
              const base64 = reader.result as string;
              chain(editor).setImage({ src: base64 }).run();
            };
            reader.readAsDataURL(file);
          };
          input.click();
        }}
      >
        <ImagePlus className="h-4 w-4" />
      </Btn>

      <Btn
        title="Clear formatting"
        onClick={() => chain(editor).unsetAllMarks().clearNodes().run()}
      >
        <RemoveFormatting className="h-4 w-4" />
      </Btn>

      {/* Case change dropdown */}
      <div className="relative">
        <button
          type="button"
          title="Change case"
          onClick={(e) => {
            const menu = e.currentTarget.nextElementSibling as HTMLElement | null;
            if (menu) menu.style.display = menu.style.display === "block" ? "none" : "block";
          }}
          className="inline-flex h-8 items-center rounded-md px-2 text-sm font-semibold text-slate-600 hover:bg-slate-100"
        >
          Aa
        </button>
        <div
          className="absolute right-0 top-full z-50 mt-1 hidden w-40 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl"
          style={{ display: "none" }}
          onMouseLeave={(e) => (e.currentTarget.style.display = "none")}
        >
          {[
            { label: "UPPERCASE", fn: (s: string) => s.toUpperCase() },
            { label: "lowercase", fn: (s: string) => s.toLowerCase() },
            { label: "Title Case", fn: (s: string) => s.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()) },
            { label: "Sentence case", fn: (s: string) => s.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g, (c) => c.toUpperCase()) },
            { label: "tOGGLE cASE", fn: (s: string) => s.split("").map((c) => (c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase())).join("") },
          ].map((c) => (
            <button
              key={c.label}
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                const { from, to } = editor.state.selection;
                if (from !== to) {
                  const text = editor.state.doc.textBetween(from, to, "");
                  chain(editor).insertContentAt({ from, to }, c.fn(text)).run();
                }
                (e.currentTarget.parentElement as HTMLElement).style.display = "none";
              }}
              className="block w-full px-3 py-2 text-left text-xs hover:bg-slate-50"
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      <button
        type="button"
        title="Split view (side-by-side draft)"
        onClick={() => {
          const { from, to } = editor.state.selection;
          if (from !== to) {
            const text = editor.state.doc.textBetween(from, to, " ");
            if (text.trim()) {
              editor.chain().focus().setTextSelection(from).insertContent(`<h2>Split Draft</h2><blockquote><p style="font-style:italic;color:#475569;font-family:Georgia,serif">Parallel version based on selection.</p><p>${text.trim()}</p></blockquote>`).run();
            }
          }
        }}
        className="inline-flex items-center gap-1 rounded-md px-2 text-[11px] text-slate-500 hover:bg-slate-100"
      >
        <Columns className="h-3.5 w-3.5" /> Split
      </button>

      <Divider />

      <Btn
        title="Hanging indent (for references / bibliography)"
        active={!!editor.getAttributes("paragraph").hangingIndent}
        onClick={() => chain(editor).toggleHangingIndent().run()}
      >
        <IndentDecrease className="h-4 w-4" />
      </Btn>
      <button
        type="button"
        title="Sort selected paragraphs A→Z (alphabetize references)"
        onMouseDown={(e) => {
          e.preventDefault();
          chain(editor).sortParagraphsAlphabetically(false).run();
        }}
        className="inline-flex items-center gap-1 rounded-md px-2 text-[11px] text-slate-500 hover:bg-slate-100"
      >
        <ArrowDownAZ className="h-3.5 w-3.5" /> A–Z
      </button>

      <span className="ml-auto hidden text-[11px] text-slate-400 sm:inline">
        Pro writing mode
      </span>
    </div>
  );
}
