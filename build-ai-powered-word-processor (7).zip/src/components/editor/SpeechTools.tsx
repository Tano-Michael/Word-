"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { Editor } from "@tiptap/react";
import {
  Volume2,
  Mic,
  MicOff,
  ChevronDown,
  Search,
  Play,
  Check,
  RefreshCw,
  Globe,
  Monitor,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* eslint-disable @typescript-eslint/no-explicit-any */

/** Higher score = more natural / preferred. */
function rankVoice(voice: SpeechSynthesisVoice): number {
  const name = voice.name.toLowerCase();
  let score = 0;
  if (!voice.localService) score += 60; // cloud/online voices
  if (/natural|neural/.test(name)) score += 40;
  if (/online/.test(name)) score += 25;
  if (/google|microsoft|cloud|premium|enhanced|siri/.test(name)) score += 20;
  if (voice.lang.toLowerCase().startsWith("en-us")) score += 8;
  if (voice.lang.toLowerCase().startsWith("en")) score += 4;
  if (voice.default) score += 2;
  return score;
}

function isNaturalVoice(voice: SpeechSynthesisVoice): boolean {
  const name = voice.name.toLowerCase();
  return (
    !voice.localService ||
    /natural|neural|online|google|cloud|premium|enhanced/.test(name)
  );
}

/** Human-friendly language label, e.g. "en-US" -> "English (United States)". */
function languageLabel(tag: string): string {
  try {
    const dn = new Intl.DisplayNames(undefined, { type: "language" });
    return dn.of(tag) || tag;
  } catch {
    return tag;
  }
}

export function SpeechTools({ editor }: { editor: Editor | null }) {
  const [isReading, setIsReading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [ttsSupported, setTtsSupported] = useState(false);
  const [sttSupported, setSttSupported] = useState(false);

  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceUri, setVoiceUri] = useState("");
  const [showVoices, setShowVoices] = useState(false);
  const [query, setQuery] = useState("");
  const [langFilter, setLangFilter] = useState("all");
  const [reloadTick, setReloadTick] = useState(0);
  const [panelPos, setPanelPos] = useState<{ top: number; left: number } | null>(null);

  const recognitionRef = useRef<any>(null);
  const manualStopRef = useRef(false);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);

  // Detect support on the client only (avoids SSR/hydration mismatch).
  useEffect(() => {
    setTtsSupported(typeof window !== "undefined" && "speechSynthesis" in window);
    setSttSupported(
      typeof window !== "undefined" &&
        ("webkitSpeechRecognition" in window || "SpeechRecognition" in (window as any))
    );
  }, []);

  /**
   * Chrome/Edge populate voices asynchronously and sometimes fire
   * `voiceschanged` more than once. Poll until the list stops growing so we
   * never show a truncated list (this was the "only one natural voice" bug).
   */
  useEffect(() => {
    if (!ttsSupported) return;

    let cancelled = false;
    let attempts = 0;
    let lastCount = -1;
    let stableRounds = 0;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const collect = () => {
      if (cancelled) return;
      const list = window.speechSynthesis.getVoices();
      if (list.length !== lastCount) {
        lastCount = list.length;
        stableRounds = 0;
        setVoices([...list]);
      } else if (list.length > 0) {
        stableRounds += 1;
      }
      attempts += 1;
      // Keep polling until the count is stable for 3 rounds, or ~6s elapsed.
      if (stableRounds < 3 && attempts < 24) {
        timer = setTimeout(collect, 250);
      }
    };

    const onChanged = () => {
      lastCount = -1;
      stableRounds = 0;
      attempts = 0;
      collect();
    };

    collect();
    window.speechSynthesis.addEventListener("voiceschanged", onChanged);
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
      window.speechSynthesis.removeEventListener("voiceschanged", onChanged);
    };
  }, [ttsSupported, reloadTick]);

  // Restore or choose a sensible default voice once voices arrive.
  useEffect(() => {
    if (!voices.length) return;
    setVoiceUri((current) => {
      if (current && voices.some((v) => v.voiceURI === current)) return current;
      const stored =
        typeof window !== "undefined"
          ? localStorage.getItem("aether-speech-voice")
          : null;
      if (stored && voices.some((v) => v.voiceURI === stored)) return stored;
      const best = [...voices].sort((a, b) => rankVoice(b) - rankVoice(a))[0];
      return best?.voiceURI ?? "";
    });
  }, [voices]);

  // Cleanup
  useEffect(() => {
    return () => {
      manualStopRef.current = true;
      try {
        recognitionRef.current?.stop();
      } catch {
        /* ignore */
      }
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Close the voice panel on outside click / Escape
  useEffect(() => {
    if (!showVoices) return;
    const onDown = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setShowVoices(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setShowVoices(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [showVoices]);

  const languages = useMemo(() => {
    const set = new Map<string, number>();
    for (const v of voices) {
      const base = v.lang || "unknown";
      set.set(base, (set.get(base) ?? 0) + 1);
    }
    return [...set.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [voices]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return voices
      .filter((v) => (langFilter === "all" ? true : v.lang === langFilter))
      .filter((v) =>
        q
          ? v.name.toLowerCase().includes(q) ||
            v.lang.toLowerCase().includes(q) ||
            languageLabel(v.lang).toLowerCase().includes(q)
          : true
      )
      .sort((a, b) => rankVoice(b) - rankVoice(a));
  }, [voices, query, langFilter]);

  const naturalVoices = useMemo(() => filtered.filter(isNaturalVoice), [filtered]);
  const systemVoices = useMemo(
    () => filtered.filter((v) => !isNaturalVoice(v)),
    [filtered]
  );

  const selectedVoice =
    voices.find((v) => v.voiceURI === voiceUri) ||
    [...voices].sort((a, b) => rankVoice(b) - rankVoice(a))[0];

  const speak = useCallback(
    (text: string, voice?: SpeechSynthesisVoice) => {
      if (!("speechSynthesis" in window)) return;
      const utterance = new SpeechSynthesisUtterance(text);
      const chosen = voice || selectedVoice;
      if (chosen) {
        utterance.voice = chosen;
        utterance.lang = chosen.lang;
      }
      utterance.rate = 0.96;
      utterance.pitch = 1;
      utterance.onend = () => setIsReading(false);
      utterance.onerror = () => setIsReading(false);
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    },
    [selectedVoice]
  );

  const readAloud = useCallback(() => {
    if (!editor || !("speechSynthesis" in window)) return;
    if (isReading) {
      window.speechSynthesis.cancel();
      setIsReading(false);
      return;
    }
    const { from, to } = editor.state.selection;
    const selected = from !== to ? editor.state.doc.textBetween(from, to, " ") : "";
    const text = (selected || editor.getText()).trim();
    if (!text) return;
    speak(text);
    setIsReading(true);
  }, [editor, isReading, speak]);

  const startDictation = useCallback(() => {
    if (!editor) return;
    const SpeechRecognition =
      (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognition) return;

    manualStopRef.current = false;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.lang = selectedVoice?.lang || "en-US";
    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      let finalChunk = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) finalChunk += event.results[i][0].transcript;
      }
      if (finalChunk.trim()) editor.commands.insertContent(finalChunk.trim() + " ");
    };
    recognition.onerror = (event: any) => {
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        manualStopRef.current = true;
        setIsListening(false);
      }
    };
    recognition.onend = () => {
      if (manualStopRef.current) {
        setIsListening(false);
        return;
      }
      try {
        recognition.start();
      } catch {
        setIsListening(false);
      }
    };
    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsListening(true);
    } catch {
      setIsListening(false);
    }
  }, [editor, selectedVoice]);

  const stopDictation = useCallback(() => {
    manualStopRef.current = true;
    try {
      recognitionRef.current?.stop();
      recognitionRef.current?.abort?.();
    } catch {
      /* ignore */
    }
    recognitionRef.current = null;
    setIsListening(false);
  }, []);

  const chooseVoice = (uri: string) => {
    setVoiceUri(uri);
    localStorage.setItem("aether-speech-voice", uri);
  };

  if (!ttsSupported && !sttSupported) return null;

  const renderVoiceRow = (voice: SpeechSynthesisVoice) => {
    const active = voice.voiceURI === voiceUri;
    return (
      <div
        key={voice.voiceURI}
        className={cn(
          "flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs transition",
          active ? "bg-indigo-50 text-indigo-700" : "hover:bg-slate-50 text-slate-700"
        )}
      >
        <button
          type="button"
          onClick={() => chooseVoice(voice.voiceURI)}
          className="flex min-w-0 flex-1 items-center gap-2 text-left"
          title={`${voice.name} · ${voice.lang}`}
        >
          <span className="w-3.5 shrink-0">
            {active && <Check className="h-3.5 w-3.5" />}
          </span>
          <span className="min-w-0 flex-1 truncate">{voice.name}</span>
          <span className="shrink-0 rounded bg-slate-100 px-1 text-[9px] text-slate-500">
            {voice.lang}
          </span>
        </button>
        <button
          type="button"
          onClick={() => speak("This is how this voice sounds in Aether.", voice)}
          title="Preview this voice"
          className="shrink-0 rounded p-1 text-slate-400 hover:bg-white hover:text-indigo-600"
        >
          <Play className="h-3 w-3" />
        </button>
      </div>
    );
  };

  return (
    <div className="flex items-center gap-1.5">
      {ttsSupported && (
        <>
          <button
            type="button"
            onClick={readAloud}
            title={isReading ? "Stop read aloud" : "Read aloud (selection or whole document)"}
            className={cn(
              "rounded-full p-1.5 transition",
              isReading
                ? "bg-indigo-50 text-indigo-600"
                : "text-slate-400 hover:bg-white hover:text-slate-700"
            )}
          >
            <Volume2 className={cn("h-4 w-4", isReading && "animate-pulse")} />
          </button>

          <div className="relative" ref={panelRef}>
            <button
              ref={buttonRef}
              type="button"
              onClick={() => {
                if (showVoices) {
                  setShowVoices(false);
                  return;
                }
                // Calculate button position so the voice panel renders below it
                // with fixed positioning — never clipped by any parent overflow.
                const rect = buttonRef.current?.getBoundingClientRect();
                if (rect) {
                  setPanelPos({
                    top: rect.bottom + 6,
                    left: Math.max(8, Math.min(rect.left, window.innerWidth - 368)),
                  });
                }
                setShowVoices(true);
              }}
              title={selectedVoice ? `Voice: ${selectedVoice.name}` : "Choose a voice"}
              className="inline-flex max-w-[170px] items-center gap-1 rounded-full bg-slate-50 px-2 py-1 text-[10px] font-medium text-slate-500 hover:bg-white hover:text-slate-700"
            >
              <span className="max-w-[120px] truncate">
                {selectedVoice?.name || "Loading voices…"}
              </span>
              <span className="shrink-0 rounded bg-slate-200 px-1 text-[9px] text-slate-600">
                {voices.length}
              </span>
              <ChevronDown className={cn("h-3 w-3 shrink-0 transition-transform", showVoices && "rotate-180")} />
            </button>

            {showVoices && panelPos && (
              <div
                ref={panelRef}
                className="fixed z-[100] w-[22rem] rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl"
                style={{ top: panelPos.top, left: panelPos.left }}
              >
                <div className="mb-2 flex items-center gap-1.5">
                  <div className="relative flex-1">
                    <Search className="absolute left-2 top-1/2 h-3 w-3 -translate-y-1/2 text-slate-400" />
                    <input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search voices…"
                      className="w-full rounded-lg border border-slate-200 py-1.5 pl-7 pr-2 text-xs outline-none focus:border-indigo-400"
                    />
                  </div>
                  <select
                    value={langFilter}
                    onChange={(e) => setLangFilter(e.target.value)}
                    className="max-w-[7.5rem] rounded-lg border border-slate-200 px-1.5 py-1.5 text-[10px] text-slate-600 outline-none focus:border-indigo-400"
                    title="Filter by language"
                  >
                    <option value="all">All ({voices.length})</option>
                    {languages.map(([lang, count]) => (
                      <option key={lang} value={lang}>
                        {lang} ({count})
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => setReloadTick((t) => t + 1)}
                    title="Reload voice list"
                    className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                  </button>
                </div>

                <div className="max-h-72 overflow-y-auto pr-0.5">
                  {naturalVoices.length > 0 && (
                    <>
                      <p className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-600">
                        <Globe className="h-3 w-3" />
                        Natural / online ({naturalVoices.length})
                      </p>
                      {naturalVoices.map(renderVoiceRow)}
                    </>
                  )}

                  {systemVoices.length > 0 && (
                    <>
                      <p className="mt-1 flex items-center gap-1 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        <Monitor className="h-3 w-3" />
                        System / offline ({systemVoices.length})
                      </p>
                      {systemVoices.map(renderVoiceRow)}
                    </>
                  )}

                  {!filtered.length && (
                    <p className="px-2 py-6 text-center text-xs text-slate-500">
                      {voices.length
                        ? "No voices match your search."
                        : "Loading voices from your browser…"}
                    </p>
                  )}
                </div>

                <p className="mt-2 border-t border-slate-100 px-2 pt-2 text-[10px] leading-relaxed text-slate-400">
                  Voices come from your browser and operating system. For the most
                  natural options on Windows, open Aether in Microsoft Edge, which
                  provides Microsoft Natural (Online) voices.
                </p>
              </div>
            )}
          </div>
        </>
      )}

      {sttSupported && (
        <button
          type="button"
          onClick={() => (isListening ? stopDictation() : startDictation())}
          title={isListening ? "Stop dictation" : "Start dictation — stays on through pauses"}
          className={cn(
            "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold transition",
            isListening
              ? "bg-rose-500 text-white ring-2 ring-rose-200"
              : "text-slate-500 hover:bg-white hover:text-slate-700"
          )}
        >
          {isListening ? (
            <>
              <MicOff className="h-3.5 w-3.5" /> Stop
            </>
          ) : (
            <>
              <Mic className="h-3.5 w-3.5" /> Dictate
            </>
          )}
        </button>
      )}
    </div>
  );
}
