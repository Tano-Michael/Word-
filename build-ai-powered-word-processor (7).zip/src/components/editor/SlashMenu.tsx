"use client";

import { useEffect, useRef, useState } from "react";
import { Editor } from "@tiptap/react";
import {
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  CheckSquare,
  Quote,
  Code,
  Minus,
  Table,
  Image,
  AlignCenter,
  AlignLeft,
  Type,
  Calendar,
  Smile,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

type SlashItem = {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  desc: string;
  run: (editor: Editor) => void;
};

const SLASH_ITEMS: SlashItem[] = [
  { id: "h1", icon: Heading1, label: "Heading 1", desc: "Large section heading", run: (e) => e.chain().focus().setHeading({ level: 1 }).run() },
  { id: "h2", icon: Heading2, label: "Heading 2", desc: "Medium section heading", run: (e) => e.chain().focus().setHeading({ level: 2 }).run() },
  { id: "h3", icon: Heading3, label: "Heading 3", desc: "Small section heading", run: (e) => e.chain().focus().setHeading({ level: 3 }).run() },
  { id: "p", icon: Type, label: "Paragraph", desc: "Plain text", run: (e) => e.chain().focus().setParagraph().run() },
  { id: "ul", icon: List, label: "Bullet list", desc: "Unordered list", run: (e) => e.chain().focus().toggleBulletList().run() },
  { id: "ol", icon: ListOrdered, label: "Numbered list", desc: "Ordered list", run: (e) => e.chain().focus().toggleOrderedList().run() },
  { id: "task", icon: CheckSquare, label: "Task list", desc: "Checkable items", run: (e) => e.chain().focus().toggleTaskList().run() },
  { id: "quote", icon: Quote, label: "Quote", desc: "Block quote", run: (e) => e.chain().focus().toggleBlockquote().run() },
  { id: "code", icon: Code, label: "Code block", desc: "Multi-line code", run: (e) => e.chain().focus().toggleCodeBlock().run() },
  { id: "hr", icon: Minus, label: "Divider", desc: "Horizontal rule", run: (e) => e.chain().focus().setHorizontalRule().run() },
  { id: "table", icon: Table, label: "Table", desc: "3×3 table", run: (e) => e.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run() },
  { id: "image", icon: Image, label: "Image", desc: "From URL", run: (e) => {
    const url = window.prompt("Image URL");
    if (url) e.chain().focus().setImage({ src: url }).run();
  }},
  { id: "align-left", icon: AlignLeft, label: "Align left", desc: "Left align block", run: (e) => e.chain().focus().setTextAlign("left").run() },
  { id: "align-center", icon: AlignCenter, label: "Align center", desc: "Center block", run: (e) => e.chain().focus().setTextAlign("center").run() },
  { id: "date", icon: Calendar, label: "Date", desc: "Insert today", run: (e) => e.chain().focus().insertContent(new Date().toLocaleDateString()).run() },
  { id: "emoji", icon: Smile, label: "Emoji picker", desc: "Common emoji", run: (e) => {
    const emojis = "😀 😃 😄 😁 😆 🙏 👍 👎 ❤️ 🎉 ✅ ❌ ⚠️ 💡 🔥 ⭐ 🚀";
    const choice = window.prompt(`Choose: ${emojis}`);
    if (choice) e.chain().focus().insertContent(choice).run();
  }},
  { id: "ai", icon: Sparkles, label: "AI: Continue", desc: "AI writes next paragraph", run: (e) => {
    const text = e.getText();
    fetch("/api/ai/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "continue", documentText: text }),
    }).then(r => r.json()).then(d => {
      if (d.html) e.chain().focus().insertContent(d.html).run();
    });
  }},
];

export function SlashMenu({
  editor,
  show,
  onClose,
  position,
}: {
  editor: Editor | null;
  show: boolean;
  onClose: () => void;
  position: { top: number; left: number };
}) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!show) {
      setQuery("");
      setSelected(0);
    }
  }, [show]);

  const filtered = SLASH_ITEMS.filter((item) =>
    item.label.toLowerCase().includes(query.toLowerCase()) ||
    item.desc.toLowerCase().includes(query.toLowerCase()) ||
    item.id.includes(query.toLowerCase())
  );

  useEffect(() => {
    if (!show) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelected((s) => (s + 1) % filtered.length);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelected((s) => (s - 1 + filtered.length) % filtered.length);
      } else if (e.key === "Enter") {
        e.preventDefault();
        const item = filtered[selected];
        if (item && editor) {
          // remove the slash + query trigger
          const { from } = editor.state.selection;
          const triggerLen = 1 + query.length;
          editor.chain().focus().deleteRange({ from: from - triggerLen, to: from }).run();
          item.run(editor);
          onClose();
        }
      } else if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [show, filtered, selected, editor, onClose, query]);

  useEffect(() => {
    setSelected(0);
  }, [query]);

  if (!show || !editor) return null;

  return (
    <div
      ref={ref}
      className="fixed z-50 max-h-80 w-72 overflow-y-auto rounded-xl border border-slate-200 bg-white/95 p-1 shadow-2xl shadow-black/15 backdrop-blur-xl"
      style={{ top: position.top, left: position.left }}
      onMouseDown={(e) => e.preventDefault()}
    >
      <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
        Slash commands{query ? ` · ${query}` : ""}
      </div>
      {filtered.length === 0 ? (
        <div className="px-3 py-4 text-center text-xs text-slate-400">No matches</div>
      ) : (
        filtered.map((item, i) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                const { from } = editor.state.selection;
                const triggerLen = 1 + query.length;
                editor.chain().focus().deleteRange({ from: from - triggerLen, to: from }).run();
                item.run(editor);
                onClose();
              }}
              onMouseEnter={() => setSelected(i)}
              className={cn(
                "flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition",
                i === selected ? "bg-indigo-50 text-indigo-900" : "text-slate-700 hover:bg-slate-50"
              )}
            >
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-slate-100 text-slate-600">
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{item.label}</div>
                <div className="truncate text-[10px] text-slate-500">{item.desc}</div>
              </div>
            </button>
          );
        })
      )}
    </div>
  );
}
