"use client";

import { useState } from "react";
import { X, Printer, Ruler } from "lucide-react";
import { cn } from "@/lib/utils";

export type PageSettings = {
  marginLeft: number;
  marginRight: number;
  marginTop: number;
  marginBottom: number;
  pageSize: "letter" | "a4" | "legal";
  orientation: "portrait" | "landscape";
};

const PRESETS: { label: string; settings: Partial<PageSettings> }[] = [
  { label: "Normal", settings: { marginLeft: 1, marginRight: 1, marginTop: 1, marginBottom: 1 } },
  { label: "Narrow", settings: { marginLeft: 0.5, marginRight: 0.5, marginTop: 0.5, marginBottom: 0.5 } },
  { label: "Moderate", settings: { marginLeft: 0.75, marginRight: 0.75, marginTop: 1, marginBottom: 1 } },
  { label: "Wide", settings: { marginLeft: 1.25, marginRight: 1.25, marginTop: 1, marginBottom: 1 } },
];

export function PageSetupDialog({
  open,
  onClose,
  settings,
  onApply,
}: {
  open: boolean;
  onClose: () => void;
  settings: PageSettings;
  onApply: (s: PageSettings) => void;
}) {
  const [local, setLocal] = useState(settings);

  if (!open) return null;

  const set = (k: keyof PageSettings, v: number | string) =>
    setLocal((prev) => ({ ...prev, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-100">
              <Ruler className="h-4 w-4 text-indigo-600" />
            </div>
            <h2 className="text-sm font-semibold text-slate-900">Page setup</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mb-4 flex gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => setLocal((prev) => ({ ...prev, ...p.settings }))}
              className={cn(
                "rounded-lg border px-3 py-1.5 text-xs font-medium transition",
                JSON.stringify(p.settings) ===
                  JSON.stringify({ marginLeft: local.marginLeft, marginRight: local.marginRight, marginTop: local.marginTop, marginBottom: local.marginBottom })
                  ? "border-indigo-300 bg-indigo-50 text-indigo-700"
                  : "border-slate-200 text-slate-600 hover:border-slate-300"
              )}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          {(["marginTop", "marginBottom", "marginLeft", "marginRight"] as const).map((k) => (
            <label key={k} className="block">
              <span className="text-[11px] font-medium text-slate-600">
                {k === "marginTop" ? "Top" : k === "marginBottom" ? "Bottom" : k === "marginLeft" ? "Left" : "Right"} (inches)
              </span>
              <input
                type="number"
                step="0.25"
                min="0.25"
                max="3"
                value={local[k]}
                onChange={(e) => set(k, Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-1.5 text-sm outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20"
              />
            </label>
          ))}

          <label className="block">
            <span className="text-[11px] font-medium text-slate-600">Page size</span>
            <select
              value={local.pageSize}
              onChange={(e) => set("pageSize", e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-1.5 text-sm outline-none focus:border-indigo-400"
            >
              <option value="letter">Letter (8.5″ × 11″)</option>
              <option value="a4">A4 (210 × 297 mm)</option>
              <option value="legal">Legal (8.5″ × 14″)</option>
            </select>
          </label>

          <label className="block">
            <span className="text-[11px] font-medium text-slate-600">Orientation</span>
            <select
              value={local.orientation}
              onChange={(e) => set("orientation", e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-1.5 text-sm outline-none focus:border-indigo-400"
            >
              <option value="portrait">Portrait</option>
              <option value="landscape">Landscape</option>
            </select>
          </label>
        </div>

        {/* Preview */}
        <div className="mt-4 flex justify-center">
          <div
            className={cn(
              "border-2 border-slate-300 bg-white shadow-sm",
              local.orientation === "landscape" ? "h-24 w-32" : "w-24 h-32"
            )}
            style={{
              borderTopWidth: local.marginTop * 16,
              borderBottomWidth: local.marginBottom * 16,
              borderLeftWidth: local.marginLeft * 16,
              borderRightWidth: local.marginRight * 16,
              borderColor: "#e0e7ff",
              borderStyle: "dashed",
            }}
          >
            <div className="flex h-full items-center justify-center text-[8px] text-slate-400">
              Preview
            </div>
          </div>
        </div>

        <div className="mt-5 flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onApply(local);
              onClose();
            }}
            className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500"
          >
            <Printer className="h-3.5 w-3.5" />
            Apply
          </button>
        </div>
      </div>
    </div>
  );
}
