"use client";

import { useEffect, useRef } from "react";

/**
 * Writes a lightweight local snapshot of the current document to
 * localStorage on every edit (throttled). If the last snapshot is
 * newer than the server copy on load, the parent component prompts
 * the user to restore it — so a crash, browser close, or lost
 * network never costs more than a few keystrokes.
 */
export function useLocalSnapshot(
  documentId: string,
  html: string,
  loaded: boolean
) {
  const throttleRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!loaded || !documentId || typeof window === "undefined") return;
    if (throttleRef.current) clearTimeout(throttleRef.current);
    throttleRef.current = setTimeout(() => {
      try {
        const payload = {
          html,
          savedAt: new Date().toISOString(),
        };
        localStorage.setItem(
          `aether:snapshot:${documentId}`,
          JSON.stringify(payload)
        );
      } catch {
        // Storage quota exceeded — ignore silently, this is a nice-to-have
      }
    }, 700);
    return () => {
      if (throttleRef.current) clearTimeout(throttleRef.current);
    };
  }, [documentId, html, loaded]);
}

export function readLocalSnapshot(
  documentId: string
): { html: string; savedAt: string } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(`aether:snapshot:${documentId}`);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function clearLocalSnapshot(documentId: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(`aether:snapshot:${documentId}`);
  } catch {
    /* ignore */
  }
}
