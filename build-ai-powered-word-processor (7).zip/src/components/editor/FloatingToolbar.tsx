"use client";

import { useEffect, useRef, useState } from "react";
import { Editor } from "@tiptap/react";
import { createPortal } from "react-dom";
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Link2,
  Highlighter,
  Code,
  Sparkles,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { chain } from "@/lib/tiptap-commands";

function Btn({
  onClick,
  active,
  title,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      title={title}
      onMouseDown={(e) => {
        e.preventDefault();
        onClick?.();
      }}
      className={cn(
        "inline-flex h-7 w-7 items-center justify-center rounded-md text-slate-600 transition hover:bg-slate-200",
        active && "bg-indigo-100 text-indigo-700"
      )}
    >
      {children}
    </button>
  );
}

export function FloatingToolbar({
  editor,
}: {
  editor: Editor | null;
}) {
  const [pos, setPos] = useState<{ top: number; left: number; visible: boolean }>({
    top: 0,
    left: 0,
    visible: false,
  });
  const [aiMenu, setAiMenu] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!editor) return;
    const update = () => {
      const { from, to, empty } = editor.state.selection;
      if (empty || from === to) {
        setPos((p) => ({ ...p, visible: false }));
        return;
      }
      const view = editor.view;
      const start = view.coordsAtPos(from);
      const end = view.coordsAtPos(to);
      const rect = {
        top: Math.min(start.top, end.top),
        left: (start.left + end.left) / 2,
      };
      setPos({ top: rect.top - 52, left: rect.left, visible: true });
    };

    const handler = () => update();
    editor.on("selectionUpdate", handler);
    return () => {
      editor.off("selectionUpdate", handler);
    };
  }, [editor]);

  if (!editor || !pos.visible) return null;

  const handleAi = async (mode: "improve" | "expand" | "shorten") => {
    if (!editor) return;
    const { from, to } = editor.state.selection;
    const text = editor.state.doc.textBetween(from, to, " ");
    if (!text.trim()) return;

    const res = await fetch("/api/ai/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode, selection: text }),
    });
    const data = await res.json();
    if (data.html) {
      editor.chain().focus().insertContentAt({ from, to }, data.html).run();
    }
    setAiMenu(false);
  };

  const content = (
    <div
      ref={ref}
      className="fixed z-50 flex items-center gap-0.5 rounded-xl border border-slate-200 bg-white/95 p-1 shadow-2xl shadow-black/20 backdrop-blur-xl"
      style={{ top: pos.top, left: pos.left, transform: "translateX(-50%)" }}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <Btn
        title="Bold"
        active={editor.isActive("bold")}
        onClick={() => chain(editor).toggleBold().run()}
      >
        <Bold className="h-3.5 w-3.5" />
      </Btn>
      <Btn
        title="Italic"
        active={editor.isActive("italic")}
        onClick={() => chain(editor).toggleItalic().run()}
      >
        <Italic className="h-3.5 w-3.5" />
      </Btn>
      <Btn
        title="Underline"
        active={editor.isActive("underline")}
        onClick={() => chain(editor).toggleUnderline().run()}
      >
        <Underline className="h-3.5 w-3.5" />
      </Btn>
      <Btn
        title="Strikethrough"
        active={editor.isActive("strike")}
        onClick={() => chain(editor).toggleStrike().run()}
      >
        <Strikethrough className="h-3.5 w-3.5" />
      </Btn>
      <Btn
        title="Highlight"
        active={editor.isActive("highlight")}
        onClick={() => chain(editor).toggleHighlight().run()}
      >
        <Highlighter className="h-3.5 w-3.5" />
      </Btn>
      <Btn
        title="Code"
        active={editor.isActive("code")}
        onClick={() => chain(editor).toggleCode().run()}
      >
        <Code className="h-3.5 w-3.5" />
      </Btn>
      <Btn
        title="Link"
        active={editor.isActive("link")}
        onClick={() => {
          const prev = editor.getAttributes("link").href as string | undefined;
          const url = window.prompt("Link URL", prev || "https://");
          if (url === null) return;
          if (url === "") {
            chain(editor).extendMarkRange("link").unsetLink().run();
            return;
          }
          chain(editor).extendMarkRange("link").setLink({ href: url }).run();
        }}
      >
        <Link2 className="h-3.5 w-3.5" />
      </Btn>

      <div className="mx-0.5 h-5 w-px bg-slate-200" />

      <div className="relative">
        <button
          type="button"
          title="AI actions"
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => setAiMenu(!aiMenu)}
          className="inline-flex h-7 items-center gap-1 rounded-md px-2 text-xs font-semibold text-indigo-700 hover:bg-indigo-100"
        >
          <Sparkles className="h-3.5 w-3.5" />
          AI
        </button>
        {aiMenu && (
          <div className="absolute left-0 top-9 z-50 w-48 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
            <button
              type="button"
              onMouseDown={(e) => { e.preventDefault(); void handleAi("improve"); }}
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs hover:bg-slate-50"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Improve writing
            </button>
            <button
              type="button"
              onMouseDown={(e) => { e.preventDefault(); void handleAi("expand"); }}
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs hover:bg-slate-50"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Expand
            </button>
            <button
              type="button"
              onMouseDown={(e) => { e.preventDefault(); void handleAi("shorten"); }}
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs hover:bg-slate-50"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Shorten
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return createPortal(content, document.body);
}
