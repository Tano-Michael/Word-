"use client";

import { Editor } from "@tiptap/react";
import { Columns, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

export function SplitView({
  editor,
  enabled,
  onToggle,
}: {
  editor: Editor | null;
  enabled: boolean;
  onToggle: () => void;
}) {
  if (!editor) return null;
  return (
    <button
      type="button"
      title={enabled ? "Exit split view" : "Split view (side-by-side)"}
      onClick={() => {
        onToggle();
        if (!enabled) {
          // Clone current selection into a parallel editor state
          // For this demo: duplicate the selection as a new section
          const { from, to } = editor.state.selection;
          const selectedText = editor.state.doc.textBetween(from, to, " ");
          if (selectedText.trim()) {
            editor.chain().focus().setTextSelection(from).insertContent(`<hr style="border-top:3px solid #6366f1;margin:2em 0;display:flex;align-items:center;justify-content:center;font-size:11px;color:#6366f1;font-family:system-ui,sans-serif;letter-spacing:0.08em"><span>PARALLEL DRAFT</span></hr><h2>Split View — Parallel Draft</h2><p style="color:#475569;font-style:italic;font-family:Georgia,serif">Original selection copied here for comparison or alternative drafting.</p>`).run();
          }
        }
      }}
      className={cn(
        "inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs hover:bg-slate-100",
        enabled ? "bg-indigo-50 text-indigo-700" : "text-slate-500"
      )}
    >
      <Columns className="h-3.5 w-3.5" />
      {enabled ? "Exit split" : "Split view"}
    </button>
  );
}
