"use client";

import { useEffect, useState } from "react";
import { Editor } from "@tiptap/react";
import { AlertCircle, AlertTriangle, Info, Replace, X, ArrowRight } from "lucide-react";
import type { ProofIssue } from "./LiveProofing";
import { cn } from "@/lib/utils";

function severityIcon(s: ProofIssue["severity"]) {
  if (s === "error") return <AlertCircle className="h-3.5 w-3.5 text-rose-500" />;
  if (s === "warning") return <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />;
  return <Info className="h-3.5 w-3.5 text-sky-500" />;
}

export function ProofOverlay({
  editor,
  visible,
  position,
  issue,
  onApply,
  onDismiss,
  onClose,
}: {
  editor: Editor | null;
  visible: boolean;
  position: { top: number; left: number } | null;
  issue: ProofIssue | null;
  onApply: (issue: ProofIssue) => void;
  onDismiss: (issue: ProofIssue) => void;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!visible) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [visible, onClose]);

  if (!visible || !position || !issue) return null;

  const canApply = issue.suggestion && !issue.suggestion.startsWith("(");

  return (
    <div
      className="fixed z-50 w-72 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-2xl shadow-black/15 backdrop-blur-xl"
      style={{ top: position.top, left: position.left }}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <div className="mb-2 flex items-start justify-between gap-2">
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
          {severityIcon(issue.severity)}
          {issue.type}
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
      <p className="text-sm text-slate-800">
        <span className="rounded bg-rose-50 px-1 text-rose-700 line-through decoration-rose-300">
          {issue.original}
        </span>
        {canApply && (
          <>
            <ArrowRight className="mx-1 inline h-3 w-3 text-slate-400" />
            <span className="rounded bg-emerald-50 px-1 text-emerald-800">
              {issue.suggestion}
            </span>
          </>
        )}
      </p>
      <p className="mt-1.5 text-xs leading-relaxed text-slate-500">{issue.message}</p>
      <div className="mt-3 flex items-center gap-2">
        {canApply && (
          <button
            type="button"
            className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
            onClick={() => onApply(issue)}
          >
            <Replace className="h-3.5 w-3.5" />
            Apply fix
          </button>
        )}
        <button
          type="button"
          className={cn(
            "rounded-lg px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100",
            !canApply && "bg-white"
          )}
          onClick={() => onDismiss(issue)}
        >
          Dismiss
        </button>
      </div>
    </div>
  );
}
