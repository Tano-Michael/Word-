/**
 * Reference / bibliography helpers for Aether.
 *
 * Word-style features:
 *  - Hanging indent (first line flush left, continuation lines indented)
 *  - Alphabetical sorting of the selected reference entries
 *
 * Implemented as a TipTap Extension that adds paragraph attributes plus
 * editor commands. Hanging indent is stored as a data attribute + inline
 * style so it survives save/load and export.
 */
import { Extension } from "@tiptap/core";

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    references: {
      /** Toggle a hanging indent on the selected paragraph(s). */
      toggleHangingIndent: (indentEm?: number) => ReturnType;
      /** Set an explicit hanging indent (0 clears it). */
      setHangingIndent: (indentEm: number) => ReturnType;
      /** Sort the selected paragraphs alphabetically (A→Z or Z→A). */
      sortParagraphsAlphabetically: (descending?: boolean) => ReturnType;
    };
  }
}

const DEFAULT_HANGING_EM = 2.5;

export const References = Extension.create({
  name: "references",

  addGlobalAttributes() {
    return [
      {
        types: ["paragraph"],
        attributes: {
          hangingIndent: {
            default: null,
            parseHTML: (element) => {
              const value = element.getAttribute("data-hanging-indent");
              return value ? parseFloat(value) : null;
            },
            renderHTML: (attributes) => {
              const indent = attributes.hangingIndent as number | null;
              if (!indent) return {};
              return {
                "data-hanging-indent": String(indent),
                style: `padding-left:${indent}em;text-indent:-${indent}em`,
              };
            },
          },
        },
      },
    ];
  },

  addCommands() {
    return {
      setHangingIndent:
        (indentEm: number) =>
        ({ commands }) =>
          commands.updateAttributes("paragraph", {
            hangingIndent: indentEm > 0 ? indentEm : null,
          }),

      toggleHangingIndent:
        (indentEm = DEFAULT_HANGING_EM) =>
        ({ editor, commands }) => {
          const current = editor.getAttributes("paragraph").hangingIndent as
            | number
            | null;
          return commands.updateAttributes("paragraph", {
            hangingIndent: current ? null : indentEm,
          });
        },

      sortParagraphsAlphabetically:
        (descending = false) =>
        ({ state, tr, dispatch }) => {
          const { from, to } = state.selection;

          // Collect top-level paragraph blocks that intersect the selection.
          const blocks: { start: number; end: number; text: string; node: import("@tiptap/pm/model").Node }[] = [];
          state.doc.forEach((node, offset) => {
            if (node.type.name !== "paragraph") return;
            const start = offset;
            const end = offset + node.nodeSize;
            const intersects = start < to && end > from;
            if (intersects && node.textContent.trim().length > 0) {
              blocks.push({ start, end, text: node.textContent, node });
            }
          });

          if (blocks.length < 2) return false;

          // Sort by normalized text (ignore leading punctuation/quotes).
          const normalize = (s: string) =>
            s
              .toLowerCase()
              .replace(/^[\s"'“”‘’(\[]+/, "")
              .trim();

          const sortedNodes = [...blocks]
            .sort((a, b) => {
              const cmp = normalize(a.text).localeCompare(normalize(b.text), undefined, {
                numeric: true,
                sensitivity: "base",
              });
              return descending ? -cmp : cmp;
            })
            .map((b) => b.node);

          // Replace the contiguous span from the first to the last block.
          const spanStart = blocks[0].start;
          const spanEnd = blocks[blocks.length - 1].end;

          // Only safe when the blocks are contiguous paragraphs.
          const contiguous = blocks.every(
            (b, i) => i === 0 || b.start === blocks[i - 1].end
          );
          if (!contiguous) return false;

          if (dispatch) {
            const fragment = sortedNodes;
            tr.replaceWith(
              spanStart,
              spanEnd,
              fragment as unknown as import("@tiptap/pm/model").Node[]
            );
            dispatch(tr);
          }
          return true;
        },
    };
  },
});
