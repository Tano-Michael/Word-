"use client";

import { cn } from "@/lib/utils";

export type PageLayoutMode = "page" | "web" | "outline";

export function PageBreakInsertButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group relative my-4 flex w-full cursor-pointer items-center gap-2"
      title="Insert page break"
    >
      <div className="flex-1 border-t-2 border-dashed border-slate-300 transition-colors group-hover:border-indigo-400" />
      <span className="shrink-0 rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-slate-500 transition-colors group-hover:bg-indigo-100 group-hover:text-indigo-700">
        Insert page break
      </span>
      <div className="flex-1 border-t-2 border-dashed border-slate-300 transition-colors group-hover:border-indigo-400" />
    </button>
  );
}

export function WatermarkOverlay({ text }: { text: string }) {
  if (!text) return null;
  const repeats = 6;
  return (
    <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden opacity-[0.07]">
      <div
        className="absolute flex flex-wrap gap-24"
        style={{
          top: "10%",
          left: "-10%",
          width: "140%",
          transform: "rotate(-35deg)",
        }}
      >
        {Array.from({ length: repeats }).map((_, row) => (
          <div key={row} className="flex w-full gap-24">
            {Array.from({ length: repeats }).map((_, col) => (
              <span
                key={col}
                className="text-5xl font-bold uppercase tracking-widest text-slate-900"
              >
                {text}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function PageNumDisplay({
  current,
  total,
}: {
  current: number;
  total: number;
}) {
  return (
    <span className="text-xs text-slate-400">
      Page {current} of {total}
    </span>
  );
}

export function LayoutModeSelector({
  mode,
  onChange,
}: {
  mode: PageLayoutMode;
  onChange: (m: PageLayoutMode) => void;
}) {
  const modes: { id: PageLayoutMode; label: string }[] = [
    { id: "page", label: "Page" },
    { id: "web", label: "Web" },
    { id: "outline", label: "Outline" },
  ];
  return (
    <div className="flex items-center gap-0.5 rounded-lg border border-slate-200 bg-slate-50 p-0.5">
      {modes.map((m) => (
        <button
          key={m.id}
          type="button"
          onClick={() => onChange(m.id)}
          className={cn(
            "rounded-md px-2.5 py-1 text-[11px] font-medium transition",
            mode === m.id
              ? "bg-white text-slate-900 shadow-sm"
              : "text-slate-500 hover:text-slate-700"
          )}
        >
          {m.label}
        </button>
      ))}
    </div>
  );
}

export function ColumnSelector({
  columns,
  onChange,
}: {
  columns: number;
  onChange: (n: number) => void;
}) {
  return (
    <label className="flex items-center gap-1 text-[11px] text-slate-500">
      Columns
      <select
        value={columns}
        onChange={(e) => onChange(Number(e.target.value))}
        className="rounded border border-slate-200 bg-white px-1 py-0.5 text-[11px]"
      >
        {[1, 2, 3].map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </select>
    </label>
  );
}

export function WatermarkSelector({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const presets = ["", "DRAFT", "CONFIDENTIAL", "DO NOT DISTRIBUTE", "SAMPLE", "ORIGINAL"];
  return (
    <label className="flex items-center gap-1 text-[11px] text-slate-500">
      Watermark
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded border border-slate-200 bg-white px-1 py-0.5 text-[11px]"
      >
        {presets.map((p) => (
          <option key={p} value={p}>
            {p || "None"}
          </option>
        ))}
      </select>
    </label>
  );
}

export function FootnoteRef({ n }: { n: number }) {
  return (
    <sup className="cursor-pointer font-semibold text-indigo-600 hover:underline">
      [{n}]
    </sup>
  );
}

export function FootnotesBar({ notes }: { notes: string[] }) {
  if (!notes.length) return null;
  return (
    <div className="mx-auto my-4 w-[816px] max-w-full border-t border-slate-200 pt-3">
      <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
        Footnotes
      </p>
      <ol className="space-y-1">
        {notes.map((note, i) => (
          <li key={i} className="flex gap-2 text-xs text-slate-600">
            <span className="font-semibold text-indigo-600">{i + 1}.</span>
            <span>{note}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}

export function TableOfContents({
  items,
  onJump,
}: {
  items: { level: number; text: string; pos?: number }[];
  onJump: (pos?: number) => void;
}) {
  if (!items.length) return null;
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
      <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
        Table of contents
      </p>
      <nav className="space-y-1">
        {items.map((item, i) => (
          <button
            key={i}
            type="button"
            onClick={() => onJump(item.pos)}
            className="block w-full text-left text-sm text-slate-700 hover:text-indigo-600"
            style={{ paddingLeft: (item.level - 1) * 14 }}
          >
            <span className="mr-1.5 text-[10px] font-bold text-slate-400">
              H{item.level}
            </span>
            {item.text}
          </button>
        ))}
      </nav>
    </div>
  );
}

export function TrackChangeIndicator({
  mode,
  onToggle,
}: {
  mode: "editing" | "suggesting";
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={cn(
        "inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium transition",
        mode === "suggesting"
          ? "bg-amber-100 text-amber-800 ring-1 ring-amber-300"
          : "text-slate-500 hover:bg-slate-100"
      )}
      title={mode === "suggesting" ? "Switch to editing" : "Switch to suggesting"}
    >
      <div
        className={cn(
          "h-2 w-2 rounded-full",
          mode === "suggesting" ? "bg-amber-500" : "bg-emerald-500"
        )}
      />
      {mode === "suggesting" ? "Suggesting" : "Editing"}
    </button>
  );
}
