"use client";

import { Editor } from "@tiptap/react";
import { Database, KanbanSquare, List, CheckSquare } from "lucide-react";
import { cn } from "@/lib/utils";

interface DatabaseBlockProps {
  editor: Editor;
  data?: { columns?: { title: string; items: string[] }[] };
}

export function DatabaseBlock({ editor, data }: DatabaseBlockProps) {
  const columns = data?.columns || [
    { title: "Task", items: ["Draft proposal", "Review timeline", "Send to client"] },
  ];

  const handleAddItem = (colIndex: number, item: string) => {
    columns[colIndex].items.push(item);
    // Trigger update so the editor saves the new state
    if (editor) {
      editor.commands.insertContentAt(editor.state.selection.to, `<p>[DB-UPDATE]</p>`);
    }
  };

  return (
    <div className="my-4 overflow-x-auto rounded-xl border border-slate-200 bg-slate-50 shadow-sm">
      <div className="flex min-w-[600px] gap-3 p-3">
        {columns.map((col, i) => (
          <div key={i} className="min-w-[200px] flex-1 rounded-xl bg-white p-3 shadow-sm ring-1 ring-slate-100">
            <div className="mb-2 flex items-center gap-1 text-xs font-bold text-slate-600 uppercase tracking-wide">
              <KanbanSquare className="h-3.5 w-3.5 text-indigo-500" />
              {col.title}
            </div>
            <div className="space-y-1.5">
              {col.items.map((item, j) => (
                <div
                  key={j}
                  className="flex items-start gap-2 rounded-lg bg-slate-50 px-2.5 py-2 text-sm text-slate-800 hover:bg-indigo-50 transition-colors"
                >
                  <CheckSquare className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                  <span className="leading-tight">{item}</span>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                const text = window.prompt(`New item for "${col.title}"?`);
                if (text?.trim()) handleAddItem(i, text.trim());
              }}
              className="mt-2 flex items-center gap-1 rounded-md px-2 py-1 text-[11px] text-indigo-600 hover:bg-indigo-50"
            >
              <List className="h-3 w-3" /> Add item
            </button>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-200 bg-slate-100/60 px-3 py-1.5 text-[10px] text-slate-500">
        Database-style tracking block · {columns.length} column{columns.length === 1 ? "" : "s"} · {columns.reduce((n, c) => n + c.items.length, 0)} item{columns.reduce((n, c) => n + c.items.length, 0) === 1 ? "" : "s"}
      </div>
    </div>
  );
}
