#!/usr/bin/env bash
# Aether - AI Document OS :: macOS / Linux installer (zero setup)
set -u

cd "$(dirname "$0")"

BOLD='\033[1m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'

echo ""
echo -e "${CYAN}  ============================================================${NC}"
echo -e "${CYAN}                 AETHER - AI DOCUMENT OS${NC}"
echo -e "${CYAN}                  macOS / Linux Installer${NC}"
echo -e "${CYAN}  ============================================================${NC}"
echo ""
echo "  No database setup needed. This takes about 3 minutes."
echo ""
read -rp "  Press Enter to continue..."

# ---------------------------------------------------------------
# 1. Node.js
# ---------------------------------------------------------------
echo ""
echo -e "${BOLD}  [1/3] Checking for Node.js...${NC}"
if ! command -v node >/dev/null 2>&1; then
  echo -e "${YELLOW}      Node.js not found - attempting install...${NC}"
  if command -v brew >/dev/null 2>&1; then
    brew install node
  elif command -v apt >/dev/null 2>&1; then
    sudo apt update && sudo apt install -y nodejs npm
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y nodejs
  fi
fi

if ! command -v node >/dev/null 2>&1; then
  echo -e "${RED}"
  echo "  [X] Node.js is required but could not be installed automatically."
  echo -e "${NC}"
  echo "  Please install it from https://nodejs.org (LTS version),"
  echo "  then run ./install.sh again."
  echo ""
  exit 1
fi

NODE_VER="$(node -v)"
NODE_MAJOR="$(echo "$NODE_VER" | sed 's/v//' | cut -d. -f1)"
echo "      Found Node.js $NODE_VER"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo -e "${YELLOW}      [!] Aether needs Node.js v20+. Please upgrade.${NC}"
  exit 1
fi

# ---------------------------------------------------------------
# 2. Dependencies
# ---------------------------------------------------------------
echo ""
echo -e "${BOLD}  [2/3] Installing components (slow part, ~2 min)...${NC}"
echo ""
if ! npm install --no-audit --no-fund; then
  echo -e "${RED}  [X] Install failed. Check your internet connection.${NC}"
  exit 1
fi
echo "      Components installed."

# ---------------------------------------------------------------
# 3. Build
# ---------------------------------------------------------------
echo ""
echo -e "${BOLD}  [3/3] Preparing the application...${NC}"
echo ""
if ! npm run build; then
  echo -e "${RED}  [X] Build failed.${NC}"
  exit 1
fi

chmod +x start.sh 2>/dev/null || true

echo ""
echo -e "${GREEN}  ============================================================${NC}"
echo -e "${GREEN}                    INSTALLATION COMPLETE${NC}"
echo -e "${GREEN}  ============================================================${NC}"
echo ""
echo "  To start Aether, run:"
echo -e "      ${BOLD}./start.sh${NC}"
echo ""
echo "  Your documents are stored in the ./data folder."
echo ""
echo "  TIP: In Chrome or Edge, click the install icon in the address"
echo "       bar to run Aether in its own window like a native app."
echo ""

read -rp "  Start Aether now? (Y/n): " LAUNCH
case "$LAUNCH" in [nN]*) exit 0 ;; esac
exec ./start.sh
