@echo off
setlocal EnableDelayedExpansion
title Aether - Installer
color 0B

cd /d "%~dp0"

echo.
echo   ============================================================
echo.
echo        A E T H E R   -   AI   D O C U M E N T   O S
echo.
echo   ============================================================
echo.
echo   Everything you need runs from this folder. No database
echo   server, no cloud account, no configuration files.
echo.
echo   This takes about 3 minutes on a typical connection.
echo.
pause

REM ===============================================================
REM  STEP 1 - Node.js (auto-install via winget if missing)
REM ===============================================================
echo.
echo   [1/5] Checking for Node.js...

where node >nul 2>nul
if not errorlevel 1 goto :nodefound

echo       Node.js was not found. Attempting automatic install...
echo.

where winget >nul 2>nul
if errorlevel 1 goto :nodemanual

echo       Installing Node.js LTS via Windows Package Manager.
echo       (You may see a User Account Control prompt - click Yes.)
echo.
winget install --id OpenJS.NodeJS.LTS -e --source winget --accept-package-agreements --accept-source-agreements
echo.

REM Refresh PATH for this session
for /f "usebackq tokens=2,*" %%A in (`reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul`) do set "SYSPATH=%%B"
for /f "usebackq tokens=2,*" %%A in (`reg query "HKCU\Environment" /v Path 2^>nul`) do set "USRPATH=%%B"
set "PATH=%SYSPATH%;%USRPATH%;%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs"

where node >nul 2>nul
if not errorlevel 1 goto :nodefound

color 0E
echo.
echo   [!] Node.js was installed but this window cannot see it yet.
echo.
echo       Please CLOSE this window and double-click INSTALL.bat again.
echo       (Windows needs to refresh its PATH.)
echo.
pause
exit /b 0

:nodemanual
color 0C
echo.
echo   [X] Node.js is required and could not be installed automatically.
echo.
echo   1. The download page is opening now.
echo   2. Choose the "LTS" installer and run it.
echo   3. Accept all the defaults.
echo   4. RESTART your computer.
echo   5. Run this INSTALL.bat again.
echo.
start https://nodejs.org
pause
exit /b 1

:nodefound
for /f "tokens=*" %%v in ('node -v') do set "NODEVER=%%v"
echo       Found Node.js !NODEVER!

set "NODEMAJOR=!NODEVER:v=!"
for /f "tokens=1 delims=." %%a in ("!NODEMAJOR!") do set "NODEMAJOR=%%a"
if !NODEMAJOR! LSS 20 (
    color 0E
    echo.
    echo   [!] Node.js !NODEVER! is too old - Aether needs v20+.
    echo       Please update from https://nodejs.org then re-run this installer.
    echo.
    start https://nodejs.org
    pause
    exit /b 1
)

REM ===============================================================
REM  STEP 2 - Dependencies
REM ===============================================================
echo.
echo   [2/5] Downloading Aether components...
echo.
echo   The first download is large (PDF, DOCX, editor, AI tools).
echo   It normally takes 5-15 minutes depending on your internet.
echo.
echo   IMPORTANT: If package names or a spinner are still changing,
echo   it is working — please let it finish.
echo.
echo   If the exact same text stays on screen for MORE THAN 5 MINUTES,
echo   press Ctrl+C, then double-click FIX-INSTALL.bat.
echo.

REM Avoid extremely long stalled network retries.
set "npm_config_fetch_retries=2"
set "npm_config_fetch_retry_mintimeout=5000"
set "npm_config_fetch_retry_maxtimeout=30000"
set "npm_config_fetch_timeout=120000"

call npm install --no-audit --no-fund --prefer-offline --foreground-scripts
if errorlevel 1 (
    color 0C
    echo.
    echo   [X] Install failed or was interrupted.
    echo.
    echo   Double-click FIX-INSTALL.bat to repair the installation.
    echo.
    pause
    exit /b 1
)
echo       Components installed.

REM ===============================================================
REM  STEP 3 - Build
REM ===============================================================
echo.
echo   [3/5] Preparing the application...
echo.
call npm run build
if errorlevel 1 (
    color 0C
    echo.
    echo   [X] Build failed. Please share the messages above for support.
    echo.
    pause
    exit /b 1
)
echo       Build complete.

REM ===============================================================
REM  STEP 4 - Desktop shortcut
REM ===============================================================
echo.
echo   [4/5] Creating shortcuts...

set "SHORTCUT=%USERPROFILE%\Desktop\Aether.lnk"
set "TARGET=%~dp0Aether.bat"
set "ICONSRC=%~dp0public\icons\aether.ico"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w = New-Object -ComObject WScript.Shell;" ^
  "$s = $w.CreateShortcut('%SHORTCUT%');" ^
  "$s.TargetPath = '%TARGET%';" ^
  "$s.WorkingDirectory = '%~dp0';" ^
  "$s.Description = 'Aether - AI Document OS';" ^
  "$s.WindowStyle = 7;" ^
  "if (Test-Path '%ICONSRC%') { $s.IconLocation = '%ICONSRC%' };" ^
  "$s.Save()" >nul 2>nul

if exist "%SHORTCUT%" (
    echo       Desktop shortcut created.
) else (
    echo       Could not create desktop shortcut - use Aether.bat instead.
)

REM Start Menu shortcut
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Aether.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w = New-Object -ComObject WScript.Shell;" ^
  "$s = $w.CreateShortcut('%STARTMENU%');" ^
  "$s.TargetPath = '%TARGET%';" ^
  "$s.WorkingDirectory = '%~dp0';" ^
  "$s.Description = 'Aether - AI Document OS';" ^
  "$s.WindowStyle = 7;" ^
  "if (Test-Path '%ICONSRC%') { $s.IconLocation = '%ICONSRC%' };" ^
  "$s.Save()" >nul 2>nul

if exist "%STARTMENU%" (
    echo       Start Menu shortcut created.
) else (
    echo       Could not create Start Menu shortcut.
)

REM ===============================================================
REM  STEP 5 - Verify everything works
REM ===============================================================
echo.
echo   [5/5] Running a quick self-test...
echo.

set "TESTOK=0"
start "" /min cmd /c "npm start -- -p 3399 > data\install-test.log 2>&1"
for /l %%i in (1,1,8) do (
    timeout /t 2 >nul
    curl -s --max-time 3 http://localhost:3399/api/health > "%TEMP%\aether-test.json" 2>nul
    if not errorlevel 1 (
        set "TESTOK=1"
        goto :testdone
    )
)
:testdone

REM Kill the test server
for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":3399 " ^| findstr "LISTENING"') do (
    taskkill /F /PID %%p >nul 2>nul
)

if !TESTOK!==1 (
    echo       Self-test PASSED - Aether is working correctly.
) else (
    color 0E
    echo       Self-test could not confirm the server started.
    echo       This might just be a slow machine - try starting it manually.
    echo       If problems persist, run DIAGNOSE.bat.
)

color 0A
echo.
echo   ============================================================
echo.
echo              INSTALLATION COMPLETE - READY TO USE
echo.
echo   ============================================================
echo.
echo   HOW TO START AETHER:
echo.
echo      Option 1:  Double-click "Aether" on your Desktop
echo      Option 2:  Search "Aether" in the Start Menu
echo      Option 3:  Double-click Aether.bat in this folder
echo.
echo   Your documents are saved in the "data" folder here.
echo   To back up your work, copy the "data" folder.
echo.
echo   BONUS: When Aether opens in Chrome or Edge, click the
echo   install icon in the address bar to make it look and feel
echo   exactly like a normal desktop program (its own window,
echo   no browser tabs).
echo.
echo   ============================================================
echo.
set "LAUNCHNOW=Y"
set /p LAUNCHNOW="   Start Aether now? (Y/n): "
if /i "!LAUNCHNOW!"=="n" goto :end
start "" "%~dp0Aether.bat"

:end
echo.
echo   Enjoy Aether!
timeout /t 3 >nul
endlocal
exit /b 0
