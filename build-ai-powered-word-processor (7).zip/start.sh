#!/usr/bin/env bash
# Aether - AI Document OS :: launcher for macOS / Linux
set -u

cd "$(dirname "$0")"

CYAN='\033[0;36m'; RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'

echo ""
echo -e "${CYAN}  ============================================${NC}"
echo -e "${CYAN}         AETHER - AI DOCUMENT OS${NC}"
echo -e "${CYAN}  ============================================${NC}"
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo -e "${RED}  [X] Node.js not found. Run ./install.sh first.${NC}"
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo -e "${RED}  [X] Dependencies missing. Run ./install.sh first.${NC}"
  exit 1
fi

if [ ! -d ".next" ]; then
  echo "  First run detected - building..."
  npm run build || exit 1
fi

PORT=3000
if command -v lsof >/dev/null 2>&1 && lsof -i :3000 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "  Port 3000 busy - using 3001."
  PORT=3001
fi

URL="http://localhost:${PORT}"
echo -e "  Starting Aether at ${BOLD}${URL}${NC}"
echo ""
echo "  ------------------------------------------------"
echo "   Keep this terminal open while using Aether."
echo "   Press Ctrl+C to stop."
echo "  ------------------------------------------------"
echo ""

# Open the browser once the server is up
(
  sleep 4
  if command -v open >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  fi
) >/dev/null 2>&1 &

exec npm start -- -p "$PORT"
