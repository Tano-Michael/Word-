@echo off
setlocal EnableDelayedExpansion
title Aether - Update
color 0B

cd /d "%~dp0"

echo.
echo   ============================================================
echo                  AETHER - UPDATE / REPAIR
echo   ============================================================
echo.
echo   This re-installs components and rebuilds the app.
echo   Your documents in the "data" folder are NOT touched.
echo.
pause

where node >nul 2>nul
if errorlevel 1 (
    color 0C
    echo   [X] Node.js not found. Run INSTALL.bat first.
    pause
    exit /b 1
)

echo.
echo   [1/3] Cleaning previous build...
if exist ".next" rmdir /s /q ".next" >nul 2>nul
echo       Done.

echo.
echo   [2/3] Reinstalling components...
echo.
call npm install --no-audit --no-fund
if errorlevel 1 (
    color 0C
    echo   [X] Install failed.
    pause
    exit /b 1
)

echo.
echo   [3/3] Rebuilding the application...
echo.
call npm run build
if errorlevel 1 (
    color 0C
    echo   [X] Build failed.
    pause
    exit /b 1
)

color 0A
echo.
echo   ============================================================
echo                     UPDATE COMPLETE
echo   ============================================================
echo.
echo   Start Aether as usual (Desktop shortcut or Aether.bat).
echo.
pause
endlocal
exit /b 0
