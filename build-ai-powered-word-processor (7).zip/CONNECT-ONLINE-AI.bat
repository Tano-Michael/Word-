@echo off
setlocal
title Aether - Connect Online AI
color 0B
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONNECT-ONLINE-AI.ps1"
if errorlevel 1 (
  color 0C
  echo.
  echo   Setup did not complete. Check the message above.
  echo.
  pause
  exit /b 1
)

endlocal
exit /b 0
