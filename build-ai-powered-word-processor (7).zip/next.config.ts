import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // These must run as real Node modules on the server (native / WASM assets),
  // so keep them out of the bundler.
  serverExternalPackages: [
    "mammoth",
    "pdfjs-dist",
    "docx",
    "@electric-sql/pglite",
    "pg",
  ],
};

export default nextConfig;
