@echo off
setlocal EnableDelayedExpansion
title Aether - Diagnostics
color 0E

cd /d "%~dp0"

echo.
echo   ============================================================
echo                AETHER - SYSTEM DIAGNOSTICS
echo   ============================================================
echo.
echo   This checks why Aether or documents are not opening.
echo   Nothing here changes your PC or your documents.
echo.
pause

set "FAILS=0"

REM ---------------------------------------------------------------
echo.
echo   [1/5] Node.js
where node >nul 2>nul
if errorlevel 1 (
    echo       FAIL - Node.js is not installed or not in PATH.
    echo       FIX  - Run INSTALL.bat.
    set /a FAILS+=1
) else (
    for /f "tokens=*" %%v in ('node -v') do echo       OK   - Node.js %%v
)

REM ---------------------------------------------------------------
echo.
echo   [2/5] Aether files present
set "MISSING=0"
if not exist "package.json" set "MISSING=1" & echo       FAIL - package.json is missing - extract the whole ZIP.
if not exist "node_modules" set "MISSING=1" & echo       FAIL - node_modules is missing - run INSTALL.bat.
if not exist ".next" set "MISSING=1" & echo       FAIL - .next is missing - run INSTALL.bat.
if !MISSING!==0 echo       OK   - Everything the app needs is here.
if !MISSING!==1 set /a FAILS+=1

REM ---------------------------------------------------------------
echo.
echo   [3/5] Data folder
if exist "data" (
    echo       OK   - "data" folder exists.
) else (
    echo       INFO - No "data" folder yet. It will be created on first run.
)
echo       (This folder stores all your documents.)

REM ---------------------------------------------------------------
echo.
echo   [4/5] Is Aether already running somewhere?
curl -s --max-time 3 http://localhost:3000/api/health > "%TEMP%\aether-h3000.json" 2>nul
if not errorlevel 1 (
    echo       PORT 3000 answers:
    type "%TEMP%\aether-h3000.json" 2>nul & echo.
)
curl -s --max-time 3 http://localhost:3001/api/health > "%TEMP%\aether-h3001.json" 2>nul
if not errorlevel 1 (
    echo       PORT 3001 answers:
    type "%TEMP%\aether-h3001.json" 2>nul & echo.
)

REM ---------------------------------------------------------------
echo.
echo   [5/5] Live test with a fresh server
echo.
echo       Starting a test server on port 3310 for 25 seconds...
echo       (A window freez or your firewall asking a question is normal.)
echo.

start "" /min cmd /c "npm start -- -p 3310 > data\diag-server.log 2>&1"

echo       Waiting for it to come up...
set "HEALTH="
for /l %%i in (1,1,10) do (
    timeout /t 2 >nul
    curl -s --max-time 3 http://localhost:3310/api/health > "%TEMP%\aether-h3310.json" 2>nul
    if not errorlevel 1 (
        set "HEALTH=1"
        goto :gothealth
    )
)
:gothealth

if defined HEALTH (
    echo       OK   - Server started. Health says:
    echo.
    type "%TEMP%\aether-h3310.json" 2>nul
    echo.
    echo.
    curl -s --max-time 5 http://localhost:3310/api/diagnose > "%TEMP%\aether-diag.json" 2>nul
    if not errorlevel 1 (
        echo       Full diagnostic:
        echo.
        type "%TEMP%\aether-diag.json" 2>nul
        echo.
    )
) else (
    echo       FAIL - The server did not start within 20 seconds.
    echo       Most likely that is ALSO why Aether cannot open documents.
    echo.
    set /a FAILS+=1
    if exist "data\diag-server.log" (
        echo       ------- Server log (data\diag-server.log) -------
        type "data\diag-server.log"
        echo       --------------------------------------------------
    )
)

taskkill /F /FI "WINDOWTITLE eq node*" >nul 2>nul
for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":3310 " ^| findstr "LISTENING"') do (
    taskkill /F /PID %%p >nul 2>nul
)

echo.
echo   ============================================================
if !FAILS!==0 (
    color 0A
    echo   RESULT: No blocking problems found.
    echo.
    echo   If documents STILL do not open:
    echo     1. Open http://localhost:3000 in Chrome or Edge
    echo        while Aether.bat is running.
    echo     2. Do NOT open the page from an old bookmark whose
    echo        port has changed (e.g. 3001).
    echo     3. Send us the output of this window.
) else (
    color 0C
    echo   RESULT: Found !FAILS! problem(s) above - follow each FIX.
)
echo.
echo   Log file you can send for support: data\aether.log
if exist "data\aether.log" (
    echo.
    echo   ------- Last log entries (data\aether.log) -------
    powershell -NoProfile -Command "Get-Content 'data\aether.log' -Tail 15" 2>nul
    echo   --------------------------------------------------
)
echo   ============================================================
echo.
pause
endlocal
exit /b 0
