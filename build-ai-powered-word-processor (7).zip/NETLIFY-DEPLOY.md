# Netlify quick-deploy guide for Aether

This folder contains a zero-setup document editor. You can deploy it
on Netlify in about 60 seconds — no database server needed.

## One-click deploy

```bash
# From this folder
netlify deploy --build --prod
```

Or use the Netlify web UI:
1. Go to https://app.netlify.com
2. Click "New site from Git" (or drag this folder for manual deploy)
3. If using Git: connect your repo and set:
   - Build command: `npm run build`
   - Publish directory: `.next`
4. Click Deploy

## What happens

Aether detects Netlify (`NETLIFY=true` in the environment) and:
- Uses the embedded PostgreSQL (`PGlite`) instead of a server DB
- Writes your documents to `/tmp/aether-db` (survives the function request)
- Keeps the data folder (`./data`) as a fallback for local runs

## After deploy

- Visit your `.netlify.app` URL
- Create a document — it saves to the embedded DB
- Download DOCX / PDF — import / export works exactly the same
- All AI features (copilot, grammar check, rewrite, research, outline) work

## Troubleshooting

If you see "Failed to load the document" or a blank library after deploy:
- The embedded DB is likely having a path issue with `/tmp`
- The `diag` endpoint (`https://your-site.netlify.app/api/diagnose`) will show the exact error
- Re-deploy by running `netlify deploy --prod --build` again — `/tmp` is fresh per deploy
