$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Set-DotEnvValue {
  param([string]$Name, [string]$Value)
  $envPath = Join-Path $PSScriptRoot ".env"
  $lines = @()
  if (Test-Path $envPath) {
    $lines = [System.Collections.Generic.List[string]](Get-Content $envPath)
  } else {
    $lines = [System.Collections.Generic.List[string]]@()
  }

  $escaped = $Value.Replace("`r", "").Replace("`n", "")
  $replacement = "$Name=$escaped"
  $found = $false
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match "^\s*$([regex]::Escape($Name))=") {
      $lines[$i] = $replacement
      $found = $true
    }
  }
  if (-not $found) { $lines.Add($replacement) }
  [System.IO.File]::WriteAllLines($envPath, $lines, (New-Object System.Text.UTF8Encoding($false)))
}

function Read-SecretText {
  param([string]$Prompt)
  $secure = Read-Host $Prompt -AsSecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try {
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
  } finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
  }
}

Clear-Host
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "               AETHER - CONNECT ONLINE AI" -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Online grammar uses LanguageTool when you click Check online."
Write-Host "  That works without an API key for light personal use."
Write-Host ""
Write-Host "  To power Copilot + Rewrite with a frontier AI model, choose:"
Write-Host ""
Write-Host "    1. OpenAI (GPT)"
Write-Host "    2. Anthropic (Claude)"
Write-Host "    3. Google (Gemini)"
Write-Host "    4. LanguageTool grammar only (no cloud Copilot)"
Write-Host "    5. Disable all online services"
Write-Host ""

$choice = Read-Host "  Choice [1-5]"

# Online grammar is enabled unless explicitly disabled below.
Set-DotEnvValue "AETHER_ONLINE_GRAMMAR" "1"

switch ($choice) {
  "1" {
    $key = Read-SecretText "  Paste your OpenAI API key"
    if ([string]::IsNullOrWhiteSpace($key)) { throw "No API key entered." }
    $model = Read-Host "  Model [gpt-4.1-mini]"
    if ([string]::IsNullOrWhiteSpace($model)) { $model = "gpt-4.1-mini" }
    Set-DotEnvValue "AETHER_AI_PROVIDER" "openai"
    Set-DotEnvValue "OPENAI_API_KEY" $key
    Set-DotEnvValue "OPENAI_MODEL" $model
    Write-Host "`n  OpenAI connected." -ForegroundColor Green
  }
  "2" {
    $key = Read-SecretText "  Paste your Anthropic API key"
    if ([string]::IsNullOrWhiteSpace($key)) { throw "No API key entered." }
    $model = Read-Host "  Model [claude-3-5-haiku-latest]"
    if ([string]::IsNullOrWhiteSpace($model)) { $model = "claude-3-5-haiku-latest" }
    Set-DotEnvValue "AETHER_AI_PROVIDER" "anthropic"
    Set-DotEnvValue "ANTHROPIC_API_KEY" $key
    Set-DotEnvValue "ANTHROPIC_MODEL" $model
    Write-Host "`n  Anthropic connected." -ForegroundColor Green
  }
  "3" {
    $key = Read-SecretText "  Paste your Gemini API key"
    if ([string]::IsNullOrWhiteSpace($key)) { throw "No API key entered." }
    $model = Read-Host "  Model [gemini-2.5-flash]"
    if ([string]::IsNullOrWhiteSpace($model)) { $model = "gemini-2.5-flash" }
    Set-DotEnvValue "AETHER_AI_PROVIDER" "gemini"
    Set-DotEnvValue "GEMINI_API_KEY" $key
    Set-DotEnvValue "GEMINI_MODEL" $model
    Write-Host "`n  Gemini connected." -ForegroundColor Green
  }
  "4" {
    Set-DotEnvValue "AETHER_AI_PROVIDER" "local"
    Write-Host "`n  LanguageTool online grammar enabled. Copilot remains private/local." -ForegroundColor Green
  }
  "5" {
    Set-DotEnvValue "AETHER_ONLINE_GRAMMAR" "0"
    Set-DotEnvValue "AETHER_AI_PROVIDER" "local"
    Write-Host "`n  Online services disabled. Aether will run privately offline." -ForegroundColor Yellow
  }
  default { throw "Invalid choice." }
}

Write-Host ""
Write-Host "  IMPORTANT: Close the black Aether server window and start" -ForegroundColor Yellow
Write-Host "  Aether.bat again so it can load the new settings." -ForegroundColor Yellow
Write-Host ""
Write-Host "  Your API key is stored only in .env inside this folder."
Write-Host "  It is never sent to the browser or included in exported files."
Write-Host ""
Read-Host "  Press Enter to finish"
