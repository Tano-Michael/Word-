@echo off
setlocal EnableDelayedExpansion
title Aether - AI Document OS
color 0B

cd /d "%~dp0"

echo.
echo   ============================================
echo          AETHER - AI DOCUMENT OS
echo   ============================================
echo.

REM ===============================================================
REM  1 - Node.js present?
REM ===============================================================
where node >nul 2>nul
if errorlevel 1 (
    color 0C
    echo   [X] Node.js was not found on this computer.
    echo.
    echo       Double-click INSTALL.bat first - it installs everything.
    echo.
    pause
    exit /b 1
)

REM ===============================================================
REM  2 - Installed? If not, run the installer automatically.
REM ===============================================================
if not exist "node_modules" (
    color 0E
    echo   Aether is not installed yet. Launching the installer...
    echo.
    call "%~dp0INSTALL.bat"
    if not exist "node_modules" (
        color 0C
        echo.
        echo   [X] Installation did not finish. Run INSTALL.bat directly
        echo       and note the error message it shows.
        echo.
        pause
        exit /b 1
    )
)

REM ===============================================================
REM  3 - Built? If not, build now (one time).
REM ===============================================================
if not exist ".next\BUILD_ID" (
    echo   First launch - preparing the app. This takes 1-3 minutes...
    echo.
    call npm run build
    if errorlevel 1 (
        color 0C
        echo.
        echo   [X] The build failed. Run UPDATE.bat to repair, or
        echo       DIAGNOSE.bat to see what is wrong.
        echo.
        pause
        exit /b 1
    )
)

REM ===============================================================
REM  4 - Already running? Just open the browser to it.
REM      (This is the most common "it does not open" cause:
REM      a second launch cannot start because the first holds the
REM      database lock - so we reuse the running one instead.)
REM ===============================================================
curl -s --max-time 2 http://localhost:3000/api/health > "%TEMP%\aether-h1.json" 2>nul
findstr /C:"\"ok\":true" "%TEMP%\aether-h1.json" >nul 2>nul
if not errorlevel 1 (
    echo   Aether is ALREADY RUNNING on port 3000.
    echo   Opening it in your browser now...
    echo.
    start "" "http://localhost:3000"
    goto :alreadyrunning
)

curl -s --max-time 2 http://localhost:3001/api/health > "%TEMP%\aether-h2.json" 2>nul
findstr /C:"\"ok\":true" "%TEMP%\aether-h2.json" >nul 2>nul
if not errorlevel 1 (
    echo   Aether is ALREADY RUNNING on port 3001.
    echo   Opening it in your browser now...
    echo.
    start "" "http://localhost:3001"
    goto :alreadyrunning
)

REM ===============================================================
REM  5 - Choose a free port
REM ===============================================================
set "PORT=3000"
netstat -ano 2>nul | findstr ":3000 " | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 (
    echo   Port 3000 is used by something else - trying 3001.
    set "PORT=3001"
    netstat -ano 2>nul | findstr ":3001 " | findstr "LISTENING" >nul 2>nul
    if not errorlevel 1 (
        color 0E
        echo   Both 3000 and 3001 are busy. Trying 3005.
        set "PORT=3005"
    )
)

REM ===============================================================
REM  6 - Start the server and WAIT for a real health check
REM ===============================================================
if not exist "data" mkdir "data" >nul 2>nul

echo   Starting Aether on http://localhost:!PORT!
echo.
echo   Waiting for the server to become ready...

start "" /min cmd /c "npm start -- -p !PORT! > data\launch.log 2>&1"

set "READY=0"
for /l %%i in (1,1,25) do (
    timeout /t 2 >nul
    curl -s --max-time 3 http://localhost:!PORT!/api/health > "%TEMP%\aether-wait.json" 2>nul
    if not errorlevel 1 (
        findstr /C:"\"ok\":true" "%TEMP%\aether-wait.json" >nul 2>nul
        if not errorlevel 1 (
            set "READY=1"
            goto :serverready
        )
    )
    echo   ...still starting (%%i)
)

:serverready

if "!READY!"=="1" (
    echo.
    echo   Server is ready. Opening your browser...
    start "" "http://localhost:!PORT!"
    echo.
    color 0A
    echo   ============================================
    echo    AETHER IS RUNNING
    echo    Address:  http://localhost:!PORT!
    echo.
    echo    Work in the browser window/tab that opened.
    echo    DO NOT close this window while using Aether,
    echo    or press any key below to stop Aether.
    echo   ============================================
    echo.
    pause >nul

    REM User pressed a key = stop the server
    echo.
    echo   Stopping Aether...
    for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":!PORT! " ^| findstr "LISTENING"') do (
        taskkill /F /PID %%p >nul 2>nul
    )
    echo   Aether has stopped.
    timeout /t 2 >nul
    endlocal
    exit /b 0
)

REM ===============================================================
REM  7 - Server did NOT come up - show the real reason
REM ===============================================================
color 0C
echo.
echo   [X] Aether did not start after 50 seconds.
echo.
echo   -------- Server log (data\launch.log) --------
if exist "data\launch.log" (
    type "data\launch.log"
) else (
    echo   (no log was written)
)
echo   ----------------------------------------------
echo.
echo   What to do, in order:
echo     1. Run UPDATE.bat (repairs the build, keeps your documents)
echo     2. If it still fails, run DIAGNOSE.bat and read the result
echo     3. Move this folder to C:\Aether and run UPDATE.bat
echo     4. As a last resort, close everything, delete the "data"
echo        folder (your documents), then run INSTALL.bat again
echo.
pause
endlocal
exit /b 1

:alreadyrunning
echo.
echo   NOTE: An Aether window is already running somewhere on this
echo   computer - you do not need to keep this one open.
echo.
echo   If your browser did not open, type this address by hand:
echo      http://localhost:3000      (or :3001)
echo.
pause
endlocal
exit /b 0
