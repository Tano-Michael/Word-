@echo off
setlocal EnableDelayedExpansion
title Aether - Uninstall
color 0E

cd /d "%~dp0"

echo.
echo   ============================================================
echo                  AETHER - UNINSTALL
echo   ============================================================
echo.
echo   This will remove Aether from your computer.
echo.

set "CONFIRM="
set /p CONFIRM="   Are you sure? Type YES to continue: "
if /i not "!CONFIRM!"=="YES" (
    echo   Cancelled.
    pause
    exit /b 0
)

echo.
echo   [1/3] Removing Desktop shortcut...
if exist "%USERPROFILE%\Desktop\Aether.lnk" (
    del "%USERPROFILE%\Desktop\Aether.lnk" >nul 2>nul
    echo       Removed.
) else (
    echo       Not found - skipping.
)

echo.
echo   [2/3] Removing Start Menu shortcut...
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Aether.lnk" (
    del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Aether.lnk" >nul 2>nul
    echo       Removed.
) else (
    echo       Not found - skipping.
)

echo.
echo   [3/3] What about your documents?
echo.
echo   Your documents are in: %~dp0data
echo.
set "DELDATA="
set /p DELDATA="   Delete your documents too? (y/N): "
if /i "!DELDATA!"=="y" (
    if exist "data" rmdir /s /q "data" >nul 2>nul
    echo       Documents deleted.
) else (
    echo       Documents kept. You can copy the "data" folder elsewhere.
)

color 0A
echo.
echo   ============================================================
echo                     UNINSTALL COMPLETE
echo   ============================================================
echo.
echo   To finish, delete this folder: %~dp0
echo.
echo   Nothing was written to the Windows registry.
echo   Node.js was NOT removed (other programs may use it).
echo.
pause
endlocal
exit /b 0
