
export type ImportResult = {
  html: string;
  title: string;
  kind: string;
  warnings: string[];
  pageCount?: number;
};

function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function plainToHtmlBlocks(text: string) {
  const normalized = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const blocks = normalized.split(/\n{2,}/).filter((b) => b.trim().length);
  if (!blocks.length) return "<p></p>";
  return blocks
    .map((b) => `<p>${escapeHtml(b.trim()).replace(/\n/g, "<br>")}</p>`)
    .join("");
}

export function markdownToHtml(md: string) {
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  const out: string[] = [];
  let inList: "ul" | "ol" | null = null;
  let inCode = false;

  const closeList = () => {
    if (inList) {
      out.push(`</${inList}>`);
      inList = null;
    }
  };

  for (const raw of lines) {
    const line = raw.trimEnd();

    if (/^```/.test(line.trim())) {
      if (inCode) {
        out.push("</code></pre>");
        inCode = false;
      } else {
        closeList();
        out.push("<pre><code>");
        inCode = true;
      }
      continue;
    }
    if (inCode) {
      out.push(escapeHtml(raw) + "\n");
      continue;
    }

    if (!line.trim()) {
      closeList();
      continue;
    }

    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      closeList();
      const level = Math.min(heading[1].length, 4);
      out.push(`<h${level}>${inlineMd(heading[2])}</h${level}>`);
      continue;
    }

    if (/^\s*>\s?/.test(line)) {
      closeList();
      out.push(`<blockquote><p>${inlineMd(line.replace(/^\s*>\s?/, ""))}</p></blockquote>`);
      continue;
    }

    if (/^\s*([-*_])\s*\1\s*\1[\s-*_]*$/.test(line)) {
      closeList();
      out.push("<hr>");
      continue;
    }

    const ul = line.match(/^\s*[-*+]\s+(.*)$/);
    if (ul) {
      if (inList !== "ul") {
        closeList();
        out.push("<ul>");
        inList = "ul";
      }
      out.push(`<li><p>${inlineMd(ul[1])}</p></li>`);
      continue;
    }

    const ol = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (ol) {
      if (inList !== "ol") {
        closeList();
        out.push("<ol>");
        inList = "ol";
      }
      out.push(`<li><p>${inlineMd(ol[1])}</p></li>`);
      continue;
    }

    closeList();
    out.push(`<p>${inlineMd(line)}</p>`);
  }
  closeList();
  if (inCode) out.push("</code></pre>");
  return out.join("") || "<p></p>";
}

function inlineMd(s: string) {
  let t = escapeHtml(s);
  t = t.replace(/`([^`]+)`/g, "<code>$1</code>");
  t = t.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  t = t.replace(/__([^_]+)__/g, "<strong>$1</strong>");
  t = t.replace(/(^|[^*])\*([^*]+)\*/g, "$1<em>$2</em>");
  t = t.replace(/~~([^~]+)~~/g, "<s>$1</s>");
  t = t.replace(
    /\[([^\]]+)\]\(([^)\s]+)\)/g,
    '<a href="$2">$1</a>'
  );
  return t;
}

function rtfToText(rtf: string) {
  let t = rtf;
  t = t.replace(/\\'([0-9a-fA-F]{2})/g, (_m, hex) =>
    String.fromCharCode(parseInt(hex, 16))
  );
  t = t.replace(/\\par[d]?\b/g, "\n");
  t = t.replace(/\{\\\*[^{}]*\}/g, "");
  t = t.replace(/\\[a-zA-Z]+-?\d* ?/g, "");
  t = t.replace(/[{}]/g, "");
  return t.replace(/\n{3,}/g, "\n\n").trim();
}

function sniffKind(buffer: Buffer, filename: string): string {
  const name = filename.toLowerCase();
  const head = buffer.subarray(0, 8);
  const ascii = buffer.subarray(0, 2048).toString("latin1");

  if (head[0] === 0x50 && head[1] === 0x4b) {
    // ZIP container — docx / odt / other OOXML
    if (name.endsWith(".odt")) return "odt";
    return "docx";
  }
  if (ascii.startsWith("%PDF")) return "pdf";
  if (ascii.startsWith("{\\rtf")) return "rtf";
  if (head[0] === 0xd0 && head[1] === 0xcf) return "legacy-doc";
  if (/<html[\s>]|<!doctype html/i.test(ascii)) return "html";
  if (name.endsWith(".md") || name.endsWith(".markdown")) return "markdown";
  if (name.endsWith(".json")) return "json";
  if (name.endsWith(".csv")) return "csv";
  if (name.endsWith(".html") || name.endsWith(".htm")) return "html";
  return "text";
}

async function extractDocx(buffer: Buffer) {
  const mammoth = (await import("mammoth")).default;
  const result = await mammoth.convertToHtml(
    { buffer },
    {
      styleMap: [
        "p[style-name='Title'] => h1:fresh",
        "p[style-name='Subtitle'] => h2:fresh",
        "p[style-name='Heading 1'] => h1:fresh",
        "p[style-name='Heading 2'] => h2:fresh",
        "p[style-name='Heading 3'] => h3:fresh",
        "p[style-name='Heading 4'] => h4:fresh",
        "p[style-name='Quote'] => blockquote > p:fresh",
        "p[style-name='Intense Quote'] => blockquote > p:fresh",
        "r[style-name='Strong'] => strong",
        "r[style-name='Emphasis'] => em",
      ],
    }
  );
  return {
    html: result.value || "<p></p>",
    warnings: (result.messages || [])
      .filter((m) => m.type === "warning" || m.type === "error")
      .map((m) => m.message)
      .slice(0, 8),
  };
}

async function extractPdf(buffer: Buffer) {
  const pdfjs: any = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const loadingTask = pdfjs.getDocument({
    data: new Uint8Array(buffer),
    useSystemFonts: true,
    isEvalSupported: false,
    disableFontFace: true,
  });
  const pdf: any = await loadingTask.promise;
  const pages: string[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    let lastY: number | null = null;
    let line = "";
    const lines: string[] = [];

    for (const item of content.items as unknown[]) {
      const anyItem = item as { str?: string; transform?: number[] };
      if (typeof anyItem.str !== "string") continue;
      const y = anyItem.transform ? Math.round(anyItem.transform[5]) : null;
      if (lastY !== null && y !== null && Math.abs(y - lastY) > 2) {
        if (line.trim()) lines.push(line.trim());
        line = "";
      }
      line += anyItem.str;
      lastY = y;
    }
    if (line.trim()) lines.push(line.trim());
    pages.push(lines.join("\n"));
  }

  try {
    await loadingTask.destroy();
  } catch {
    /* cleanup is best-effort */
  }

  const html = pages
    .map((text, idx) => {
      const body = text
        .split(/\n{2,}|\n(?=[A-Z0-9])/)
        .filter((p) => p.trim())
        .map((p) => `<p>${escapeHtml(p.trim().replace(/\n/g, " "))}</p>`)
        .join("");
      const divider =
        idx < pages.length - 1 ? "<hr>" : "";
      return (body || "<p></p>") + divider;
    })
    .join("");

  return { html: html || "<p></p>", pageCount: pdf.numPages };
}

function csvToHtml(text: string) {
  const rows = text
    .replace(/\r\n/g, "\n")
    .split("\n")
    .filter((r) => r.trim())
    .slice(0, 300)
    .map((r) => r.split(","));
  if (!rows.length) return "<p></p>";
  const head = rows[0]
    .map((c) => `<th><p>${escapeHtml(c.trim())}</p></th>`)
    .join("");
  const body = rows
    .slice(1)
    .map(
      (r) =>
        `<tr>${r
          .map((c) => `<td><p>${escapeHtml(c.trim())}</p></td>`)
          .join("")}</tr>`
    )
    .join("");
  return `<table><tbody><tr>${head}</tr>${body}</tbody></table>`;
}

function sanitizeHtml(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/\son\w+="[^"]*"/gi, "")
    .replace(/\son\w+='[^']*'/gi, "")
    .replace(/javascript:/gi, "");
}

function extractBodyHtml(html: string) {
  const body = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  return sanitizeHtml(body ? body[1] : html);
}

function guessTitle(html: string, filename: string) {
  for (const tag of ["h1", "h2", "h3"]) {
    const m = html.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
    if (m) {
      const t = m[1].replace(/<[^>]+>/g, "").trim();
      if (t) return t.slice(0, 160);
    }
  }
  const firstP = html.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
  if (firstP) {
    const t = firstP[1].replace(/<[^>]+>/g, "").trim();
    const looksLikeListItem = /^[☑☐•\-*\d]/.test(t);
    if (t.length > 3 && t.length < 90 && !looksLikeListItem) return t;
  }
  return filename.replace(/\.[^.]+$/, "") || "Imported document";
}

export async function importFileToHtml(
  buffer: Buffer,
  filename: string
): Promise<ImportResult> {
  const kind = sniffKind(buffer, filename);
  const warnings: string[] = [];
  let html = "<p></p>";
  let pageCount: number | undefined;

  switch (kind) {
    case "docx": {
      const res = await extractDocx(buffer);
      html = sanitizeHtml(res.html);
      warnings.push(...res.warnings);
      break;
    }
    case "odt": {
      // ODT is a zip with content.xml — try docx path, else fail gracefully
      try {
        const res = await extractDocx(buffer);
        html = sanitizeHtml(res.html);
      } catch {
        throw new Error(
          "OpenDocument (.odt) is not supported yet. Save as .docx and retry."
        );
      }
      break;
    }
    case "pdf": {
      const res = await extractPdf(buffer);
      html = res.html;
      pageCount = res.pageCount;
      warnings.push(
        "PDF text was extracted for editing. Original page layout, columns, and vector graphics are not preserved."
      );
      break;
    }
    case "legacy-doc": {
      throw new Error(
        "Legacy binary .doc files are not supported. Open in Word and 'Save As' .docx, then retry."
      );
    }
    case "rtf": {
      html = plainToHtmlBlocks(rtfToText(buffer.toString("utf8")));
      break;
    }
    case "html": {
      html = extractBodyHtml(buffer.toString("utf8"));
      break;
    }
    case "markdown": {
      html = markdownToHtml(buffer.toString("utf8"));
      break;
    }
    case "csv": {
      html = csvToHtml(buffer.toString("utf8"));
      break;
    }
    case "json": {
      const raw = buffer.toString("utf8");
      try {
        const parsed = JSON.parse(raw);
        if (typeof parsed?.html === "string") {
          html = sanitizeHtml(parsed.html);
        } else if (typeof parsed?.plain === "string") {
          html = plainToHtmlBlocks(parsed.plain);
        } else {
          html = `<pre><code>${escapeHtml(
            JSON.stringify(parsed, null, 2)
          )}</code></pre>`;
        }
        if (typeof parsed?.title === "string") {
          return {
            html,
            title: parsed.title,
            kind,
            warnings,
          };
        }
      } catch {
        html = plainToHtmlBlocks(raw);
      }
      break;
    }
    default: {
      html = plainToHtmlBlocks(buffer.toString("utf8"));
    }
  }

  if (!html.trim()) html = "<p></p>";

  return {
    html,
    title: guessTitle(html, filename),
    kind,
    warnings,
    pageCount,
  };
}
