import type { Editor } from "@tiptap/react";

/** TipTap command chain with extension commands (typed loosely for DX). */
export function chain(editor: Editor) {
  return editor.chain().focus() as any;
}

export function can(editor: Editor) {
  return editor.can() as any;
}
