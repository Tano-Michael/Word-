/**
 * Aether Grammar Engine — 40+ detection rules.
 *
 * Organized into tiers:
 *   1. Spelling (250+ misspellings)
 *   2. Confused words (then/than, affect/effect, etc.)
 *   3. Grammar (subject-verb, articles, pronouns, tense)
 *   4. Punctuation (commas, apostrophes, semicolons)
 *   5. Style & clarity (hedging, wordiness, clichés)
 *   6. Readability (long sentences, fragments)
 *   7. Consistency (hyphenation, capitalization)
 */

import type { GrammarIssue } from "./types";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

// ──────────────────────────────────────────────────────
// TIER 1 — Spelling
// ──────────────────────────────────────────────────────

const MISSPELLINGS: Record<string, string> = {
  // --- A–B ---
  abcess: "abscess", abscence: "absence", accross: "across",
  acheive: "achieve", acheived: "achieved", acheivement: "achievement",
  acknoledge: "acknowledge", adaption: "adaptation",
  address: "address", admiting: "admitting", adn: "and",
  advantagous: "advantageous", affor: "afford",
  agian: "again", aggrivate: "aggravate", alchohol: "alcohol",
  aledge: "allege", alledg: "allege", alleg: "allege",
  allmost: "almost", allready: "already", allthough: "although",
  alltogether: "altogether", alse: "else", alterior: "ulterior",
  ammend: "amend", ammendment: "amendment", anual: "annual",
  anyh: "any", anyw: "any",
  appartment: "appointment", appearence: "appearance",
  apporach: "approach", approch: "approach",
  arguement: "argument", arraival: "arrival",
  artic: "arctic", assest: "asset", assit: "assist",
  assosiate: "associate", asteer: "aster",
  atention: "attention", avaiable: "available",
  avalable: "available", awfull: "awful",

  becuse: "because", becasue: "because", becuase: "because",
  begining: "beginning", beging: "beginning",
  behaivior: "behavior", behav: "behavior",
  beleive: "believe", belive: "believe",
  bellive: "believe", benifit: "benefit", benifits: "benefits",
  beween: "between", boundry: "boundary",
  buisness: "business", buisnessman: "businessman",
  bizzare: "bizarre", breif: "brief", breifly: "briefly",

  // --- C–D ---
  caffiene: "caffeine", calander: "calendar", calender: "calendar",
  caligraphy: "calligraphy", camoflage: "camouflage",
  carribean: "caribbean", catagory: "category",
  cemetary: "cemetery", cemeter: "cemetery",
  changable: "changeable", charactor: "character",
  charecter: "character", cirkle: "circle",
  claen: "clean", colum: "column", colums: "columns",
  comming: "coming", commitee: "committee",
  committe: "committee", comparision: "comparison",
  compelx: "complex", competant: "competent",
  complay: "comply", compleat: "complete",
  compleately: "completely", completly: "completely",
  concensus: "consensus", concious: "conscious",
  conciousness: "consciousness", consciencious: "conscientious",
  consicious: "conscious", consitant: "consistent",
  constanly: "constantly", convienent: "convenient",
  convient: "convenient", coppy: "copy",
  copywrite: "copyright", corperate: "corporate",
  coud: "could", coudl: "could", creater: "creator",
  critisism: "criticism", critisize: "criticize",
  curren: "current", custome: "custom",

  daut: "doubt", deafult: "default", decison: "decision",
  decid: "decide", definately: "definitely",
  definatly: "definitely", definetly: "definitely",
  defintely: "definitely", definit: "definite",
  delima: "dilema", depen: "depend", dependant: "dependent",
  dependanc: "dependency", desparate: "desperate",
  devloped: "developed", devloping: "developing",
  develope: "develop", dicover: "discover",
  diction: "dictionary", didint: "didn't",
  didnot: "didn't", didnt: "didn't", diffrent: "different",
  differe: "different", differenc: "difference",
  dilemma: "dilemma", dimensio: "dimension",
  directer: "director", disaffect: "dissatisfy",
  discconect: "disconnect", discoverd: "discovered",
  discription: "description", disapoint: "disappoint",
  disapear: "disappear", disatisfaction: "dissatisfaction",
  disctinct: "distinct",
  dissappear: "disappear", divise: "device",
  documnet: "document",
  docrtrine: "doctrine", doesn: "doesn't",
  doesnt: "doesn't", dogma: "dogma",
  domino: "domino", dosnt: "doesn't", dounle: "double",
  doxument: "document", drastik: "drastic",
  drinkign: "drinking", drivig: "driving",

  // --- E–F ---
  echoeing: "echoing", ecomonic: "economic",
  eductation: "education", effectiv: "effective",
  eiter: "either", elimate: "eliminate",
  embarras: "embarrass", emenent: "eminent",
  emminent: "eminent", emmediat: "immediate",
  emparially: "impartially", emphysis: "emphasis",
  enought: "enough", entrepeneur: "entrepreneur",
  enveroment: "environment", enviroment: "environment",
  envirment: "environment", envirnoment: "environment",
  equiptment: "equipment", esentially: "essentially",
  espeically: "especially", essentail: "essential",
  essential: "essential", etcectera: "et cetera",
  euphamism: "euphemism", eventh: "event",
  evenually: "eventually", everbody: "everybody",
  everybodys: "everybody's", everyine: "everyone",
  everyione: "everyone", everyody: "everybody",
  everythig: "everything", exagerate: "exaggerate",
  exagerrate: "exaggerate", examion: "exam",
  exapmle: "example", excercise: "exercise",
  excpetion: "exception", excpet: "except",
  exeperienced: "experienced", experiance: "experience",
  experince: "experience", explict: "explicit",
  explicitely: "explicitly", expresso: "espresso",
  extreem: "extreme", extrodinary: "extraordinary",
  exspecialy: "especially",

  facinating: "fascinating", facist: "fascist",
  faeture: "feature", familar: "familiar",
  feasable: "feasible", feild: "field",
  finaly: "finally", finalyl: "finally",
  financialy: "financially", flameable: "flammable",
  floresent: "fluorescent", fo: "for",
  foriegn: "foreign", formall: "formally",
  fourty: "forty", freind: "friend",
  freinds: "friends", freindly: "friendly",
  frome: "from", fulfill: "fulfill",
  futher: "further", futhermore: "furthermore",

  // --- G–I ---
  generaly: "generally", geniune: "genuine",
  geting: "getting", giv: "give", glamor: "glamour",
  glossry: "glossary", goeverment: "government",
  goig: "going", goign: "going", goverment: "government",
  grammer: "grammar", greif: "grief",
  guage: "gauge", guarentee: "guarantee",
  gurantee: "guarantee", gusset: "gusset",

  habbit: "habit", halleujah: "hallelujah",
  harrased: "harassed", harrass: "harass",
  harrassment: "harassment", hasnt: "hasn't",
  "havent": "haven't",
  heiroglyph: "hieroglyph", heros: "heroes",
  hiegth: "height", higway: "highway",
  hindrence: "hindrance", histry: "history",
  homogenious: "homogeneous", horable: "horrible",
  horible: "horrible", humerous: "humorous",
  hundered: "hundred", hypothes: "hypothesis",
  hypothetical: "hypothetical",

  identifer: "identifier", ihs: "his",
  imediate: "immediate", imediatly: "immediately",
  immediat: "immediate", immediatly: "immediately",
  importent: "important", importnat: "important",
  impossable: "impossible", improvment: "improvement",
  incldue: "include", incloud: "include",
  incresed: "increased", indespensable: "indispensable",
  indispensible: "indispensable", infastructure: "infrastructure",
  infrastucture: "infrastructure", intead: "instead",
  intellegent: "intelligent", intially: "initially",
  intresting: "interesting", intruduce: "introduce",
  irregardless: "regardless", irrevelent: "irrelevant",
  irrevelant: "irrelevant", ist: "is",
  itsself: "itself",

  // --- J–L ---
  januray: "January", jeapordize: "jeopardize",
  jeopardy: "jeopardy", jery: "Jerry",
  judg: "judge", judgemnt: "judgment",
  judement: "judgment", judical: "judicial",
  kindergarden: "kindergarten", knowldeg: "knowledge",
  knowlege: "knowledge",

  labratory: "laboratory", labtop: "laptop",
  lagnuage: "language", larg: "large",
  lavendar: "lavender", layed: "laid",
  leinient: "lenient", leisur: "leisure",
  libary: "library", liberry: "library",
  liason: "liaison", libel: "libel",
  lible: "libel", liscense: "license",
  lisense: "license",
  lonly: "lonely", lookign: "looking",
  loosing: "loosing", loseing: "losing",
  loveing: "loving", lukiemia: "leukemia",

  // --- M–O ---
  magasine: "magazine", maintenace: "maintenance",
  maintainance: "maintenance", maintainence: "maintenance",
  majoroty: "majority", managment: "management",
  manuever: "maneuver", marraige: "marriage",
  materal: "material", mathmatics: "mathematics",
  mearly: "merely", mediun: "medium",
  memento: "momento", memmory: "memory",
  menally: "mentally", ment: "meant",
  mesage: "message", miht: "might",
  mileu: "milieu", millenium: "millennium",
  milenial: "millennial", millitary: "military",
  miniscule: "minuscule", miniture: "miniature",
  mintue: "minute", miscelaneous: "miscellaneous",
  mischeivous: "mischievous", mispell: "misspell",
  mispelling: "misspelling", mispel: "misspell",
  moblie: "mobile", modelt: "modest",
  moent: "moment", momey: "money",
  monoploy: "monopoly", mortage: "mortgage",
  moument: "moment", mrs: "Mrs.",
  munipulate: "manipulate", musuem: "museum",
  mutiply: "multiply", myster: "mystery",

  naigbor: "neighbor", neccessary: "necessary",
  neccesary: "necessary", necessar: "necessary",
  negligable: "negligible", negligble: "negligible",
  neigbor: "neighbor", neolitic: "neolithic",
  noticable: "noticeable",
  noticible: "noticeable", nowdays: "nowadays",
  nucular: "nuclear", nuisence: "nuisance",

  obcect: "object", obejct: "object",
  observ: "observe", obssesed: "obsessed",
  occassion: "occasion", occasionly: "occasionally",
  oclock: "o'clock", ocurrence: "occurrence",
  offical: "official", onot: "not",
  opon: "upon", opose: "oppose",
  oridin: "ordinary", organation: "organization",
  orignal: "original", ostentatious: "ostentatious",
  ouccured: "occurred", oustanding: "outstanding",
  overthere: "over there",

  // --- P–R ---
  pacific: "specific", pagenation: "pagination",
  pamphlet: "pamphlet", paralel: "parallel",
  paralell: "parallel", parlament: "parliament",
  parliment: "parliament", partical: "particle",
  partcularly: "particularly", passable: "passable",
  passivly: "passively", payed: "paid",
  peice: "piece", peices: "pieces",
  pendnt: "pendant", penitent: "penitent",
  percieve: "perceive", percent: "percent",
  performace: "performance", permanant: "permanent",
  permanetly: "permanently", permisison: "permission",
  peronal: "personal", persistance: "persistence",
  personnal: "personal", personell: "personnel",
  persue: "pursue", pharoh: "pharaoh",
  phenomenom: "phenomenon", phenominon: "phenomenon",
  pigion: "pigeon", platfrom: "platform",
  playright: "playwright", pluggin: "plugin",
  pneuemonia: "pneumonia", polictical: "political",
  posession: "possession", postive: "positive",
  pottential: "potential", poweful: "powerful",
  prairie: "prairie", preced: "precede",
  preceed: "precede", preceeds: "precedes",
  precidence: "precedence", prefered: "preferred",
  preferr: "prefer", prefrence: "preference",
  preformance: "performance", presense: "presence",
  presidant: "president", prestigous: "prestigious",
  privledge: "privilege", priviledge: "privilege",
  probaly: "probably",
  probel: "problem", procede: "proceed",
  proceding: "proceeding", processer: "processor",
  proffessional: "professional", proffesional: "professional",
  programer: "programmer", promiss: "promise",
  pronounciation: "pronunciation", propoganda: "propaganda",
  prossecut: "prosecute", protext: "protect",
  psycology: "psychology", puctuation: "punctuation",
  puncutre: "puncture", pursuade: "persuade",
  purtaining: "pertaining",

  que: "queue", queston: "question",

  recieve: "receive", recieved: "received", reciept: "receipt",
  recievd: "received", recommand: "recommend",
  challange: "challenge", challanged: "challenged",
  deliever: "deliver", delievered: "delivered",
  reccommend: "recommend", recommedn: "recommend",
  reconize: "recognize", refered: "referred",
  refere: "refer", registor: "register",
  religous: "religious", relious: "religious",
  relise: "realize", rember: "remember",
  remeber: "remember", rememebr: "remember",
  repear: "repair", repitition: "repetition",
  represnt: "represent", reserch: "research",
  resourse: "resource",
  resorce: "resource", respectivly: "respectively",
  responde: "response", responcible: "responsible",
  respon: "respond", responsib: "responsible",
  restarant: "restaurant", resturant: "restaurant",
  restarunt: "restaurant", rythm: "rhythm",
  rythmic: "rhythmic",

  // --- S–U ---
  sacreligious: "sacrilegious", saftey: "safety",
  sceneary: "scenery", schdule: "schedule",
  seach: "search", secrtary: "secretary",
  seige: "siege", senoir: "senior",
  sentance: "sentence",
  sentense: "sentence", seperate: "separate",
  seperat: "separate", seprate: "separate",
  sercumstance: "circumstance", sevice: "service",
  shcool: "school",
  shoud: "should", shoudl: "should",
  shouldnt: "shouldn't", simlar: "similar",
  similiar: "similar", simlilar: "similar",
  sismilar: "similar", sitck: "stick",
  sitation: "situation", skillfull: "skilful",
  soical: "social", soliliquy: "soliloquy",
  somthing: "something", speach: "speech",
  specif: "specific", specifiy: "specify",
  strenght: "strength", strengh: "strength",
  subscribtion: "subscription", successfull: "successful",
  succesful: "successful", sucess: "success",
  suffce: "suffice", sumary: "summary",
  suprise: "surprise", suprize: "surprise",
  surogate: "surrogate", sujest: "suggest",
  supercede: "supersede", suposed: "supposed",
  sur: "sure", surgar: "sugar",
  supersoni: "supersonic", suscesful: "successful",
  suscessful: "successful", susinct: "succinct",
  sutble: "subtle", tahn: "than",
  taht: "that", tath: "that",
  teh: "the", tehy: "they",
  tempr: "temper",
  temperture: "temperature", tenacle: "tentacle",
  tendancy: "tendency", tention: "tension",
  terriable: "terrible", terriably: "terribly",
  teritory: "territory", terriroty: "territory",
  territoyr: "territory", therefor: "therefore",
  thiere: "their", thier: "their",
  thorogh: "thorough", thourough: "thorough",
  throuroughly: "thoroughly", throught: "through",
  tiem: "time", togehter: "together",
  tommorrow: "tomorrow", tomorow: "tomorrow",
  tounge: "tongue", towrad: "toward",
  truht: "truth", truely: "truly",
  truley: "truly", ture: "true",
  tyhat: "that", tyme: "time",
  typicall: "typically",

  ubt: "but", undar: "under", unforseen: "unforeseen",
  unfortunatly: "unfortunately",
  unil: "until", untill: "until",
  usally: "usually", usualyl: "usually",
  utilties: "utilities",

  // --- V–Z ---
  vaccum: "vacuum", vaccuum: "vacuum",
  vacume: "vacuum", vegtable: "vegetable",
  veiw: "view", vialin: "violin",
  visious: "vicious",
  visiter: "visitor", voacal: "vocal",
  volitile: "volatile", volkswagon: "volkswagen",
  vunerable: "vulnerable", wether: "whether",
  wehre: "where", whcih: "which",
  whent: "went",
  wheras: "whereas", whch: "which",
  whihc: "which", whitch: "which",
  whoch: "which", whould: "would",
  widly: "widely", wiew: "view",
  wih: "with", wiht: "with",
  wihtout: "without", wirt: "with",
  wokr: "work", worls: "world",
  woudl: "would", wraite: "write",
  writeing: "writing", writting: "writing",
  yatch: "yacht", yera: "year",
  yeras: "years", youe: "you",
  youll: "you'll", yount: "young",
  youre: "you're", youve: "you've",

  // --- Contractions and informal ---
  wouldnt: "wouldn't", wont: "won't",
  werent: "weren't", arent: "aren't", im: "I'm",
  ive: "I've", id: "I'd", ill: "I'll",
  theyre: "they're", theyve: "they've", theyll: "they'll",
  weve: "we've",
  shes: "she's", hes: "he's",
  thats: "that's", whos: "who's", whats: "what's",
  heres: "here's", theres: "there's",
  lets: "let's",
};

// ──────────────────────────────────────────────────────
// TIER 2 — Confused words
// ──────────────────────────────────────────────────────

interface ConfusedRule {
  pattern: RegExp;
  /** Runs against match[1] — the word after the trigger */
  check: (after: string, match: RegExpExecArray) => boolean;
  suggestion: string;
  explanation: string;
  severity: GrammarIssue["severity"];
}

const CONFUSED_RULES: ConfusedRule[] = [
  // then/than
  {
    pattern: /\bdifferent\s+then\b/gi,
    check: () => true,
    suggestion: "different from",
    explanation: 'Use "different from" for a standard comparison, not "different then".',
    severity: "error",
  },
  {
    pattern: /\brather\s+then\b/gi,
    check: () => true,
    suggestion: "rather than",
    explanation: 'Use "rather than" (comparison), not "then" (sequence).',
    severity: "error",
  },
  {
    pattern: /\bmore\s+then\b/gi,
    check: () => true,
    suggestion: "more than",
    explanation: 'Use "more than" (comparison), not "then".',
    severity: "error",
  },
  {
    pattern: /\bless\s+then\b/gi,
    check: () => true,
    suggestion: "less than",
    explanation: 'Use "less than" (comparison), not "then".',
    severity: "error",
  },
  {
    pattern: /\bbetter\s+then\b/gi,
    check: () => true,
    suggestion: "better than",
    explanation: 'Use "better than" (comparison), not "then".',
    severity: "error",
  },

  // affect/effect
  {
    pattern: /\b(effect|affect)\s+(on|of|upon|the|a|an|this|that|our|its|their|your)\b/gi,
    check: (_a, m) => m[1].toLowerCase() === "affect",
    suggestion: "effect",
    explanation: '"Effect" is the noun (the effect of). "Affect" is the verb (to affect).',
    severity: "error",
  },
  {
    pattern: /\bto\s+(effect|affect)\b/gi,
    check: (_a, m) => m[1].toLowerCase() === "effect",
    suggestion: "to affect",
    explanation: 'After "to", the verb form is "affect" (to affect change).',
    severity: "error",
  },

  // there/their/they're
  {
    pattern: /\bthere\s+(house|car|dog|cat|phone|key|book|idea|team|job|work|project|money|name|email|bag|shoes|clothes|food|room|desk|office|city|country)\b/gi,
    check: () => true,
    suggestion: "their",
    explanation: 'Use "their" (possessive), not "there" (place/existence).',
    severity: "error",
  },
  {
    pattern: /\btheir\s+(going|coming|leaving|working|doing|running|trying|playing|making|getting|having|being)\b/gi,
    check: () => true,
    suggestion: "they're",
    explanation: 'Use "they\'re" (they are) before a verb like "going".',
    severity: "error",
  },
  {
    pattern: /\bthere\s+(going|coming|leaving|working|doing|running|trying|playing|making|getting|having|being)\b/gi,
    check: () => true,
    suggestion: "they're",
    explanation: 'Use "they\'re" (they are) before a verb like "going".',
    severity: "error",
  },
  {
    pattern: /\btheir\s+(is|are|was|were|will|can|could|should|would|must|might|has|have|had)\b/gi,
    check: () => true,
    suggestion: "there",
    explanation: 'Use "there" (existential), not "their" (possessive).',
    severity: "error",
  },
  {
    pattern: /\bthey're\s+(house|car|dog|cat|phone|key|book|idea|team|job|work|project|money|stuff|name|email|phone|bag|shoes|clothes|food|room|desk|office|city|country)\b/gi,
    check: () => true,
    suggestion: "their",
    explanation: 'Use "their" (possessive), not "they\'re" (they are).',
    severity: "error",
  },

  // your/you're
  {
    pattern: /\byour\s+(going|coming|leaving|working|doing|running|trying|playing|making|getting|having|being|welcome|right|wrong|sure|correct)\b/gi,
    check: () => true,
    suggestion: "you're",
    explanation: 'Use "you\'re" (you are) before a verb/adjective, not "your" (possessive).',
    severity: "error",
  },

  // its/it's
  {
    pattern: /\bits\s+(a|an|the|my|your|his|her|our|their|not|going|been|time|been|just|also|really|very|been|always|only|still|already|been|important)\b/gi,
    check: () => true,
    suggestion: "it's",
    explanation: 'Use "it\'s" (it is / it has) before articles, pronouns, and adverbs — not possessive "its".',
    severity: "error",
  },

  // who/whom
  {
    pattern: /\b(to|for|with|from|by|about|between|among)\s+(who)\b/gi,
    check: () => true,
    suggestion: "whom",
    explanation: 'After a preposition, use "whom" (object form), not "who" (subject).',
    severity: "suggestion",
  },

  // who's/whose
  {
    pattern: /\bwho's\s+(idea|car|house|phone|name|book|fault|turn|job|problem|responsibility|job|opinion|idea|place)\b/gi,
    check: () => true,
    suggestion: "whose",
    explanation: 'Use "whose" (possessive), not "who\'s" (who is).',
    severity: "error",
  },
];

// ──────────────────────────────────────────────────────
// TIER 3 — Grammar
// ──────────────────────────────────────────────────────

const SUBJECT_VERB_AGREEMENT: Array<{
  pattern: RegExp;
  suggestion: string;
  explanation: string;
}> = [
  { pattern: /\b(he|she|it)\s+don't\b/gi, suggestion: "doesn't", explanation: 'Use "doesn\'t" with he/she/it.' },
  { pattern: /\b(he|she|it)\s+have\b/gi, suggestion: "has", explanation: 'Use "has" with he/she/it.' },
  { pattern: /\b(he|she|it)\s+were\b/gi, suggestion: "was", explanation: 'Use "was" with he/she/it.' },
  { pattern: /\b(they|we)\s+was\b/gi, suggestion: "were", explanation: 'Use "were" with they/we.' },
  { pattern: /\b(they|we)\s+has\b/gi, suggestion: "have", explanation: 'Use "have" with they/we.' },
  { pattern: /\b(they|we|you)\s+doesn't\b/gi, suggestion: "don't", explanation: 'Use "don\'t" with they/we/you.' },
  { pattern: /\beverybody\s+(are|have|were|don't|doesn't)\b/gi, suggestion: "is/has/was/doesn't", explanation: '"Everybody" is singular — use singular verbs.' },
  { pattern: /\bsomeone\s+(are|have|were|don't|doesn't)\b/gi, suggestion: "is/has/was/doesn't", explanation: '"Someone" is singular — use singular verbs.' },
];

// Article a/an must be decided by SOUND, not spelling.
// Words starting with a vowel letter but a consonant sound ("university",
// "European", "one") take "a". Words starting with a consonant letter but a
// vowel sound ("hour", "honest", "MBA") take "an". These exception lists
// prevent the most common false positives.
const AN_BUT_CONSONANT_SOUND = /^(uni|use|user|usu|ubi|euro|eu|ewe|one|once|u\b|ufo|ukulele|unicorn|unique|unit|unil|unif|utop)/i;
const A_BUT_VOWEL_SOUND = /^(hour|honest|honor|honour|heir|herb\b|x|f|h\b|m\b|n\b|l\b|r\b|s\b|mba|mbe|fbi|nda|llc|rsvp|sos)/i;

const ARTICLE_ERRORS: Array<{
  pattern: RegExp;
  suggestion: string;
  explanation: string;
  skip?: (nextWord: string) => boolean;
}> = [
  {
    pattern: /\ba\s+([aeiou]\w*)/gi,
    suggestion: "an",
    explanation: 'Use "an" before a vowel sound (an apple, an hour).',
    // Skip when the vowel-letter word actually begins with a consonant sound.
    skip: (nextWord) => AN_BUT_CONSONANT_SOUND.test(nextWord),
  },
  {
    pattern: /\ban\s+([b-df-hj-np-tv-z]\w*)/gi,
    suggestion: "a",
    explanation: 'Use "a" before a consonant sound (a book, a car).',
    // Skip when the consonant-letter word actually begins with a vowel sound.
    skip: (nextWord) => A_BUT_VOWEL_SOUND.test(nextWord),
  },
];

// ──────────────────────────────────────────────────────
// TIER 4 — Punctuation
// ──────────────────────────────────────────────────────

const CONTRACTION_FIXES: Record<string, string> = {
  dont: "don't",
  doesnt: "doesn't",
  didnt: "didn't",
  cant: "can't",
  couldnt: "couldn't",
  shouldnt: "shouldn't",
  wouldnt: "wouldn't",
  wont: "won't",
  isnt: "isn't",
  arent: "aren't",
  wasnt: "wasn't",
  werent: "weren't",
  hasnt: "hasn't",
  havent: "haven't",
  hadnt: "hadn't",
  ive: "I've",
  youve: "you've",
  weve: "we've",
  theyve: "they've",
  hes: "he's",
  shes: "she's",
  thats: "that's",
  whats: "what's",
  heres: "here's",
  theres: "there's",
};

const PUNCTUATION_RULES: Array<{
  pattern: RegExp;
  suggestion: string;
  explanation: string;
  severity: GrammarIssue["severity"];
}> = [
  // Missing apostrophe in contractions
  { pattern: /\b(dont|doesnt|didnt|cant|couldnt|shouldnt|wouldnt|wont|isnt|arent|wasnt|werent|hasnt|havent|hadnt|ive|youve|weve|theyve|hes|shes|thats|whats|heres|theres)\b/gi,
    suggestion: "", explanation: 'Add an apostrophe to contractions (don\'t, doesn\'t, can\'t).', severity: "error" },

  // Missing space after punctuation
  { pattern: /[.,:;!?][A-Za-z]/g, suggestion: "", explanation: "Add a space after punctuation marks.", severity: "error" },

  // Double punctuation
  { pattern: /[.!?]{2,}/g, suggestion: ".", explanation: "Avoid repeated punctuation marks (unless intentional).", severity: "warning" },

  // Comma before "that" (nonrestrictive vs restrictive)
  { pattern: /,\s+that\s+(is|was|has|have|had|will|can|could|should|would|may|might)\b/gi,
    suggestion: "", explanation: 'Check whether the comma before "that" is needed. Restrictive clauses (essential info) don\'t take commas.', severity: "suggestion" },

  // Comma splice pattern (two independent clauses joined by just a comma)
  { pattern: /\b(I|we|they|he|she|it|you|this|that|there|here|everyone|someone|nobody|nothing|something)\s+[^,.!?]{10,80},\s+(I|we|they|he|she|it|you|this|that|there|here|everyone|someone|nobody|nothing|something)\s+(is|are|was|were|have|has|had|will|can|could|should|would|do|does|did|am|need|want|like|love|hate|think|believe|know)\b/gi,
    suggestion: "", explanation: "Possible comma splice — two independent clauses joined by only a comma. Use a semicolon, period, or conjunction.", severity: "warning" },

  // Space before comma/period
  { pattern: /\s+[,.;!?]/g, suggestion: "", explanation: "Remove the space before punctuation.", severity: "error" },
];

// ──────────────────────────────────────────────────────
// TIER 5 — Style & Clarity
// ──────────────────────────────────────────────────────

const HEDGING_PHRASES: Record<string, string> = {
  "i think that": "that",
  "i believe that": "that",
  "it seems like": "apparently",
  "it appears that": "",
  "it seems that": "",
  "it could be said that": "",
  "in my opinion": "",
  "in my personal opinion": "",
  "to be honest": "",
  "if you ask me": "",
  "it kind of": "it",
  "it sort of": "it",
};

const REDUNDANCIES: Record<string, string> = {
  "absolutely essential": "essential",
  "actual fact": "fact",
  "advance planning": "planning",
  "advance warning": "warning",
  "added bonus": "bonus",
  "ask a question": "ask",
  "at the present time": "now",
  "basic fundamentals": "fundamentals",
  "brief summary": "summary",
  "close proximity": "proximity",
  "collaborate together": "collaborate",
  "completely unanimous": "unanimous",
  "consensus of opinion": "consensus",
  "current trend": "trend",
  "end result": "result",
  "exact same": "same",
  "free gift": "gift",
  "future plans": "plans",
  "general public": "public",
  "important essentials": "essentials",
  "joint collaboration": "collaboration",
  "new innovation": "innovation",
  "past history": "history",
  "personal opinion": "opinion",
  "pre-planning": "planning",
  "protest against": "protest",
  "repeat again": "repeat",
  "return back": "return",
  "revert back": "revert",
  "still remains": "remains",
  "sudden impulse": "impulse",
  "surrounded on all sides": "surrounded",
  "unexpected surprise": "surprise",
  "usual custom": "custom",
  "whether or not": "whether",
};

const CLICHÉS: Record<string, string> = {
  "at the end of the day": "ultimately",
  "think outside the box": "think creatively",
  "paradigm shift": "major change",
  "low-hanging fruit": "easy wins",
  "synergy": "collaboration",
  "move the needle": "make progress",
  "circle back": "follow up",
  "deep dive": "detailed analysis",
  "touch base": "connect",
  "bandwidth": "capacity",
  "boil the ocean": "take on too much",
  "drink the kool-aid": "accept without question",
  "in the weeds": "in excessive detail",
  "peel the onion": "examine layer by layer",
  "win-win": "mutually beneficial",
  "level playing field": "fair conditions",
  "game changer": "major development",
  "double down": "commit further",
  "best practice": "standard approach",
  "thought leader": "expert",
  "value proposition": "offer",
  "core competency": "strength",
  "holistic approach": "comprehensive approach",
};

// ──────────────────────────────────────────────────────
// TIER 6 — Readability
// ──────────────────────────────────────────────────────

const SENTENCE_STARTERS: Record<string, string> = {
  "and": "And",
  "but": "But",
  "or": "Or",
  "so": "So",
  "yet": "Yet",
  "also": "Also",
  "then": "Then",
  "however": "However",
  "therefore": "Therefore",
  "moreover": "Moreover",
  "furthermore": "Furthermore",
  "meanwhile": "Meanwhile",
  "finally": "Finally",
  "specifically": "Specifically",
  "additionally": "Additionally",
};

// ──────────────────────────────────────────────────────
// TIER 7 — Consistency
// ──────────────────────────────────────────────────────

const DOUBLE_NEGATIVES: Array<{
  pattern: RegExp;
  suggestion: string;
  explanation: string;
}> = [
  { pattern: /\bdon'?t\s+have\s+no\b/gi, suggestion: "don't have any", explanation: 'Avoid double negatives: "don\'t have no" → "don\'t have any".' },
  { pattern: /\bcan'?t\s+get\s+no\b/gi, suggestion: "can't get any", explanation: 'Avoid double negatives: "can\'t get no" → "can\'t get any".' },
  { pattern: /\bwon'?t\s+never\b/gi, suggestion: "will never", explanation: 'Avoid double negatives: "won\'t never" → "will never".' },
  { pattern: /\bdon'?t\s+never\b/gi, suggestion: "don't ever", explanation: 'Avoid double negatives: "don\'t never" → "don\'t ever".' },
  { pattern: /\bain'?t\s+no\b/gi, suggestion: "isn't any", explanation: 'Avoid "ain\'t no" — use "isn\'t any" or "there isn\'t".' },
  { pattern: /\bhardly\s+(no|none|nothing|never|nobody)\b/gi, suggestion: "hardly any/ever", explanation: '"Hardly" already implies negation — don\'t pair it with negative words.' },
  { pattern: /\bscarcely\s+(no|none|nothing|never|nobody)\b/gi, suggestion: "scarcely any/ever", explanation: '"Scarcely" already implies negation.' },
  { pattern: /\bbarely\s+(no|none|nothing|never|nobody)\b/gi, suggestion: "barely any/ever", explanation: '"Barely" already implies negation.' },
];

// ──────────────────────────────────────────────────────
// MAIN ENGINE
// ──────────────────────────────────────────────────────

function sentBoundaries(text: string): Array<{ text: string; start: number }> {
  const results: Array<{ text: string; start: number }> = [];
  const re = /[^.!?]*[.!?]+[\s]*/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const s = m[0].trim();
    if (s.length > 2) results.push({ text: s, start: m.index + m[0].indexOf(s) });
  }
  // Catch trailing sentence without terminal punctuation
  const rest = text.slice(re.lastIndex).trim();
  if (rest.length > 2) results.push({ text: rest, start: text.lastIndexOf(rest) });
  return results;
}

export function runGrammarCheck(text: string): GrammarIssue[] {
  const issues: GrammarIssue[] = [];
  if (!text.trim() || text.trim().length < 5) return issues;

  let m: RegExpExecArray | null;

  // ── TIER 1: Spelling ──
  const wordRe = /\b[A-Za-z']+\b/g;
  while ((m = wordRe.exec(text)) !== null) {
    const raw = m[0];
    const lower = raw.toLowerCase();
    if (MISSPELLINGS[lower]) {
      let suggestion = MISSPELLINGS[lower];
      if (raw[0] === raw[0].toUpperCase() && raw[0] !== raw[0].toLowerCase()) {
        suggestion = suggestion.charAt(0).toUpperCase() + suggestion.slice(1);
      }
      issues.push({
        id: uid(),
        type: "spelling",
        original: raw,
        suggestion,
        explanation: `"${raw}" appears misspelled. Did you mean "${suggestion}"?`,
        severity: "error",
        start: m.index,
        end: m.index + raw.length,
      });
    }
  }

  // ── TIER 2: Confused words ──
  for (const rule of CONFUSED_RULES) {
    rule.pattern.lastIndex = 0;
    while ((m = rule.pattern.exec(text)) !== null) {
      if (!rule.check(m[1] || "", m)) continue;

      let suggestion = rule.suggestion;
      // Single-word suggestions fix one token inside the matched phrase rather
      // than replacing and accidentally deleting the phrase's surrounding word.
      if (!suggestion.includes(" ") && m[0].includes(" ")) {
        const tokens = m[0].split(/(\s+)/);
        if (suggestion.toLowerCase() === "whom") {
          for (let i = tokens.length - 1; i >= 0; i--) {
            if (/\w/.test(tokens[i])) {
              tokens[i] = suggestion;
              break;
            }
          }
          suggestion = tokens.join("");
        } else if (m[1] && ["affect", "effect"].includes(m[1].toLowerCase())) {
          // Patterns such as "affect on" capture the erroneous first token.
          suggestion = m[0].replace(new RegExp(`\\b${m[1]}\\b`, "i"), suggestion);
        } else {
          const first = tokens.findIndex((x) => /\w/.test(x));
          if (first >= 0) tokens[first] = suggestion;
          suggestion = tokens.join("");
        }
      }

      issues.push({
        id: uid(),
        type: "grammar",
        original: m[0],
        suggestion,
        explanation: rule.explanation,
        severity: rule.severity,
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // ── TIER 3: Subject-verb agreement ──
  for (const rule of SUBJECT_VERB_AGREEMENT) {
    rule.pattern.lastIndex = 0;
    while ((m = rule.pattern.exec(text)) !== null) {
      issues.push({
        id: uid(),
        type: "grammar",
        original: m[0],
        suggestion: m[0].replace(/\b(don't|doesn't|have|has|were|was|is|are)\b/i, rule.suggestion),
        explanation: rule.explanation,
        severity: "error",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // ── TIER 4: Punctuation ──
  for (const rule of PUNCTUATION_RULES) {
    rule.pattern.lastIndex = 0;
    while ((m = rule.pattern.exec(text)) !== null) {
      let suggestion = rule.suggestion;
      if (!suggestion) {
        const contraction = CONTRACTION_FIXES[m[0].toLowerCase()];
        if (contraction) {
          suggestion = contraction;
          if (/^[A-Z]/.test(m[0])) {
            suggestion = suggestion.charAt(0).toUpperCase() + suggestion.slice(1);
          }
        }
        // Auto-fix for space-after-punctuation and space-before-punctuation
        else if (m[0].length === 2 && /[.,:;!?]/.test(m[0][0]) && /[A-Za-z]/.test(m[0][1])) {
          suggestion = m[0][0] + " " + m[0][1];
        } else if (/^\s+[.,;!?]$/.test(m[0])) {
          suggestion = m[0].trim();
        }
      }
      if (suggestion && suggestion === m[0]) continue; // Skip if no actual change
      issues.push({
        id: uid(),
        type: "punctuation",
        original: m[0],
        suggestion: suggestion || "",
        explanation: rule.explanation,
        severity: rule.severity,
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // ── TIER 5: Style & Clarity ──
  // Wordiness
  for (const [phrase, alt] of Object.entries(HEDGING_PHRASES)) {
    const re = new RegExp(`\\b${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    while ((m = re.exec(text)) !== null) {
      issues.push({
        id: uid(),
        type: "style",
        original: m[0],
        suggestion: alt || "(remove)",
        explanation: alt
          ? `"${phrase}" is hedging language. Use the direct form: "${alt}".`
          : `"${phrase}" weakens your writing. Remove it for direct, confident prose.`,
        severity: "suggestion",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // Redundancies
  for (const [phrase, alt] of Object.entries(REDUNDANCIES)) {
    const re = new RegExp(`\\b${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    while ((m = re.exec(text)) !== null) {
      issues.push({
        id: uid(),
        type: "style",
        original: m[0],
        suggestion: alt,
        explanation: `"${phrase}" is redundant. Use "${alt}" instead.`,
        severity: "suggestion",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // Clichés
  for (const [phrase, alt] of Object.entries(CLICHÉS)) {
    const re = new RegExp(`\\b${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    while ((m = re.exec(text)) !== null) {
      issues.push({
        id: uid(),
        type: "style",
        original: m[0],
        suggestion: alt,
        explanation: `"${phrase}" is a cliché. Try "${alt}" for more precise, professional writing.`,
        severity: "suggestion",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // ── TIER 6: Readability ──
  const sents = sentBoundaries(text);
  for (const s of sents) {
    const wc = s.text.split(/\s+/).filter(Boolean).length;
    if (wc >= 35) {
      issues.push({
        id: uid(),
        type: "readability",
        original: s.text.slice(0, 80) + (s.text.length > 80 ? "…" : ""),
        suggestion: "Split into 2–3 shorter sentences.",
        explanation: `This sentence has ${wc} words. Sentences over 30 words are harder to read. Break them up.`,
        severity: "warning",
        start: s.start,
        end: s.start + s.text.length,
      });
    }
  }

  // ── TIER 7: Double negatives ──
  for (const rule of DOUBLE_NEGATIVES) {
    rule.pattern.lastIndex = 0;
    while ((m = rule.pattern.exec(text)) !== null) {
      issues.push({
        id: uid(),
        type: "grammar",
        original: m[0],
        suggestion: rule.suggestion,
        explanation: rule.explanation,
        severity: "error",
        start: m.index,
        end: m.index + m[0].length,
      });
    }
  }

  // ── TIER 7: Repeated words ──
  const rw = /\b(\w+)\s+\1\b/gi;
  while ((m = rw.exec(text)) !== null) {
    const word = m[1].toLowerCase();
    // Skip intentional repetitions ("very very", "had had")
    if (["very", "had", "do", "that", "no"].includes(word)) continue;
    issues.push({
      id: uid(),
      type: "repetition",
      original: m[0],
      suggestion: m[1],
      explanation: `Repeated word "${m[1]}". Remove the duplicate.`,
      severity: "warning",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // ── TIER 7: Double spaces ──
  const ds = / {2,}/g;
  while ((m = ds.exec(text)) !== null) {
    issues.push({
      id: uid(),
      type: "punctuation",
      original: m[0],
      suggestion: " ",
      explanation: "Multiple consecutive spaces — use a single space.",
      severity: "warning",
      start: m.index,
      end: m.index + m[0].length,
    });
  }

  // ── TIER 7: Sentence-start capitalization ──
  const sentRe = /(?:^|[.!?]\s+)([a-z])/g;
  while ((m = sentRe.exec(text)) !== null) {
    const idx = m.index + m[0].length - 1;
    issues.push({
      id: uid(),
      type: "grammar",
      original: text[idx],
      suggestion: text[idx].toUpperCase(),
      explanation: "Capitalize the first word of each sentence.",
      severity: "error",
      start: idx,
      end: idx + 1,
    });
  }

  // ── Deduplicate, clamp to text bounds, and cap ──
  const seen = new Set<string>();
  const textLen = text.length;
  return issues
    .filter((i) => {
      // Clamp offsets to valid range
      if (i.start < 0) i.start = 0;
      if (i.end > textLen) i.end = textLen;
      // Skip invalid ranges
      if (i.start >= i.end || i.end - i.start > textLen / 2) return false;
      const key = `${i.start}-${i.end}-${i.type}-${i.original}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => a.start - b.start)
    .slice(0, 80);
}
