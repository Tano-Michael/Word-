export type PanelId =
  | "none"
  | "ai"
  | "grammar"
  | "rewrite"
  | "protection"
  | "outline"
  | "comments"
  | "versions"
  | "export"
  | "insights"
  | "templates"
  | "research";

export type AiMode =
  | "write"
  | "continue"
  | "improve"
  | "summarize"
  | "expand"
  | "shorten"
  | "outline"
  | "brainstorm"
  | "translate"
  | "tone"
  | "explain"
  | "fix"
  | "meeting-notes"
  | "email"
  | "blog"
  | "proposal"
  | "resume"
  | "research";

export type RewriteStyle =
  | "standard"
  | "fluency"
  | "formal"
  | "simple"
  | "creative"
  | "expand"
  | "shorten"
  | "academic"
  | "casual"
  | "persuasive"
  | "confident"
  | "empathetic"
  | "seo";


export type RewriteScope = "selection" | "sentence" | "paragraph" | "document";

export interface RewriteTarget {
  scope: RewriteScope;
  label: string;
  text: string;
  from: number;
  to: number;
}

export type GrammarIssueType =
  | "spelling"
  | "grammar"
  | "punctuation"
  | "style"
  | "clarity"
  | "conciseness"
  | "tone"
  | "inclusivity"
  | "passive"
  | "wordy"
  | "repetition"
  | "readability";

export interface GrammarIssue {
  id: string;
  type: GrammarIssueType;
  original: string;
  suggestion: string;
  explanation: string;
  severity: "error" | "warning" | "suggestion";
  start: number;
  end: number;
}

export interface WritingInsights {
  wordCount: number;
  charCount: number;
  sentenceCount: number;
  paragraphCount: number;
  avgWordsPerSentence: number;
  readingTimeMin: number;
  speakingTimeMin: number;
  fleschReadingEase: number;
  gradeLevel: string;
  tone: {
    formal: number;
    confident: number;
    friendly: number;
    analytical: number;
  };
  passiveVoicePct: number;
  uniqueWordPct: number;
  topWords: { word: string; count: number }[];
  sentiment: "positive" | "neutral" | "negative" | "mixed";
}

export interface OutlineItem {
  id: string;
  level: number;
  text: string;
  pos?: number;
}

export interface DocumentListItem {
  id: string;
  title: string;
  plainText: string;
  wordCount: number;
  status: string;
  folder: string | null;
  tags: string[] | null;
  coverColor: string | null;
  aiSummary: string | null;
  readingLevel: string | null;
  isStarred: boolean;
  isTemplate: boolean;
  templateCategory: string | null;
  lastOpenedAt: string | Date | null;
  createdAt: string | Date;
  updatedAt: string | Date;
}

export interface TemplateDef {
  id: string;
  title: string;
  category: string;
  description: string;
  coverColor: string;
  content: string;
  promptHint: string;
}
