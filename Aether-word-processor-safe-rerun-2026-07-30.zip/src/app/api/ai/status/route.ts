import { NextResponse } from "next/server";
import { getProviderStatus } from "@/lib/online-ai";

export const dynamic = "force-dynamic";

export async function GET() {
  const status = getProviderStatus();
  return NextResponse.json({
    ok: true,
    ...status,
    freeOptions: {
      gemini: {
        available: true,
        name: "Google Gemini 2.5 Flash",
        limit: "500 requests/day",
        signupUrl: "https://aistudio.google.com/app/apikey",
        description:
          "Free API key, no credit card needed. Powers Copilot and Rewrite with cloud AI.",
      },
      languagetool: {
        available: status.onlineGrammar.available,
        name: "LanguageTool public API",
        limit: "20 requests/min, 20KB per check",
        signupUrl: null,
        description:
          "Built-in, no key needed. Click 'Check online' in the Grammar panel.",
      },
      openai: {
        available: true,
        name: "OpenAI GPT",
        limit: "$5 minimum prepaid",
        signupUrl: "https://platform.openai.com/api-keys",
        description: "Requires payment. Alternative if Gemini doesn't suit.",
      },
    },
    privacy: {
      localFallback: true,
      onlineGrammar:
        "Text is sent to LanguageTool only when you explicitly choose Check online.",
      cloudAi:
        "Cloud rewriting and Copilot requests are sent only to the configured provider. Keys are never exposed to the browser.",
    },
    setupGuide: "/GET-FREE-API-KEYS.md",
  });
}
