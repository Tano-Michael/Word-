import { NextResponse } from "next/server";
import { getProviderStatus, generateCloudText } from "@/lib/online-ai";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Live connectivity test for the configured cloud AI provider.
 * Returns a clear, human-readable diagnosis so users can see EXACTLY
 * why their key is or isn't working — no more silent fallback.
 */
export async function GET() {
  const status = getProviderStatus();

  // Which env vars are present (without ever exposing the actual key)
  const keyPresence = {
    OPENAI_API_KEY: mask(process.env.OPENAI_API_KEY),
    ANTHROPIC_API_KEY: mask(process.env.ANTHROPIC_API_KEY),
    GEMINI_API_KEY: mask(process.env.GEMINI_API_KEY),
    GOOGLE_API_KEY: mask(process.env.GOOGLE_API_KEY),
    AETHER_AI_PROVIDER: process.env.AETHER_AI_PROVIDER || "(not set)",
  };

  if (!status.cloudAi.available) {
    return NextResponse.json({
      ok: false,
      stage: "configuration",
      configured: false,
      provider: null,
      keyPresence,
      message:
        "No cloud AI provider is configured. No API key was found in the server environment.",
      fixes: [
        "Make sure your key is in a file named exactly `.env` in the Aether folder (not .env.txt).",
        "The line must look like:  GEMINI_API_KEY=AIzaSy...   (no quotes, no spaces around =).",
        "Also add:  AETHER_AI_PROVIDER=gemini",
        "Fully close the Aether server window and start Aether.bat again — env vars load only at startup.",
      ],
    });
  }

  // A provider IS configured — actually call it and report the real result.
  const started = Date.now();
  const result = await generateCloudText(
    "generate",
    "Reply with exactly these three words: Aether connection works"
  );
  const elapsedMs = Date.now() - started;

  if (result.online && result.text.trim()) {
    return NextResponse.json({
      ok: true,
      stage: "success",
      configured: true,
      provider: result.provider,
      model: result.model,
      keyPresence,
      elapsedMs,
      sample: result.text.slice(0, 120),
      message: `✅ ${result.provider} (${result.model}) is connected and responding in ${elapsedMs}ms.`,
    });
  }

  // Configured but the call failed — surface the exact provider error.
  return NextResponse.json({
    ok: false,
    stage: "request-failed",
    configured: true,
    provider: status.cloudAi.provider,
    model: status.cloudAi.model,
    keyPresence,
    elapsedMs,
    error: result.error,
    message: `⚠️ ${status.cloudAi.provider} is configured but the request failed.`,
    fixes: diagnoseError(result.error, status.cloudAi.provider),
  });
}

function mask(value: string | undefined): string {
  const v = value?.trim();
  if (!v) return "(missing)";
  if (v.length < 8) return "(present, but suspiciously short)";
  return `present ✓ (${v.slice(0, 4)}…${v.slice(-3)}, ${v.length} chars)`;
}

function diagnoseError(
  error: string | undefined,
  provider: string | null
): string[] {
  const e = (error || "").toLowerCase();
  const fixes: string[] = [];

  if (e.includes("401") || e.includes("unauthorized") || e.includes("api_key_invalid") || e.includes("api key not valid")) {
    fixes.push("Your API key is invalid or was copied incorrectly. Re-copy the full key and save it again.");
    if (provider === "gemini") {
      fixes.push("Get a fresh free key at https://aistudio.google.com/app/apikey");
    }
  } else if (e.includes("403") || e.includes("permission")) {
    fixes.push("The key is valid but lacks permission. For Gemini, ensure the Generative Language API is enabled on the key's project.");
  } else if (e.includes("429") || e.includes("quota") || e.includes("rate")) {
    fixes.push("You hit the rate/quota limit. Free Gemini allows 500 requests/day, 15/minute. Wait a minute and retry.");
  } else if (e.includes("model") && (e.includes("not found") || e.includes("404"))) {
    fixes.push(`The model name is wrong. For Gemini use GEMINI_MODEL=gemini-2.5-flash. For OpenAI use OPENAI_MODEL=gpt-4.1-mini.`);
  } else if (e.includes("timeout") || e.includes("abort") || e.includes("fetch failed") || e.includes("enotfound")) {
    fixes.push("Could not reach the provider. Check your internet connection or firewall.");
  } else {
    fixes.push("Check the exact error above. Re-save the key and restart Aether.bat.");
  }

  return fixes;
}
