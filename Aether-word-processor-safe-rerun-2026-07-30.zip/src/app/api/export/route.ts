import { NextRequest, NextResponse } from "next/server";
import { htmlToPlain } from "@/lib/ai-engine";
import { htmlToDocxBuffer } from "@/lib/html-to-docx";
import { createFallbackDocxBuffer } from "@/lib/fallback-docx";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_EXPORT_HTML_BYTES = 25 * 1024 * 1024;
const SUPPORTED_FORMATS = new Set([
  "docx",
  "doc",
  "md",
  "markdown",
  "html",
  "json",
  "txt",
]);

function htmlToMarkdown(html: string): string {
  let md = html;
  md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, "# $1\n\n");
  md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, "## $1\n\n");
  md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, "### $1\n\n");
  md = md.replace(/<h4[^>]*>(.*?)<\/h4>/gi, "#### $1\n\n");
  md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**");
  md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**");
  md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*");
  md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, "*$1*");
  md = md.replace(/<u[^>]*>(.*?)<\/u>/gi, "$1");
  md = md.replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)");
  md = md.replace(/<li[^>]*>(.*?)<\/li>/gi, "- $1\n");
  md = md.replace(/<\/?ul[^>]*>/gi, "\n");
  md = md.replace(/<\/?ol[^>]*>/gi, "\n");
  md = md.replace(/<br\s*\/?>/gi, "\n");
  md = md.replace(/<\/p>/gi, "\n\n");
  md = md.replace(/<p[^>]*>/gi, "");
  md = md.replace(/<[^>]+>/g, "");
  md = md
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"');
  return md.replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

function wrapDocxLite(title: string, plain: string) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${title}</title></head><body>${plain
    .split(/\n{2,}/)
    .map((p) =>
      `<p>${p
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/\n/g, "<br>")}</p>`
    )
    .join("")}</body></html>`;
}

function safeFilenameBase(raw: string): string {
  return (
    String(raw || "document")
      .normalize("NFKC")
      .replace(/[\u0000-\u001f<>:"/\\|?*]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/[. ]+$/g, "")
      .slice(0, 120) || "document"
  );
}

function contentDisposition(base: string, extension: string): string {
  const fullUnicode = `${base}.${extension}`;
  const asciiBase =
    base
      .normalize("NFKD")
      .replace(/[^\x20-\x7e]/g, "")
      .replace(/["\\;]/g, "")
      .trim() || "document";
  const ascii = `${asciiBase}.${extension}`;
  const encoded = encodeURIComponent(fullUnicode).replace(
    /['()]/g,
    (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`
  );
  return `attachment; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}

function attachmentHeaders(
  contentType: string,
  base: string,
  extension: string,
  extra: Record<string, string> = {}
) {
  return {
    "Content-Type": contentType,
    "Content-Disposition": contentDisposition(base, extension),
    "Cache-Control": "private, no-store, no-transform",
    "X-Content-Type-Options": "nosniff",
    ...extra,
  };
}

async function readExportPayload(req: NextRequest) {
  const contentType = req.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    const body = await req.json();
    return {
      title: body?.title,
      html: body?.html,
      format: body?.format,
    };
  }

  if (
    contentType.includes("multipart/form-data") ||
    contentType.includes("application/x-www-form-urlencoded")
  ) {
    const form = await req.formData();
    return {
      title: form.get("title")?.toString(),
      html: form.get("html")?.toString(),
      format: form.get("format")?.toString(),
    };
  }

  throw new Error("UNSUPPORTED_CONTENT_TYPE");
}

export async function POST(req: NextRequest) {
  try {
    const payload = await readExportPayload(req);
    const title = String(payload.title || "document");
    const html = String(payload.html || "");
    const format = String(payload.format || "txt").toLowerCase();

    if (!SUPPORTED_FORMATS.has(format)) {
      return NextResponse.json(
        { error: `Unsupported export format: ${format}` },
        { status: 400 }
      );
    }

    if (Buffer.byteLength(html, "utf8") > MAX_EXPORT_HTML_BYTES) {
      return NextResponse.json(
        {
          error:
            "This document is too large to export in one pass. Remove or resize very large embedded images and try again.",
        },
        { status: 413 }
      );
    }

    const plain = htmlToPlain(html);
    const safe = safeFilenameBase(title);

    if (format === "md" || format === "markdown") {
      const md = htmlToMarkdown(html);
      return new NextResponse(md, {
        headers: attachmentHeaders("text/markdown; charset=utf-8", safe, "md"),
      });
    }

    if (format === "html") {
      const full = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${safe}</title>
<style>body{font-family:Georgia,serif;max-width:720px;margin:40px auto;line-height:1.7;color:#111}
h1,h2,h3{line-height:1.25} p{margin:0 0 1em}</style></head><body>${html}</body></html>`;
      return new NextResponse(full, {
        headers: attachmentHeaders("text/html; charset=utf-8", safe, "html"),
      });
    }

    if (format === "docx") {
      let buffer: Buffer;
      let exportMode = "rich";
      try {
        buffer = await htmlToDocxBuffer(html, safe);
        if (buffer.length < 4 || buffer.subarray(0, 2).toString("ascii") !== "PK") {
          throw new Error("Rich DOCX generator returned an invalid ZIP signature.");
        }
      } catch (richError) {
        console.error(
          "Rich DOCX export failed; using compatibility fallback:",
          richError
        );
        buffer = createFallbackDocxBuffer(html, safe);
        exportMode = "compatibility";
      }

      return new NextResponse(new Uint8Array(buffer), {
        headers: attachmentHeaders(
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          safe,
          "docx",
          {
            "Content-Length": String(buffer.byteLength),
            "X-Aether-Export-Mode": exportMode,
          }
        ),
      });
    }

    if (format === "doc") {
      const doc = wrapDocxLite(safe, plain);
      return new NextResponse(doc, {
        headers: attachmentHeaders(
          "application/msword; charset=utf-8",
          safe,
          "doc"
        ),
      });
    }

    if (format === "json") {
      const payloadJson = JSON.stringify(
        {
          title,
          html,
          plain,
          exportedAt: new Date().toISOString(),
        },
        null,
        2
      );
      return new NextResponse(payloadJson, {
        headers: attachmentHeaders(
          "application/json; charset=utf-8",
          safe,
          "json"
        ),
      });
    }

    return new NextResponse(plain, {
      headers: attachmentHeaders("text/plain; charset=utf-8", safe, "txt"),
    });
  } catch (error) {
    if (error instanceof Error && error.message === "UNSUPPORTED_CONTENT_TYPE") {
      return NextResponse.json(
        { error: "Export request must be JSON or form data." },
        { status: 415 }
      );
    }
    console.error("Export failed:", error);
    return NextResponse.json(
      { error: "Export failed. Please retry or run Aether diagnostics." },
      { status: 500 }
    );
  }
}
