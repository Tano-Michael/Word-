import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import path from "node:path";
import fs from "node:fs";
import { dbReady, requireDb, isEmbedded, getInitError } from "@/db";
import { htmlToDocxBuffer } from "@/lib/html-to-docx";
import { createFallbackDocxBuffer } from "@/lib/fallback-docx";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface Check {
  name: string;
  ok: boolean;
  detail: string;
}

export async function GET() {
  const checks: Check[] = [];

  checks.push({
    name: "Node.js runtime",
    ok: true,
    detail: `${process.version} on ${process.platform} (${process.arch})`,
  });

  checks.push({
    name: "Database mode",
    ok: true,
    detail: isEmbedded
      ? "Embedded (built-in, no installation needed)"
      : "PostgreSQL server via DATABASE_URL",
  });

  const dataDir = path.join(process.cwd(), "data");
  let dataWritable = false;
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    fs.accessSync(dataDir, fs.constants.W_OK);
    dataWritable = true;
  } catch {
    /* below */
  }
  checks.push({
    name: "Data folder writable",
    ok: !isEmbedded || dataWritable,
    detail: dataWritable
      ? dataDir
      : `Cannot write to ${dataDir} — move the Aether folder out of "Program Files" or OneDrive, then try again.`,
  });

  let dbOk = false;
  let dbDetail = "not tested";
  try {
    await dbReady;
    const db = requireDb();
    const res = await db.execute(sql`select count(*) as n from documents`);
    const rows = (res as { rows?: { n: string | number }[] }).rows ?? [];
    dbOk = true;
    dbDetail = `Connected · ${rows[0]?.n ?? 0} document(s) stored`;
  } catch (error) {
    dbDetail =
      (error instanceof Error ? error.message : String(error)) ||
      "connection failed";
  }
  checks.push({
    name: "Database reachable",
    ok: dbOk,
    detail: dbDetail,
  });

  let docxOk = false;
  let docxDetail = "not tested";
  try {
    const sample = await htmlToDocxBuffer(
      "<h1>Aether export test</h1><p>Word export is working.</p>",
      "Aether export test"
    );
    docxOk = sample.length > 100 && sample.subarray(0, 2).toString("ascii") === "PK";
    docxDetail = docxOk
      ? `Rich DOCX engine ready · ${sample.length} byte test file`
      : "Rich DOCX engine returned invalid data";
  } catch (error) {
    try {
      const fallback = createFallbackDocxBuffer(
        "<p>Word export compatibility test.</p>",
        "Aether export test"
      );
      docxOk =
        fallback.length > 100 &&
        fallback.subarray(0, 2).toString("ascii") === "PK";
      docxDetail = docxOk
        ? `Compatibility DOCX engine ready; rich engine error: ${
            error instanceof Error ? error.message : String(error)
          }`
        : "Both DOCX engines failed their self-test";
    } catch (fallbackError) {
      docxDetail = `Rich engine: ${
        error instanceof Error ? error.message : String(error)
      }; compatibility engine: ${
        fallbackError instanceof Error
          ? fallbackError.message
          : String(fallbackError)
      }`;
    }
  }
  checks.push({
    name: "DOCX export engine",
    ok: docxOk,
    detail: docxDetail,
  });

  const initError = getInitError();

  const advice: string[] = [];
  if (!dbOk) {
    if (isEmbedded) {
      advice.push(
        "Close Aether completely, open the app folder, DELETE the 'data' folder, then double-click Aether.bat again."
      );
      advice.push(
        "If you extracted Aether into 'Program Files', AppData-roving, or inside OneDrive/Dropbox, move the folder to somewhere simple like C:\\Aether and try again."
      );
      advice.push(
        "Temporarily disable real-time antivirus scanning on the Aether folder, then retry."
      );
    } else {
      advice.push(
        "Verify DATABASE_URL inside .env and make sure the PostgreSQL service is running."
      );
    }
  }
  if (!docxOk) {
    advice.push(
      "DOCX export is not healthy. Run UPDATE.bat, restart Aether, and open /api/diagnose again."
    );
  }
  if (initError) advice.push(`Startup error: ${initError}`);
  if (!advice.length) advice.push("Everything looks healthy.");

  return NextResponse.json({
    ok: checks.every((c) => c.ok),
    checks,
    advice,
    initError,
    node: process.version,
    platform: `${process.platform}/${process.arch}`,
    cwd: process.cwd(),
    time: new Date().toISOString(),
  });
}
