"use client";

import { useEffect } from "react";
import Link from "next/link";

/**
 * Global error boundary. Next.js calls this if a client render throws
 * before or above the app tree. Prevents the blank-white-page failure
 * mode and gives users a clear way to recover instead of guessing.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[Aether] Uncaught render error", error);
  }, [error]);

  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">
        <main className="mx-auto flex min-h-screen max-w-lg flex-col items-center justify-center gap-4 px-6 py-16 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-2xl font-black shadow-2xl shadow-indigo-500/30">
            Æ
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Something went wrong on this screen
          </h1>
          <p className="text-sm leading-relaxed text-slate-400">
            The rest of Aether is still running normally. Your documents are
            saved on disk and were not affected. Please try again, or return to
            your library.
          </p>
          {error?.digest && (
            <p className="text-xs text-slate-500">
              Error ref:{" "}
              <code className="rounded bg-white/5 px-1.5 py-0.5">{error.digest}</code>
            </p>
          )}
          <div className="mt-2 flex gap-2">
            <button
              type="button"
              onClick={reset}
              className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-900 hover:bg-indigo-100"
            >
              Try again
            </button>
            <Link
              href="/"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 px-4 py-2 text-sm font-medium text-slate-200 hover:bg-white/10"
            >
              Back to library
            </Link>
          </div>
        </main>
      </body>
    </html>
  );
}
