/**
 * Aether database layer — works in two modes:
 *
 *  1. EMBEDDED (default, zero setup)
 *     No DATABASE_URL set. Uses PGlite: real PostgreSQL compiled to WASM,
 *     running inside this process and storing data in ./data/aether-db.
 *
 *  2. SERVER (optional)
 *     DATABASE_URL is set. Connects to a normal PostgreSQL server.
 */
import { createRequire } from "node:module";
import path from "node:path";
import fs from "node:fs";
import { drizzle as drizzlePg } from "drizzle-orm/node-postgres";
import { drizzle as drizzlePglite } from "drizzle-orm/pglite";
import { BOOTSTRAP_SQL } from "./bootstrap-sql";

const require = createRequire(import.meta.url);

const databaseUrl = process.env.DATABASE_URL?.trim();
const isServerlessHost =
  process.env.AETHER_NETLIFY === "1" || process.env.NETLIFY === "true";
const requiresServerDatabase = isServerlessHost && !databaseUrl;
const useEmbedded = !databaseUrl && !isServerlessHost;

const globalForDb = globalThis as typeof globalThis & {
  __aetherDb?: any;
  __aetherPool?: any;
  __aetherClient?: any;
  __aetherReady?: Promise<void>;
  __aetherInitError?: string | null;
};

function formatDetail(details: unknown): string {
  try {
    if (details instanceof Error) {
      return JSON.stringify({ name: details.name, message: details.message });
    }
    return JSON.stringify(details).slice(0, 500);
  } catch {
    return String(details);
  }
}

export function aetherLog(message: string, details?: unknown) {
  const line = `[${new Date().toISOString()}] ${message}${
    details ? " " + formatDetail(details) : ""
  }`;
  if (details) console.error(message, details);
  else console.log(message);

  // Best-effort: mirror to a log file users can send for support.
  try {
    const logDir = path.join(process.cwd(), "data");
    fs.mkdirSync(logDir, { recursive: true });
    fs.appendFileSync(path.join(logDir, "aether.log"), line + "\n", "utf8");
  } catch {
    /* logging must never crash the app */
  }
}

/**
 * PGlite's emscripten filesystem cannot handle absolute Windows paths
 * ("C:\..."). Forward slashes are mandatory, and on Windows we also resolve
 * to a path RELATIVE to the working directory so the WASM layer never sees
 * a drive letter.
 */
function embeddedDataDir(): string {
  const raw =
    process.env.AETHER_DATA_DIR?.trim() ||
    path.join(process.cwd(), "data", "aether-db");

  let safe = raw.replace(/\\/g, "/");

  // Windows: absolute paths break emscripten's filesystem layer.
  // Resolve to a relative path from cwd so WASM sees only "./...".
  if (process.platform === "win32") {
    const cwd = process.cwd().replace(/\\/g, "/");
    if (safe === cwd || safe.startsWith(cwd + "/")) {
      safe = "." + safe.slice(cwd.length);
    }
  }
  return safe;
}

function createEmbedded() {
  const { PGlite } = require("@electric-sql/pglite");
  const dataDir = embeddedDataDir();

  let client: any;
  try {
    client = new PGlite(dataDir);
  } catch (err) {
    globalForDb.__aetherInitError = formatDetail(err);
    throw new PGliteUnavailable(globalForDb.__aetherInitError);
  }

  // Fixing the path if PGlite holds it; PGlite normalises at open time.
  const readyP = client
    .exec(BOOTSTRAP_SQL)
    .then(() => {
      aetherLog(`[Aether] Embedded database ready (dir: ${dataDir})`);
    })
    .catch((err: unknown) => {
      globalForDb.__aetherInitError = formatDetail(err);
      aetherLog(
        "[Aether] Embedded database FAILED to initialise. Documents cannot be loaded until this is fixed.",
        err
      );
      console.error(
        "\n[Aether] DATABASE INIT FAILED\n" +
          "  Fix: close Aether, delete the 'data' folder, then run Aether.bat again.\n" +
          `  Details: ${formatDetail(err)}\n`
      );
    });

  return { client, db: drizzlePglite(client), ready: readyP };
}

class PGliteUnavailable extends Error {
  constructor(detail: string) {
    super(
      "The built-in database could not start on this computer. " +
        `Details: ${detail}`
    );
    this.name = "PGliteUnavailable";
  }
}

function createServer(url: string) {
  const { Pool } = require("pg");
  const pool = new Pool({ connectionString: url });
  aetherLog("[Aether] Using PostgreSQL server from DATABASE_URL");
  return { pool, db: drizzlePg(pool), ready: Promise.resolve() };
}

if (!globalForDb.__aetherDb) {
  globalForDb.__aetherInitError = null;
  try {
    if (requiresServerDatabase) {
      throw new Error(
        "A persistent DATABASE_URL is required on Netlify. Serverless /tmp storage is temporary and could lose or split documents between function instances."
      );
    }
    const created = useEmbedded ? createEmbedded() : createServer(databaseUrl!);
    globalForDb.__aetherDb = created.db;
    globalForDb.__aetherReady = created.ready;
    if ("pool" in created && created.pool) globalForDb.__aetherPool = created.pool;
    if ("client" in created && created.client)
      globalForDb.__aetherClient = created.client;
  } catch (err) {
    globalForDb.__aetherInitError = formatDetail(err);
    aetherLog("[Aether] Database driver could not start.", err);
    globalForDb.__aetherReady = Promise.resolve();
    globalForDb.__aetherDb = undefined;
  }
}

export const db = globalForDb.__aetherDb;

/** Throws a clear error if the database failed to start. */
export function requireDb() {
  if (!globalForDb.__aetherDb) {
    throw new Error(
      "Database is not available. " +
        (globalForDb.__aetherInitError
          ? `Error: ${globalForDb.__aetherInitError}`
          : "Delete the 'data' folder and restart Aether.")
    );
  }
  return globalForDb.__aetherDb;
}

export const pool = globalForDb.__aetherPool;

/** Resolves once the schema is guaranteed to exist. */
export const dbReady: Promise<void> =
  globalForDb.__aetherReady ?? Promise.resolve();

/** True when running on the zero-setup embedded database. */
export const isEmbedded = useEmbedded;

/** Non-null if the embedded database failed to start. */
export function getInitError(): string | null {
  return globalForDb.__aetherInitError ?? null;
}
