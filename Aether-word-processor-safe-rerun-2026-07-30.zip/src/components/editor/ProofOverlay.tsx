"use client";

import { useEffect, useMemo, useRef } from "react";
import { createPortal } from "react-dom";
import { Editor } from "@tiptap/react";
import { AlertCircle, AlertTriangle, Info, Replace, X, ArrowRight } from "lucide-react";
import type { ProofIssue } from "./LiveProofing";
import { cn } from "@/lib/utils";

function severityIcon(s: ProofIssue["severity"]) {
  if (s === "error") return <AlertCircle className="h-3.5 w-3.5 text-rose-500" />;
  if (s === "warning") return <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />;
  return <Info className="h-3.5 w-3.5 text-sky-500" />;
}

const POPOVER_WIDTH = 320;

export function ProofOverlay({
  editor,
  visible,
  position,
  issue,
  onApply,
  onDismiss,
  onClose,
}: {
  editor: Editor | null;
  visible: boolean;
  position: { top: number; left: number } | null;
  issue: ProofIssue | null;
  onApply: (issue: ProofIssue) => void;
  onDismiss: (issue: ProofIssue) => void;
  onClose: () => void;
}) {
  const popoverRef = useRef<HTMLDivElement>(null);

  const finalPosition = useMemo(() => {
    if (!visible || !position || typeof window === "undefined") return null;
    const margin = 16;
    const viewW = window.innerWidth;
    const viewH = window.innerHeight;
    let left = position.left - POPOVER_WIDTH / 2;
    if (left < margin) left = margin;
    if (left + POPOVER_WIDTH > viewW - margin) {
      left = viewW - POPOVER_WIDTH - margin;
    }
    let top = position.top;
    let arrowOnTop = true;
    if (top + 200 > viewH - margin) {
      top = position.top - 220;
      arrowOnTop = false;
    }
    if (top < margin) {
      top = margin;
      arrowOnTop = true;
    }
    return { top, left, arrowOnTop };
  }, [visible, position]);

  // Close on Escape
  useEffect(() => {
    if (!visible) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [visible, onClose]);

  // Close on outside click
  useEffect(() => {
    if (!visible || !finalPosition) return;
    const onDown = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    // Delay to avoid catching the click that opened the popover
    const timer = setTimeout(() => {
      document.addEventListener("mousedown", onDown);
    }, 100);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("mousedown", onDown);
    };
  }, [visible, finalPosition, onClose]);

  if (
    typeof document === "undefined" ||
    !visible ||
    !position ||
    !issue ||
    !finalPosition
  ) {
    return null;
  }

  const canApply = issue.suggestion && !issue.suggestion.startsWith("(");

  const severityColor =
    issue.severity === "error"
      ? "rose"
      : issue.severity === "warning"
        ? "amber"
        : "sky";

  const arrow = finalPosition.arrowOnTop ? (
    // Arrow at top, pointing UP
    <div
      className={cn(
        "absolute -top-1.5 h-3 w-3 rotate-45 border-t border-l bg-white",
        severityColor === "rose" && "border-rose-200",
        severityColor === "amber" && "border-amber-200",
        severityColor === "sky" && "border-sky-200"
      )}
      style={{ left: position.left - finalPosition.left }}
    />
  ) : (
    // Arrow at bottom, pointing DOWN
    <div
      className={cn(
        "absolute -bottom-1.5 h-3 w-3 rotate-45 border-b border-r bg-white",
        severityColor === "rose" && "border-rose-200",
        severityColor === "amber" && "border-amber-200",
        severityColor === "sky" && "border-sky-200"
      )}
      style={{ left: position.left - finalPosition.left }}
    />
  );

  const content = (
    <div
      ref={popoverRef}
      className={cn(
        "fixed z-[9999] overflow-hidden rounded-2xl border bg-white/98 shadow-2xl shadow-black/20 backdrop-blur-xl",
        severityColor === "rose" && "border-rose-200",
        severityColor === "amber" && "border-amber-200",
        severityColor === "sky" && "border-sky-200"
      )}
      style={{
        top: finalPosition.top,
        left: finalPosition.left,
        width: POPOVER_WIDTH,
      }}
      onMouseDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Colored severity strip on the left */}
      <div
        className={cn(
          "absolute left-0 top-0 h-full w-1",
          severityColor === "rose" && "bg-rose-500",
          severityColor === "amber" && "bg-amber-500",
          severityColor === "sky" && "bg-sky-500"
        )}
      />
      {arrow}

      <div className="ml-1 p-3">
        <div className="mb-2 flex items-start justify-between gap-2">
          <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
            {severityIcon(issue.severity)}
            {issue.type}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>

        <p className="text-sm leading-relaxed text-slate-800">
          <span className="rounded bg-rose-50 px-1 text-rose-700 line-through decoration-rose-300">
            {issue.original}
          </span>
          {canApply && (
            <>
              <ArrowRight className="mx-1 inline h-3 w-3 text-slate-400" />
              <span className="rounded bg-emerald-50 px-1 font-medium text-emerald-800">
                {issue.suggestion}
              </span>
            </>
          )}
        </p>

        <p className="mt-2 text-xs leading-relaxed text-slate-500">
          {issue.message}
        </p>

        <div className="mt-3 flex items-center gap-2">
          {canApply && (
            <button
              type="button"
              className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500"
              onClick={() => onApply(issue)}
            >
              <Replace className="h-3.5 w-3.5" />
              Apply fix
            </button>
          )}
          <button
            type="button"
            className={cn(
              "rounded-lg px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100",
              !canApply && "bg-white border border-slate-200"
            )}
            onClick={() => onDismiss(issue)}
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );

  return createPortal(content, document.body);
}
