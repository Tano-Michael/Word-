"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import TextAlign from "@tiptap/extension-text-align";
import Placeholder from "@tiptap/extension-placeholder";
import Highlight from "@tiptap/extension-highlight";
import {
  TextStyle,
  Color,
  FontFamily,
  FontSize,
  LineHeight,
} from "@tiptap/extension-text-style";
import { References } from "./references";
import Link from "@tiptap/extension-link";
import Image from "@tiptap/extension-image";
import { Table } from "@tiptap/extension-table";
import TableRow from "@tiptap/extension-table-row";
import TableCell from "@tiptap/extension-table-cell";
import TableHeader from "@tiptap/extension-table-header";
import TaskList from "@tiptap/extension-task-list";
import TaskItem from "@tiptap/extension-task-item";
import CharacterCount from "@tiptap/extension-character-count";
import Typography from "@tiptap/extension-typography";
import Dropcursor from "@tiptap/extension-dropcursor";
import Gapcursor from "@tiptap/extension-gapcursor";
import SubScript from "@tiptap/extension-subscript";
import SuperScript from "@tiptap/extension-superscript";
import {
  ArrowLeft,
  Sparkles,
  SpellCheck2,
  RefreshCw,
  ListTree,
  MessageSquare,
  History,
  Download,
  BarChart3,
  LayoutTemplate,
  Search,
  Star,
  Save,
  Cloud,
  CloudOff,
  MoreHorizontal,
  FileUp,
  Keyboard,
  Printer,
  Moon,
  Sun,
  Focus,
  Copy as CopyIcon,
  Eye,
  EyeOff,
  Shield,
  Undo2,
  Redo2,
} from "lucide-react";
import LinkNext from "next/link";
import { WordRibbon } from "./WordRibbon";
import { SidePanel } from "./SidePanel";
import { FindReplace } from "./FindReplace";
import { Ruler } from "./Ruler";
import { PageSetupDialog, type PageSettings } from "./PageSetupDialog";
import { LiveProofing, getProofIdAt } from "./LiveProofing";
import type { ProofIssue } from "./LiveProofing";
import { ProofOverlay } from "./ProofOverlay";
import { plainOffsetToPos } from "@/lib/offset-map";
import { SpeechTools } from "./SpeechTools";
import { SlashMenu } from "./SlashMenu";
import { FloatingToolbar } from "./FloatingToolbar";
import { TableControls, CaseChangeMenu } from "./TableControls";
import {
  useLocalSnapshot,
  readLocalSnapshot,
  clearLocalSnapshot,
} from "./CrashRecovery";
import {
  WatermarkOverlay,
  LayoutModeSelector,
  ColumnSelector,
  WatermarkSelector,
  TrackChangeIndicator,
  FootnotesBar,
  TableOfContents,
  type PageLayoutMode,
} from "./PageLayout";
import type { GrammarIssue, PanelId, RewriteScope, RewriteTarget, WritingInsights } from "@/lib/types";
import { analyzeWriting, plainToHtml, extractOutlineFromHtml } from "@/lib/ai-engine";
import { cn, estimatePages, formatRelativeDate } from "@/lib/utils";
import { chain } from "@/lib/tiptap-commands";

type CommentRow = {
  id: string;
  body: string;
  author: string;
  anchorText: string | null;
  resolved: boolean;
  createdAt: string | Date;
};

type VersionRow = {
  id: string;
  label: string | null;
  title: string;
  createdAt: string | Date;
  content: string;
};

function escapeHtmlText(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeCssString(value: string) {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/</g, "\\3C ")
    .replace(/\r?\n/g, "\\A ");
}

export function DocumentEditor({ documentId }: { documentId: string }) {
  const [title, setTitle] = useState("Untitled Document");
  const [panel, setPanel] = useState<PanelId>("none");
  const [fontSize, setFontSize] = useState("18px");
  const [saving, setSaving] = useState<"idle" | "saving" | "saved" | "error">(
    "idle"
  );
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [starred, setStarred] = useState(false);
  const [insights, setInsights] = useState<WritingInsights | null>(null);
  const [selection, setSelection] = useState("");
  const [, setCursorRevision] = useState(0);
  const [plainText, setPlainText] = useState("");
  const [html, setHtml] = useState("<p></p>");
  const [comments, setComments] = useState<CommentRow[]>([]);
  const [versions, setVersions] = useState<VersionRow[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState<{
    kind: "not-found" | "server";
    detail: string;
  } | null>(null);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [importState, setImportState] = useState<{
    status: "idle" | "loading" | "success" | "error";
    message: string;
    warnings?: string[];
  }>({ status: "idle", message: "" });
  const [dragging, setDragging] = useState(false);
  const [showFind, setShowFind] = useState(false);
  const [pageMode, setPageMode] = useState<PageLayoutMode>("page");
  const [columns, setColumns] = useState(1);
  const [watermark, setWatermark] = useState("");
  const [trackMode, setTrackMode] = useState<"editing" | "suggesting">("editing");
  const [footnotes, setFootnotes] = useState<string[]>([]);
  const [tocItems, setTocItems] = useState<{ level: number; text: string; pos?: number }[]>([]);
  const [marginLeft, setMarginLeft] = useState(1);
  const [marginRight, setMarginRight] = useState(1);
  const [marginTop, setMarginTop] = useState(1);
  const [marginBottom, setMarginBottom] = useState(1);
  const [pageSize, setPageSize] = useState<"letter" | "a4" | "legal">("letter");
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const [showPageSetup, setShowPageSetup] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [showProofing, setShowProofing] = useState(true);
  const [showRuler, setShowRuler] = useState(false);
  const [snapshotOffer, setSnapshotOffer] = useState<{
    html: string;
    savedAt: string;
  } | null>(null);
  const [proofIssues, setProofIssues] = useState<number>(0);
  const [proofList, setProofList] = useState<ProofIssue[]>([]);
  const [activeProofId, setActiveProofId] = useState<string | null>(null);
  const activeProofIndex = activeProofId ? proofList.findIndex((x) => x.id === activeProofId) : -1;
  const [proofPopover, setProofPopover] = useState<{
    issue: ProofIssue;
    position: { top: number; left: number };
  } | null>(null);
  const [slashMenu, setSlashMenu] = useState<{ show: boolean; position: { top: number; left: number } }>({
    show: false,
    position: { top: 0, left: 0 },
  });
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editorContainerRef = useRef<HTMLDivElement>(null);

  const extensions = useMemo(
    () => [
      StarterKit.configure({
        heading: { levels: [1, 2, 3, 4] },
      }),
      Underline,
      TextStyle,
      Color,
      FontFamily,
      FontSize,
      LineHeight,
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ["heading", "paragraph"] }),
      Placeholder.configure({
        placeholder:
          "Start writing, or press ⌘J to summon Aether Copilot…",
      }),
      Link.configure({ openOnClick: false, autolink: true }),
      Image.configure({ inline: false, allowBase64: true }),
      Table.configure({ resizable: true }),
      TableRow,
      TableHeader,
      TableCell,
      TaskList,
      TaskItem.configure({ nested: true }),
      CharacterCount,
      Typography,
      Dropcursor,
      Gapcursor,
      SubScript,
      SuperScript,
      References,
      LiveProofing.configure({
        enabled: showProofing,
        debounceMs: 900,
        onIssues: (issues) => {
          setProofIssues(issues.length);
          setProofList(issues as unknown as ProofIssue[]);
        },
        onAIIssues: (aiPatterns) => {
          // Merge AI phrases into proofList for popover navigation
          const aiIssues: ProofIssue[] = aiPatterns.map((p: any, idx: number) => ({
            id: `ai-${idx}-${p.originalPhrase}`,
            type: "common_ai_phrase",
            severity: "warning" as const,
            message: `AI-like phrase: "${p.originalPhrase}" → "${p.suggestedPhrase}"`,
            original: p.originalPhrase,
            suggestion: p.suggestedPhrase,
            start: 0, // Not used for popover
            end: 0,
          }));
          setProofList((prev) => {
            // Keep grammar issues, add AI issues
            const grammarIssues = prev.filter((x) => !x.id.startsWith("ai-"));
            return [...grammarIssues, ...aiIssues];
          });
        },
      }),
    ],
    [showProofing]
  );

  const editor = useEditor({
    extensions,
    content: "<p></p>",
    immediatelyRender: false,
    editorProps: {
      attributes: {
        class:
          "aether-editor focus:outline-none min-h-[calc(100vh-150px)] px-12 py-10 md:px-16",
      },
      handleDOMEvents: {
        mousedown: (view, event) => {
          if (!(event.target instanceof HTMLElement)) return false;
          const proofNode = event.target.closest<HTMLElement>("[data-proof-id]");
          if (!proofNode) return false;
          const proofId = proofNode.getAttribute("data-proof-id") ?? null;
          if (!proofId) return false;
          event.preventDefault();
          event.stopPropagation();

          const rect = proofNode.getBoundingClientRect();
          const issue = proofList.find((x) => x.id === proofId) ?? null;
          if (!issue) return false;

          // Pass the center-bottom position of the underline
          // The ProofOverlay will handle centering itself and flipping if needed
          const centerX = rect.left + rect.width / 2;
          const bottomY = rect.bottom + 8;

          setActiveProofId(proofId);
          setProofPopover({ issue, position: { top: bottomY, left: centerX } });
          return true;
        },
      },
    },
    onUpdate: ({ editor: ed }) => {
      const nextHtml = ed.getHTML();
      const nextPlain = ed.getText();
      setHtml(nextHtml);
      setPlainText(nextPlain);
      setInsights(analyzeWriting(nextPlain));
      scheduleSave(nextHtml, title);

      // Detect slash command trigger
      const { from } = ed.state.selection;
      const node = ed.state.doc.nodeAt(from - 1);
      if (node?.text === "/") {
        const { view } = ed;
        const coords = view.coordsAtPos(from);
        setSlashMenu({ show: true, position: { top: coords.top + 24, left: coords.left } });
      } else if (slashMenu.show) {
        const before = ed.state.doc.textBetween(Math.max(0, from - 20), from, "");
        if (!/\/[\w]*$/.test(before)) setSlashMenu({ show: false, position: { top: 0, left: 0 } });
      }
    },
    onSelectionUpdate: ({ editor: ed }) => {
      const { from, to } = ed.state.selection;
      if (from !== to) setSelection(ed.state.doc.textBetween(from, to, " "));
      else setSelection("");
      // Force scope previews to follow the caret even when there is no selection.
      setCursorRevision((value) => value + 1);
    },
  });

  const persist = useCallback(
    async (
      content: string,
      nextTitle: string,
      opts?: { createVersion?: boolean; versionLabel?: string }
    ) => {
      setSaving("saving");
      try {
        const res = await fetch(`/api/documents/${documentId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            content,
            title: nextTitle,
            createVersion: opts?.createVersion,
            versionLabel: opts?.versionLabel,
            isStarred: starred,
          }),
        });
        if (!res.ok) throw new Error("save failed");
        const data = await res.json();
        if (data.insights) setInsights(data.insights);
        setSaving("saved");
        setLastSaved(new Date());
        // Server copy is now authoritative — the local snapshot can go.
        clearLocalSnapshot(documentId);
      } catch {
        setSaving("error");
      }
    },
    [documentId, starred]
  );

  const scheduleSave = useCallback(
    (content: string, nextTitle: string) => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        void persist(content, nextTitle);
      }, 900);
    },
    [persist]
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/documents/${documentId}`);
        if (cancelled) return;
        if (!res.ok) {
          let detail = `Server answered with status ${res.status}.`;
          try {
            const errorBody = await res.json();
            if (errorBody?.error) detail = errorBody.error;
            if (errorBody?.initError) detail += ` (${errorBody.initError})`;
          } catch {
            /* body unreadable */
          }
          setLoadError({
            kind: res.status === 404 ? "not-found" : "server",
            detail,
          });
          return;
        }
        const data = await res.json();
        const doc = data.document;
      setTitle(doc.title);
      setStarred(!!doc.isStarred);
      setHtml(doc.content || "<p></p>");
      setPlainText(doc.plainText || "");
      setComments(data.comments || []);
      setVersions(data.versions || []);
      setInsights(
        analyzeWriting(doc.plainText || "") ||
          (doc.wordCount
            ? {
                wordCount: doc.wordCount,
                charCount: doc.charCount,
                sentenceCount: 0,
                paragraphCount: 0,
                avgWordsPerSentence: 0,
                readingTimeMin: Math.max(1, Math.ceil(doc.wordCount / 230)),
                speakingTimeMin: Math.max(1, Math.ceil(doc.wordCount / 150)),
                fleschReadingEase: 60,
                gradeLevel: doc.readingLevel || "—",
                tone: doc.toneScore || {
                  formal: 40,
                  confident: 40,
                  friendly: 40,
                  analytical: 40,
                },
                passiveVoicePct: 0,
                uniqueWordPct: 0,
                topWords: [],
                sentiment: "neutral",
              }
            : null)
      );
      setLoaded(true);

      // Crash-recovery: if a local snapshot exists AND is newer than the
      // server copy, offer to restore it. We compare timestamps to avoid
      // ever offering an older draft than what's already saved.
      const snap = readLocalSnapshot(documentId);
      const serverUpdatedAt = doc.updatedAt ? new Date(doc.updatedAt).getTime() : 0;
      if (
        snap &&
        snap.html &&
        snap.html !== (doc.content || "<p></p>") &&
        new Date(snap.savedAt).getTime() > serverUpdatedAt + 500
      ) {
        setSnapshotOffer(snap);
      }
      } catch (fetchErr) {
        if (!cancelled) {
          setLoadError({
            kind: "server",
            detail:
              "Could not reach the Aether server. Make sure it is still running.",
          });
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [documentId]);

  useEffect(() => {
    if (!editor || !loaded) return;
    const current = editor.getHTML();
    if (html && html !== current) {
      editor.commands.setContent(html, { emitUpdate: false });
    }
    // only on initial load
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor, loaded]);

  const openProofPopoverForIssue = useCallback(
    (issue: ProofIssue) => {
      if (!editor) return;
      const { view } = editor;
      const resolvedPos = plainOffsetToPos(editor.state.doc, Number(issue.start));
      const target = resolvedPos ?? 0;
      const node = view.nodeDOM(target);
      if (node instanceof HTMLElement) {
        const rect = node.getBoundingClientRect();
        const left = Math.min(rect.left + rect.width / 2 - 140, window.innerWidth - 312);
        const top = Math.max(rect.bottom + 10, 12);
        setActiveProofId(issue.id);
        setProofPopover({ issue, position: { top, left } });
        return;
      }
      const left = Math.min(window.innerWidth / 2 - 140, window.innerWidth - 312);
      setActiveProofId(issue.id);
      setProofPopover({ issue, position: { top: 120, left } });
    },
    [editor]
  );

  const openProofByIndex = useCallback(
    (nextIndex: number) => {
      const issue = proofList[nextIndex];
      if (!issue) return;
      openProofPopoverForIssue(issue);
    },
    [proofList, openProofPopoverForIssue]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "j") {
        e.preventDefault();
        setPanel((p) => (p === "ai" ? "none" : "ai"));
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        void persist(html, title, {
          createVersion: true,
          versionLabel: "Manual save",
        });
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        setShowFind((s) => !s);
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "h") {
        e.preventDefault();
        setShowFind(true);
      }
      if (e.key === "F3" || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "g")) {
        if (!showFind) return;
        e.preventDefault();
      }

      if (e.key === "Escape") {
        setProofPopover(null);
        setActiveProofId(null);
        if (focusMode) setFocusMode(false);
        if (showFind) setShowFind(false);
      }

      if (!proofList.length) return;
      if (e.altKey && (e.key === "]" || e.key === "}" || e.key === "ArrowDown")) {
        e.preventDefault();
        const nextIndex = activeProofIndex < 0 ? 0 : (activeProofIndex + 1) % proofList.length;
        openProofByIndex(nextIndex);
      }
      if (e.altKey && (e.key === "[" || e.key === "{" || e.key === "ArrowUp")) {
        e.preventDefault();
        const prevIndex = activeProofIndex <= 0 ? proofList.length - 1 : activeProofIndex - 1;
        openProofByIndex(prevIndex);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [
    html,
    title,
    persist,
    showFind,
    focusMode,
    proofList,
    activeProofIndex,
    openProofByIndex,
  ]);

  const togglePanel = (id: PanelId) =>
    setPanel((p) => (p === id ? "none" : id));

  const getRewriteTarget = useCallback(
    (scope: RewriteScope): RewriteTarget | null => {
      if (!editor) return null;
      const { doc, selection: editorSelection } = editor.state;
      const { from, to } = editorSelection;

      if (scope === "selection") {
        if (from === to) return null;
        return {
          scope,
          label: "Selected text",
          text: doc.textBetween(from, to, "\n", "\n"),
          from,
          to,
        };
      }

      if (scope === "document") {
        return {
          scope,
          label: "Entire document",
          text: doc.textBetween(0, doc.content.size, "\n", "\n"),
          from: 0,
          to: doc.content.size,
        };
      }

      const $from = doc.resolve(from);
      let depth = $from.depth;
      while (depth > 0 && !$from.node(depth).isTextblock) depth -= 1;
      if (!$from.node(depth).isTextblock) return null;

      const blockFrom = $from.start(depth);
      const blockTo = $from.end(depth);
      const blockText = doc.textBetween(blockFrom, blockTo, "\n", "\n");
      if (!blockText.trim()) return null;

      if (scope === "paragraph") {
        return {
          scope,
          label: "Current paragraph",
          text: blockText,
          from: blockFrom,
          to: blockTo,
        };
      }

      const beforeCaret = doc.textBetween(blockFrom, from, "\n", "\n");
      const caretOffset = Math.max(0, Math.min(blockText.length, beforeCaret.length));
      const boundary = /[.!?]["')\]]?\s+/g;
      let sentenceStart = 0;
      let sentenceEnd = blockText.length;
      let match: RegExpExecArray | null;
      while ((match = boundary.exec(blockText)) !== null) {
        const nextStart = match.index + match[0].length;
        if (nextStart <= caretOffset) sentenceStart = nextStart;
        else {
          sentenceEnd = match.index + match[0].trimEnd().length;
          break;
        }
      }
      while (sentenceStart < sentenceEnd && /\s/.test(blockText[sentenceStart] || "")) sentenceStart += 1;
      while (sentenceEnd > sentenceStart && /\s/.test(blockText[sentenceEnd - 1] || "")) sentenceEnd -= 1;

      return {
        scope: "sentence",
        label: "Current sentence",
        text: blockText.slice(sentenceStart, sentenceEnd),
        from: blockFrom + sentenceStart,
        to: blockFrom + sentenceEnd,
      };
    },
    [editor]
  );

  const applyRewriteTarget = useCallback(
    (target: RewriteTarget, replacement: string) => {
      if (!editor || !replacement.trim()) return;
      if (target.scope === "document") {
        editor.commands.setContent(plainToHtml(replacement));
      } else {
        const max = editor.state.doc.content.size;
        const from = Math.max(0, Math.min(target.from, max));
        const to = Math.max(from, Math.min(target.to, max));
        editor.chain().focus().insertContentAt({ from, to }, replacement).run();
      }
      const nextHtml = editor.getHTML();
      setHtml(nextHtml);
      setPlainText(editor.getText());
      scheduleSave(nextHtml, title);
    },
    [editor, scheduleSave, title]
  );

  const onApplyHtml = (next: string, mode: "replace" | "insert" = "insert") => {
    if (!editor) return;
    if (mode === "replace") {
      editor.commands.setContent(next);
    } else {
      chain(editor).insertContent(next).run();
    }
    setHtml(editor.getHTML());
    setPlainText(editor.getText());
    scheduleSave(editor.getHTML(), title);
  };



  /**
   * Precisely replace a specific phrase in the document while preserving
   * ALL formatting (headings, bold, lists, etc). Used by the grammar panel
   * so applying a fix does not flatten the document to plain text.
   * Returns true if a replacement was made.
   */
  const replacePhrase = (
    original: string,
    suggestion: string,
    issue?: { start: number; end: number }
  ): boolean => {
    if (!editor || !original) return false;
    const doc = editor.state.doc;
    let matchFrom = -1;
    let matchTo = -1;

    // If we have exact positions from the issue, use them to target the
    // specific occurrence instead of just finding the first match
    if (issue && typeof issue.start === "number" && typeof issue.end === "number") {
      const fromPos = plainOffsetToPos(doc, issue.start);
      const toPos = plainOffsetToPos(doc, issue.end);
      if (fromPos !== null && toPos !== null) {
        matchFrom = fromPos;
        matchTo = toPos;
      }
    }

    // Fallback: walk every text node to find the first occurrence
    if (matchFrom === -1 || matchTo === -1) {
      matchFrom = -1;
      matchTo = -1;
      doc.descendants((node, pos) => {
        if (matchFrom !== -1) return false;
        if (node.isText && node.text) {
          const idx = node.text.indexOf(original);
          if (idx !== -1) {
            matchFrom = pos + idx;
            matchTo = matchFrom + original.length;
            return false;
          }
        }
        return true;
      });
    }

    if (matchFrom === -1) return false;

    const isRemoval = suggestion.startsWith("(") || suggestion === "";
    if (isRemoval) {
      // Also swallow one trailing space so we don't leave a double space.
      const doc2 = editor.state.doc;
      const nextChar = doc2.textBetween(matchTo, Math.min(matchTo + 1, doc2.content.size));
      const end = nextChar === " " ? matchTo + 1 : matchTo;
      editor.chain().focus().deleteRange({ from: matchFrom, to: end }).run();
    } else {
      editor
        .chain()
        .focus()
        .insertContentAt({ from: matchFrom, to: matchTo }, suggestion)
        .run();
    }

    setHtml(editor.getHTML());
    setPlainText(editor.getText());
    scheduleSave(editor.getHTML(), title);
    return true;
  };

  const applyGrammarIssues = useCallback(
    (candidateIssues: GrammarIssue[]): number => {
      if (!editor) return 0;
      const safeTypes = new Set(["spelling", "grammar", "punctuation", "repetition"]);
      const doc = editor.state.doc;
      const mapped = candidateIssues
        .filter((issue) =>
          safeTypes.has(issue.type) &&
          Number.isFinite(issue.start) &&
          Number.isFinite(issue.end) &&
          issue.end > issue.start &&
          issue.end - issue.start <= 120 &&
          issue.suggestion !== issue.original
        )
        .map((issue) => {
          const from = plainOffsetToPos(doc, issue.start);
          const to = plainOffsetToPos(doc, issue.end);
          return from !== null && to !== null && from < to ? { issue, from, to } : null;
        })
        .filter((item): item is { issue: GrammarIssue; from: number; to: number } => item !== null)
        .sort((a, b) => b.from - a.from);

      let rightBoundary = Number.POSITIVE_INFINITY;
      let applied = 0;
      let tr = editor.state.tr;
      for (const item of mapped) {
        if (item.to > rightBoundary) continue;
        const current = doc.textBetween(item.from, item.to, "\n", "\n");
        if (current.toLowerCase() !== item.issue.original.toLowerCase()) continue;
        const replacement = item.issue.suggestion.startsWith("(") ? "" : item.issue.suggestion;
        tr = tr.insertText(replacement, item.from, item.to);
        rightBoundary = item.from;
        applied += 1;
      }

      if (!applied) return 0;
      editor.view.dispatch(tr);
      const nextHtml = editor.getHTML();
      setHtml(nextHtml);
      setPlainText(editor.getText());
      scheduleSave(nextHtml, title);
      return applied;
    },
    [editor, scheduleSave, title]
  );

  const duplicateDoc = async () => {
    try {
      const res = await fetch(`/api/documents/${documentId}/duplicate`, { method: "POST" });
      const data = await res.json();
      if (data.document?.id) {
        window.open(`/doc/${data.document.id}`, "_blank");
      }
    } catch (err) {
      console.error("Duplicate failed:", err);
    }
  };

  const importFile = async (file: File) => {
    setImportState({ status: "loading", message: `Opening ${file.name}…` });
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/import", { method: "POST", body: form });
      const data = await res.json();

      if (!res.ok) {
        setImportState({
          status: "error",
          message: data.error || "Could not open this file.",
        });
        return;
      }

      onApplyHtml(data.html, "replace");
      const nextTitle = data.title || file.name.replace(/\.[^.]+$/, "");
      setTitle(nextTitle);
      scheduleSave(data.html, nextTitle);

      const kindLabel =
        data.kind === "docx"
          ? "Word document"
          : data.kind === "pdf"
            ? `PDF (${data.pageCount ?? "?"} pages)`
            : data.kind;
      setImportState({
        status: "success",
        message: `Imported ${kindLabel} · ${data.wordCount ?? 0} words`,
        warnings: data.warnings || [],
      });
    } catch {
      setImportState({
        status: "error",
        message: "Import failed. Please try again.",
      });
    }
  };

  // Continuously mirror the document to localStorage so a crash, close, or
  // network hiccup never costs more than the last ~0.7 seconds of typing.
  useLocalSnapshot(documentId, html, loaded);

  const wordCount = insights?.wordCount ?? 0;

  const handlePrint = useCallback(() => {
    const printWin = window.open("", "_blank");
    if (!printWin) return;
    const docHtml = editor?.getHTML() || html;
    const safePrintTitle = escapeHtmlText(title);
    const safeWatermark = escapeCssString(watermark);
    printWin.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
<title>${safePrintTitle}</title>
<style>
@page{size:letter;margin:${marginTop}in ${marginRight}in ${marginTop}in ${marginLeft}in}
body{font-family:Georgia,serif;font-size:${fontSize};line-height:1.7;color:#111;max-width:100%;margin:0;padding:0}
h1,h2,h3,h4{font-family:Inter,system-ui,sans-serif;line-height:1.2;margin:0.6em 0 0.4em}
h1{font-size:2em}h2{font-size:1.45em}h3{font-size:1.2em}
p{margin:0 0 0.85em}ul,ol{padding-left:1.4em;margin:0 0 0.85em}
blockquote{border-left:3px solid #c7d2fe;margin:0.8em 0;padding:0.25em 0 0.25em 1em;font-style:italic}
table{border-collapse:collapse;width:100%;margin:1em 0}
th,td{border:1px solid #cbd5e1;padding:0.45em 0.65em}
th{background:#f8fafc;font-weight:600}
pre{background:#f1f5f9;border-radius:8px;padding:1em;font-size:0.9em}
code{font-family:Courier New,monospace;font-size:0.9em}
mark{background:#fef08a}
a{color:#4f46e5;text-decoration:underline}
hr{border:none;border-top:1px solid #e2e8f0;margin:1.5em 0}
${watermark ? `body::before{content:"${safeWatermark}";position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-size:80px;font-weight:bold;color:rgba(0,0,0,0.04);letter-spacing:16px;white-space:nowrap;pointer-events:none;z-index:9999}` : ""}
${columns > 1 ? `body{column-count:${columns};column-gap:2em;column-rule:1px solid #e2e8f0}` : ""}
</style></head><body>
${docHtml}
</body></html>`);
    printWin.document.close();
    setTimeout(() => {
      printWin.focus();
      printWin.print();
      printWin.close();
    }, 400);
  }, [editor, html, title, fontSize, marginLeft, marginRight, marginTop, watermark, columns]);

  if (loadError) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-[#e8ecf3] px-6 text-center dark:bg-slate-950">
        <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-xl dark:bg-slate-900">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 text-2xl">
            ⚠️
          </div>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">
            {loadError.kind === "not-found"
              ? "Document not found"
              : "Couldn't open this document"}
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
            {loadError.kind === "not-found"
              ? "This document may have been deleted, or the link points somewhere that does not exist."
              : loadError.detail}
          </p>
          <div className="mt-6 flex flex-col gap-2">
            <LinkNext
              href="/"
              className="rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-500"
            >
              Back to your library
            </LinkNext>
            <a
              href="/api/diagnose"
              target="_blank"
              className="text-xs text-slate-400 underline hover:text-slate-600"
            >
              Run diagnostics
            </a>
          </div>
        </div>
      </div>
    );
  }

  if (!loaded) {
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-3 bg-[#e8ecf3] dark:bg-slate-950">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 text-lg font-black text-white shadow-lg">
          Æ
        </div>
        <p className="text-sm text-slate-500">Opening document…</p>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "flex h-screen flex-col transition-colors duration-300",
        darkMode && "aether-dark",
        darkMode
          ? "bg-slate-950 text-slate-100"
          : "bg-[#e8ecf3] text-slate-900"
      )}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".docx,.pdf,.rtf,.txt,.md,.markdown,.html,.htm,.json,.csv"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void importFile(f);
          e.target.value = "";
        }}
      />

      {/* Unified Ultra-Clean Top Bar + Ribbon */}
      {!focusMode && (
        <WordRibbon
          // Document Identity
          title={title}
          onTitleChange={(val) => {
            setTitle(val);
            scheduleSave(html, val);
          }}
          saving={saving}
          lastSaved={lastSaved}
          wordCount={wordCount}
          starred={starred}
          onToggleStar={() => {
            setStarred((s) => !s);
            void persist(html, title);
          }}
          // Ribbon props

          editor={editor}
          fontSize={fontSize}
          onFontSize={setFontSize}
          activePanel={panel}
          onTogglePanel={(id) =>
            setPanel((p) => (p === id ? "none" : id))
          }
          pageMode={pageMode}
          onPageModeChange={setPageMode}
          columns={columns}
          onColumnsChange={setColumns}
          watermark={watermark}
          onWatermarkChange={setWatermark}
          onOpenPageSetup={() => setShowPageSetup(true)}
          trackMode={trackMode}
          onToggleTrackMode={() =>
            setTrackMode((m) => (m === "editing" ? "suggesting" : "editing"))
          }
          showProofing={showProofing}
          onToggleProofing={() => setShowProofing((s) => !s)}
          proofIssues={proofIssues}
          zoom={zoom}
          onZoomChange={setZoom}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode((d) => !d)}
          focusMode={focusMode}
          onToggleFocusMode={() => setFocusMode((f) => !f)}
          showRuler={showRuler}
          onToggleRuler={() => setShowRuler((value) => !value)}
          onToggleShortcuts={() => setShowShortcuts((s) => !s)}
          onNewDoc={() => {
            if (
              confirm(
                "Create new blank document? Your current document is saved automatically."
              )
            ) {
              window.open("/?new=1", "_blank");
            }
          }}
          onImportFile={() => fileInputRef.current?.click()}
          onSaveCheckpoint={() =>
            void persist(html, title, {
              createVersion: true,
              versionLabel: "Manual checkpoint",
            })
          }
          onDuplicateDoc={duplicateDoc}
          onPrint={handlePrint}
          onInsertFootnote={() => {
            const note = window.prompt("Add footnote for selection:");
            if (!note?.trim()) return;
            setFootnotes((prev) => [...prev, note.trim()]);
            if (editor) {
              const { from } = editor.state.selection;
              editor
                .chain()
                .focus()
                .insertContentAt(
                  from + selection.length,
                  `<sup>[${footnotes.length + 1}]</sup>`
                )
                .run();
            }
          }}
        />
      )}
      <TableControls editor={editor} />

      <FloatingToolbar editor={editor} />
      <SlashMenu
        editor={editor}
        show={slashMenu.show}
        onClose={() => setSlashMenu({ show: false, position: { top: 0, left: 0 } })}
        position={slashMenu.position}
      />

      {pageMode === "page" && showRuler && (
        <Ruler
          marginLeft={marginLeft}
          marginRight={marginRight}
          onMarginsChange={(l, r) => { setMarginLeft(l); setMarginRight(r); }}
          onInsertTab={() => {}}
        />
      )}

      <FindReplace
        visible={showFind}
        onClose={() => setShowFind(false)}
        getText={() => editor?.getText() || plainText}
        highlightMatches={() => {}}
        jumpTo={(from) => { if (editor) { editor.chain().focus().setTextSelection(from).run(); } }}
        replaceText={(from, to, rep) => {
          if (!editor) return;
          editor.chain().focus().insertContentAt({ from, to }, rep).run();
        }}
      />

      {snapshotOffer && editor && (
        <div className="flex items-start gap-2 border-b border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-900">
          <span className="mt-0.5 text-base">💾</span>
          <div className="flex-1">
            <p className="font-semibold">Unsaved changes recovered</p>
            <p className="text-amber-800/80">
              Aether found a local draft from{" "}
              {formatRelativeDate(snapshotOffer.savedAt)} that is newer than
              the version on the server. Restore it, or keep the server copy.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              editor.commands.setContent(snapshotOffer.html, { emitUpdate: true });
              setHtml(snapshotOffer.html);
              setPlainText(editor.getText());
              scheduleSave(snapshotOffer.html, title);
              setSnapshotOffer(null);
            }}
            className="rounded-lg bg-amber-600 px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-amber-500"
          >
            Restore draft
          </button>
          <button
            type="button"
            onClick={() => {
              clearLocalSnapshot(documentId);
              setSnapshotOffer(null);
            }}
            className="rounded-lg px-3 py-1.5 text-[11px] font-medium text-amber-700 hover:bg-amber-100"
          >
            Discard
          </button>
        </div>
      )}

      {importState.status !== "idle" && (
        <div
          className={cn(
            "flex items-start gap-2 border-b px-4 py-2 text-xs",
            importState.status === "loading" &&
              "border-indigo-100 bg-indigo-50 text-indigo-800",
            importState.status === "success" &&
              "border-emerald-100 bg-emerald-50 text-emerald-800",
            importState.status === "error" &&
              "border-rose-100 bg-rose-50 text-rose-800"
          )}
        >
          <FileUp className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <div className="flex-1">
            <p className="font-medium">{importState.message}</p>
            {!!importState.warnings?.length && (
              <ul className="mt-1 space-y-0.5 opacity-80">
                {importState.warnings.slice(0, 3).map((w, i) => (
                  <li key={i}>• {w}</li>
                ))}
              </ul>
            )}
          </div>
          <button
            type="button"
            onClick={() => setImportState({ status: "idle", message: "" })}
            className="rounded px-1 opacity-60 hover:opacity-100"
          >
            ✕
          </button>
        </div>
      )}

      <div className="flex min-h-0 flex-1">
        <div
          className="relative flex-1 overflow-auto"
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            const f = e.dataTransfer.files?.[0];
            if (f) void importFile(f);
          }}
        >
          {dragging && (
            <div className="pointer-events-none absolute inset-4 z-20 flex items-center justify-center rounded-3xl border-2 border-dashed border-indigo-400 bg-indigo-50/80 backdrop-blur-sm">
              <div className="text-center">
                <FileUp className="mx-auto mb-2 h-8 w-8 text-indigo-500" />
                <p className="text-sm font-semibold text-indigo-900">
                  Drop to open
                </p>
                <p className="text-xs text-indigo-700">
                  .docx · .pdf · .rtf · .md · .html · .txt · .csv
                </p>
              </div>
            </div>
          )}
          {focusMode && (
            <div className="pointer-events-none absolute inset-x-0 top-2 z-30 flex justify-end px-3">
              <button
                type="button"
                onClick={() => setFocusMode(false)}
                title="Exit focus mode (press Esc)"
                className="pointer-events-auto inline-flex items-center gap-1 rounded-full bg-slate-900/80 px-3 py-1.5 text-[11px] font-semibold text-white shadow-lg backdrop-blur transition hover:bg-slate-800"
              >
                Exit focus
              </button>
            </div>
          )}
          <div
            className="mx-auto my-6 origin-top transition-transform"
            style={{
              width: pageMode === "web" ? "100%" : 816,
              maxWidth: pageMode === "web" ? "960px" : "calc(100% - 2rem)",
              transform: `scale(${zoom / 100})`,
            }}
          >
            <div
              className={cn(
                "relative transition-colors",
                pageMode === "page"
                  ? cn(
                      "min-h-[1056px] rounded-sm ring-1",
                      darkMode
                        ? "bg-slate-900 ring-slate-700 shadow-2xl shadow-black/50"
                        : "bg-white shadow-[0_1px_3px_rgba(15,23,42,0.08),0_24px_48px_rgba(15,23,42,0.08)] ring-slate-900/5"
                    )
                  : cn(
                      "min-h-[60vh] rounded-xl p-6 shadow-sm ring-1",
                      darkMode
                        ? "bg-slate-900 ring-slate-700"
                        : "bg-white ring-slate-900/5"
                    )
              )}
              style={{
                paddingLeft: pageMode === "page" ? `${marginLeft}in` : undefined,
                paddingRight: pageMode === "page" ? `${marginRight}in` : undefined,
              }}
            >
              {watermark && <WatermarkOverlay text={watermark} />}
              <div
                style={{
                  fontSize,
                  columnCount: pageMode !== "outline" ? columns : 1,
                  columnGap: columns > 1 ? "2em" : undefined,
                  columnRule: columns > 1 ? "1px solid #e2e8f0" : undefined,
                }}
                className="aether-doc"
              >
                <EditorContent editor={editor} />
              </div>
            </div>
          </div>

          <FootnotesBar notes={footnotes} />

          {/* Page break insertion helper */}
          {pageMode === "page" && editor && (
            <div className="mx-auto w-[816px] max-w-full">
              <button
                type="button"
                onClick={() => {
                  if (!editor) return;
                  chain(editor).insertContent('<hr class="page-break">').run();
                }}
                className="group flex w-full items-center gap-2 py-2"
                title="Insert page break"
              >
                <div className="flex-1 border-t-2 border-dashed border-slate-200 transition-colors group-hover:border-indigo-300" />
                <span className="shrink-0 rounded-full bg-slate-50 px-3 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400 transition-colors group-hover:bg-indigo-50 group-hover:text-indigo-600">
                  + Page break
                </span>
                <div className="flex-1 border-t-2 border-dashed border-slate-200 transition-colors group-hover:border-indigo-300" />
              </button>
            </div>
          )}

          {showShortcuts && (
            <div className="absolute bottom-4 left-4 z-10 w-72 rounded-2xl border border-slate-200 bg-white/95 p-4 text-xs shadow-xl backdrop-blur">
              <div className="mb-2 font-semibold text-slate-800">Keyboard shortcuts</div>
              <ul className="space-y-1 text-slate-600">
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+J</kbd> — Toggle Copilot</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+S</kbd> — Save checkpoint</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+F</kbd> — Find & Replace</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+H</kbd> — Replace</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+P</kbd> — Print</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+Z</kbd> — Undo</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+Shift+Z</kbd> — Redo</li>
                <li><kbd className="rounded bg-slate-100 px-1">⌘/Ctrl+B/I/U</kbd> — Bold / Italic / Underline</li>
                <li>Select text → Rewrite / Grammar panel</li>
              </ul>
            </div>
          )}
        </div>

        {panel !== "none" && (
          <SidePanel
            panel={panel}
            onClose={() => setPanel("none")}
            editor={editor}
            documentId={documentId}
            title={title}
            plainText={plainText}
            html={html}
            selection={selection}
            insights={insights}
            onInsights={setInsights}
            onApplyHtml={onApplyHtml}
            onReplacePhrase={replacePhrase}
            onApplyGrammarIssues={applyGrammarIssues}
            getRewriteTarget={getRewriteTarget}
            onApplyRewrite={applyRewriteTarget}
            onLoadTemplate={(content, t) => {
              onApplyHtml(content, "replace");
              if (t) {
                setTitle(t);
                scheduleSave(content, t);
              }
            }}
            comments={comments}
            onAddComment={async (body, anchorText) => {
              const res = await fetch(
                `/api/documents/${documentId}/comments`,
                {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ body, anchorText }),
                }
              );
              const data = await res.json();
              if (data.comment) setComments((c) => [data.comment, ...c]);
            }}
            onToggleComment={async (id, resolved) => {
              await fetch(`/api/documents/${documentId}/comments`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id, resolved }),
              });
              setComments((list) =>
                list.map((c) => (c.id === id ? { ...c, resolved } : c))
              );
            }}
            versions={versions}
            onRestoreVersion={(content, t) => {
              onApplyHtml(content, "replace");
              setTitle(t);
              scheduleSave(content, t);
            }}
            onCreateVersion={() => {
              void persist(html, title, {
                createVersion: true,
                versionLabel: "Named checkpoint",
              }).then(async () => {
                const res = await fetch(`/api/documents/${documentId}`);
                const data = await res.json();
                setVersions(data.versions || []);
              });
            }}
          />
        )}
      </div>

      {/* status bar — larger, Word-style, with real caret position */}
      <footer
        className={cn(
          "flex h-7 shrink-0 items-center justify-between gap-3 overflow-hidden border-t px-4 text-[11px] transition-all",
          focusMode && "hidden",
          darkMode
            ? "border-slate-800 bg-slate-900 text-slate-400"
            : "border-slate-200 bg-white text-slate-600"
        )}
      >
        <div className="flex min-w-0 items-center gap-3 whitespace-nowrap">
          <span className="font-medium">
            Page 1 of {estimatePages(wordCount)}
          </span>
          <span className="text-slate-400">·</span>
          <span>
            <strong className="tabular-nums text-slate-800">{wordCount}</strong>{" "}
            words
          </span>
          <span>
            <strong className="tabular-nums text-slate-800">
              {insights?.charCount ?? 0}
            </strong>{" "}
            chars
          </span>
          {selection && (
            <span className="rounded-md bg-indigo-50 px-2 py-0.5 font-medium text-indigo-700">
              Selection:{" "}
              <span className="tabular-nums">
                {selection.split(/\s+/).filter(Boolean).length}
              </span>{" "}
              words ·{" "}
              <span className="tabular-nums">{selection.length}</span> chars
            </span>
          )}
          {footnotes.length > 0 && (
            <span className="text-slate-400">
              · {footnotes.length} footnote
              {footnotes.length === 1 ? "" : "s"}
            </span>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-3 whitespace-nowrap">
          <span className="rounded-md bg-slate-50 px-2 py-0.5 font-medium text-slate-600">
            {pageMode === "page"
              ? `${columns > 1 ? `${columns}-col · ` : ""}Margins ${marginLeft}″/${marginRight}″`
              : `View: ${pageMode}`}
          </span>
          <span>English (US)</span>
          <span>
            Reading level:{" "}
            <strong className="text-slate-800">
              {insights?.gradeLevel ?? "—"}
            </strong>
          </span>
          {watermark && (
            <span className="rounded-md bg-amber-50 px-2 py-0.5 font-medium text-amber-700">
              {watermark}
            </span>
          )}
          <span className="hidden items-center gap-1 text-indigo-600 sm:inline-flex">
            <Sparkles className="h-3 w-3" /> Aether IQ
          </span>
        </div>
      </footer>

      <ProofOverlay
        editor={editor}
        visible={!!proofPopover}
        position={proofPopover?.position ?? null}
        issue={proofPopover?.issue ?? null}
        onClose={() => {
          setProofPopover(null);
          setActiveProofId(null);
        }}
        onApply={(issue) => {
          if (issue.suggestion && !issue.suggestion.startsWith("(")) {
            replacePhrase(issue.original, issue.suggestion, issue);
          } else {
            replacePhrase(issue.original, "", issue);
          }
          setProofPopover(null);
          setProofList((prev) => prev.filter((x) => x.id !== issue.id));
          setActiveProofId(null);
        }}
        onDismiss={(issue) => {
          setProofPopover(null);
          setProofList((prev) => prev.filter((x) => x.id !== issue.id));
          setActiveProofId(null);
        }}
      />

      {focusMode && (
        <div className="fixed inset-x-0 bottom-3 z-40 flex items-center justify-center gap-2 px-3">
          <div className="inline-flex items-center gap-2 rounded-full bg-slate-900/85 px-3 py-1.5 text-[11px] font-semibold text-white shadow-xl backdrop-blur">
            <SpellCheck2 className="h-3.5 w-3.5 text-indigo-300" />
            <span>{proofList.length} issue{proofList.length === 1 ? "" : "s"}</span>
            <button
              type="button"
              className="rounded-full px-2 py-0.5 text-[10px] text-indigo-200 hover:bg-white/10"
              onClick={() => {
                if (!proofList.length) return;
                const nextIndex = (activeProofIndex + 1) % proofList.length;
                openProofPopoverForIssue(proofList[nextIndex]);
              }}
            >
              Next issue
            </button>
            <button
              type="button"
              className="rounded-full px-2 py-0.5 text-[10px] text-indigo-200 hover:bg-white/10"
              onClick={() => {
                setFocusMode(false);
                setPanel("grammar");
              }}
            >
              Open Grammar panel
            </button>
            <button
              type="button"
              className="ml-1 rounded-full bg-white/15 px-2 py-0.5 text-[10px] text-white"
              onClick={() => setFocusMode(false)}
            >
              Exit focus
            </button>
          </div>
        </div>
      )}

      {/* Page setup dialog */}
      <PageSetupDialog
        open={showPageSetup}
        onClose={() => setShowPageSetup(false)}
        settings={{ marginLeft, marginRight, marginTop, marginBottom, pageSize, orientation }}
        onApply={(s) => {
          setMarginLeft(s.marginLeft);
          setMarginRight(s.marginRight);
          setMarginTop(s.marginTop);
          setMarginBottom(s.marginBottom);
          setPageSize(s.pageSize);
          setOrientation(s.orientation);
        }}
      />

      {/* Footnote insertion floating button */}
      {selection && editor && (
        <button
          type="button"
          onClick={() => {
            const note = window.prompt("Add footnote for selection:");
            if (!note?.trim()) return;
            setFootnotes((prev) => [...prev, note.trim()]);
            const { from } = editor.state.selection;
            editor.chain().focus().insertContentAt(from + selection.length, `<sup>[${footnotes.length + 1}]</sup>`).run();
          }}
          className="fixed bottom-20 right-6 z-30 flex items-center gap-1.5 rounded-full bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-lg shadow-indigo-500/30 transition hover:bg-indigo-500"
          title="Add footnote for selected text"
        >
          <span>📝 Add footnote</span>
        </button>
      )}
    </div>
  );
}
