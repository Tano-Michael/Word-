import { Extension } from "@tiptap/core";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import type { EditorState } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";

export interface ProofIssue {
  id: string;
  type: string;
  severity: "error" | "warning" | "suggestion";
  message: string;
  original: string;
  suggestion?: string;
  start: number;
  end: number;
}

export interface LiveProofingOptions {
  enabled: boolean;
  debounceMs: number;
  onIssues?: (issues: ProofIssue[]) => void;
  onAIIssues?: (patterns: any[]) => void;
}

export const liveProofingKey = new PluginKey<DecorationSet>("liveProofing");

/** Map a plain-text offset to a ProseMirror position while preserving blocks. */
function makeOffsetMap(doc: any) {
  const segments: { start: number; end: number; pos: number; len: number }[] = [];
  let cursor = 0;
  let blockCount = 0;

  doc.descendants((node: any, pos: number) => {
    if (node.isText && node.text) {
      segments.push({
        start: cursor,
        end: cursor + node.text.length,
        pos,
        len: node.text.length,
      });
      cursor += node.text.length;
      return false;
    }
    if (node.isTextblock) {
      if (blockCount > 0) cursor += 1;
      blockCount += 1;
    }
    return true;
  });

  return (offset: number): number | null => {
    if (offset < 0) return null;
    for (const segment of segments) {
      if (offset >= segment.start && offset <= segment.end) {
        const pmPos = segment.pos + offset - segment.start;
        // Clamp to valid range
        return Math.max(0, Math.min(pmPos, doc.content.size));
      }
    }
    return null;
  };
}

export function getProofIdAt(state: EditorState, pos: number): string | null {
  if (pos < 0 || pos >= state.doc.content.size) return null;
  const decoSet = liveProofingKey.getState(state) as DecorationSet | undefined;
  if (!decoSet) return null;
  const around = pos === 0 ? 0 : pos - 1;
  const near = decoSet.find(around, pos + 1);
  for (const deco of near) {
    const spec = deco.spec as Record<string, string> | undefined;
    if (spec && typeof spec["data-proof-id"] === "string") {
      return spec["data-proof-id"];
    }
  }
  return null;
}

export const LiveProofing = Extension.create<LiveProofingOptions>({
  name: "liveProofing",

  addOptions() {
    return { enabled: true, debounceMs: 900, onIssues: undefined };
  },

  addProseMirrorPlugins() {
    if (!this.options.enabled) return [];
    const key = liveProofingKey;
    let timer: ReturnType<typeof setTimeout> | null = null;
    let controller: AbortController | null = null;
    let lastText = "";

    return [
      new Plugin<DecorationSet>({
        key,
        state: {
          init: () => DecorationSet.empty,
          apply(tr, old) {
            const meta = tr.getMeta(key) as { decorations?: DecorationSet } | undefined;
            if (meta?.decorations) return meta.decorations;
            return old.map(tr.mapping, tr.doc);
          },
        },
        props: {
          decorations(state) {
            return key.getState(state) ?? DecorationSet.empty;
          },
        },
        view: (view) => {
          const check = () => {
            if (timer) clearTimeout(timer);
            timer = setTimeout(async () => {
              const text = view.state.doc.textBetween(0, view.state.doc.content.size, "\n", "\n");
              if (text === lastText) return;
              lastText = text;

              controller?.abort();
              if (text.trim().length < 8) {
                this.options.onIssues?.([]);
                view.dispatch(view.state.tr.setMeta(key, { decorations: DecorationSet.empty }));
                return;
              }

              controller = new AbortController();
              try {
                const [grammarRes, protectionRes] = await Promise.all([
                  fetch("/api/ai/grammar", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ text }),
                    signal: controller.signal,
                  }),
                  fetch("/api/ai/protection", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ text }),
                    signal: controller.signal,
                  }),
                ]);

                const decorations: Decoration[] = [];
                const toPos = makeOffsetMap(view.state.doc);
                const docSize = view.state.doc.content.size;

                // Grammar issues
                if (grammarRes.ok) {
                  const grammarData = await grammarRes.json();
                  const issues = (grammarData.issues ?? []) as ProofIssue[];
                  this.options.onIssues?.(issues);
                  
                  for (const issue of issues) {
                    const startOffset = Number(issue.start);
                    const endOffset = Number(issue.end);
                    
                    // Skip invalid offsets
                    if (isNaN(startOffset) || isNaN(endOffset)) continue;
                    if (startOffset < 0 || endOffset < 0) continue;
                    if (endOffset <= startOffset) continue;
                    if (endOffset - startOffset > 100) continue; // Skip huge ranges
                    
                    const from = toPos(startOffset);
                    const to = toPos(endOffset);
                    
                    // Skip if mapping failed or positions are invalid
                    if (from == null || to == null) continue;
                    if (from < 0 || to < 0) continue;
                    if (from > docSize || to > docSize) continue;
                    if (from >= to) continue;
                    
                    // Limit decoration size to prevent entire-document highlights
                    const decorationSize = to - from;
                    if (decorationSize > 50) continue; // Skip decorations larger than 50 chars
                    
                    decorations.push(
                      Decoration.inline(from, to, {
                        class: `aether-proof aether-proof--${issue.severity}`,
                        title: issue.message,
                        "data-proof-id": issue.id,
                      })
                    );
                  }
                }

                // Protection (AI phrase) issues
                if (protectionRes.ok) {
                  const protectionData = await protectionRes.json();
                  const patterns = (protectionData.patterns ?? []).filter((p: any) => p.type === "common_ai_phrase");
                  this.options.onAIIssues?.(patterns);
                  
                  for (const p of patterns) {
                    if (!p.originalPhrase || typeof p.originalPhrase !== "string") continue;
                    if (p.originalPhrase.length < 3) continue; // Skip very short phrases
                    
                    // Find phrase positions in text
                    const escaped = p.originalPhrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                    const regex = new RegExp(`\\b${escaped}\\b`, "gi");
                    let match;
                    let matchCount = 0;
                    
                    while ((match = regex.exec(text)) !== null) {
                      matchCount++;
                      if (matchCount > 20) break; // Limit to 20 matches per phrase
                      
                      const from = toPos(match.index);
                      const to = toPos(match.index + match[0].length);
                      
                      if (from == null || to == null) continue;
                      if (from < 0 || to < 0) continue;
                      if (from > docSize || to > docSize) continue;
                      if (from >= to) continue;
                      
                      const decorationSize = to - from;
                      if (decorationSize > 50) continue;
                      
                      decorations.push(
                        Decoration.inline(from, to, {
                          class: "aether-proof aether-proof--ai",
                          title: `AI-like phrase: "${p.originalPhrase}" → "${p.suggestedPhrase}"`,
                          "data-proof-id": `ai-${match.index}-${p.originalPhrase}`,
                          "data-ai-original": p.originalPhrase,
                          "data-ai-suggested": p.suggestedPhrase,
                        })
                      );
                    }
                  }
                }

                const currentDoc = view.state.doc;
                const transaction = view.state.tr.setMeta(key, {
                  decorations: DecorationSet.create(currentDoc, decorations),
                });
                transaction.setMeta("addToHistory", false);
                view.dispatch(transaction);
              } catch (error) {
                if ((error as Error).name !== "AbortError") {
                  console.warn("Live proofing unavailable:", error);
                }
              }
            }, this.options.debounceMs);
          };

          check();
          return {
            update: (nextView, previousState) => {
              if (!nextView.state.doc.eq(previousState.doc)) check();
            },
            destroy: () => {
              if (timer) clearTimeout(timer);
              controller?.abort();
            },
          };
        },
      }),
    ];
  },
});
