"use client";

import React, { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { Editor } from "@tiptap/react";
import LinkNext from "next/link";
import {
  AlignCenter,
  AlignJustify,
  AlignLeft,
  AlignRight,
  ArrowLeft,
  BarChart3,
  Bold,
  CheckSquare,
  ChevronDown,
  ChevronUp,
  Code,
  Columns,
  Copy as CopyIcon,
  Download,
  Eye,
  EyeOff,
  FilePlus,
  FileText,
  FileUp,
  Focus,
  Heading1,
  Heading2,
  Heading3,
  Highlighter,
  History,
  Image as ImageIcon,
  ImagePlus,
  Italic,
  Keyboard,
  LayoutTemplate,
  Link2,
  List,
  ListOrdered,
  ListTree,
  MessageSquare,
  Minus,
  Moon,
  Pilcrow,
  Printer,
  Quote,
  Redo2,
  RefreshCw,
  RemoveFormatting,
  Save,
  Search,
  Shield,
  Sparkles,
  SpellCheck2,
  Star,
  Strikethrough,
  Subscript as SubscriptIcon,
  Sun,
  Superscript,
  Table as TableIcon,
  Type,
  Underline as UnderlineIcon,
  Undo2,
} from "lucide-react";
import { cn, formatRelativeDate } from "@/lib/utils";
import { chain } from "@/lib/tiptap-commands";
import type { PanelId } from "@/lib/types";
import type { PageLayoutMode } from "./PageLayout";
import { SpeechTools } from "./SpeechTools";

export type RibbonTabId =
  | "file"
  | "home"
  | "insert"
  | "design"
  | "layout"
  | "references"
  | "review"
  | "view"
  | "ai";

export interface WordRibbonProps {
  title: string;
  onTitleChange: (v: string) => void;
  saving: "idle" | "saving" | "saved" | "error";
  lastSaved: Date | null;
  wordCount: number;
  starred: boolean;
  onToggleStar: () => void;
  editor: Editor | null;
  fontSize: string;
  onFontSize: (v: string) => void;
  activePanel: PanelId;
  onTogglePanel: (id: PanelId) => void;
  pageMode: PageLayoutMode;
  onPageModeChange: (mode: PageLayoutMode) => void;
  columns: number;
  onColumnsChange: (cols: number) => void;
  watermark: string;
  onWatermarkChange: (w: string) => void;
  onOpenPageSetup: () => void;
  trackMode: "editing" | "suggesting";
  onToggleTrackMode: () => void;
  showProofing: boolean;
  onToggleProofing: () => void;
  proofIssues: number;
  zoom: number;
  onZoomChange: (z: number) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  focusMode: boolean;
  onToggleFocusMode: () => void;
  showRuler: boolean;
  onToggleRuler: () => void;
  onToggleShortcuts: () => void;
  onNewDoc: () => void;
  onImportFile: () => void;
  onSaveCheckpoint: () => void;
  onDuplicateDoc: () => void;
  onPrint: () => void;
  onInsertFootnote: () => void;
}

type IconType = React.ComponentType<{ className?: string }>;

function IconButton({
  onClick,
  active,
  disabled,
  title,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onMouseDown={(event) => {
        event.preventDefault();
        onClick?.();
      }}
      className={cn(
        "inline-flex h-7 w-7 shrink-0 items-center justify-center rounded text-slate-600 transition hover:bg-slate-200/70 hover:text-slate-950 disabled:pointer-events-none disabled:opacity-30 dark:text-slate-300 dark:hover:bg-slate-700 dark:hover:text-white",
        active &&
          "bg-indigo-100 text-indigo-700 ring-1 ring-inset ring-indigo-200 dark:bg-indigo-500/20 dark:text-indigo-200 dark:ring-indigo-500/30"
      )}
    >
      {children}
    </button>
  );
}

function ActionButton({
  onClick,
  active,
  disabled,
  title,
  icon: Icon,
  label,
  accent = false,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  title: string;
  icon: IconType;
  label: string;
  accent?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onMouseDown={(event) => {
        event.preventDefault();
        onClick?.();
      }}
      className={cn(
        "inline-flex h-7 shrink-0 items-center gap-1.5 rounded px-2 text-[11px] font-medium text-slate-700 transition hover:bg-slate-200/70 disabled:pointer-events-none disabled:opacity-35 dark:text-slate-200 dark:hover:bg-slate-700",
        active &&
          "bg-indigo-100 font-semibold text-indigo-700 ring-1 ring-inset ring-indigo-200 dark:bg-indigo-500/20 dark:text-indigo-200 dark:ring-indigo-500/30",
        accent &&
          "bg-indigo-600 font-semibold text-white shadow-sm hover:bg-indigo-500 dark:bg-indigo-500 dark:text-white dark:hover:bg-indigo-400"
      )}
    >
      <Icon className="h-3.5 w-3.5" />
      <span>{label}</span>
    </button>
  );
}

function Divider() {
  return <div className="mx-0.5 h-4 w-px shrink-0 bg-slate-300/80 dark:bg-slate-700" />;
}

function CompactSelect({
  value,
  onChange,
  title,
  children,
  width,
}: {
  value: string | number;
  onChange: (value: string) => void;
  title: string;
  children: React.ReactNode;
  width?: string;
}) {
  return (
    <select
      value={value}
      title={title}
      aria-label={title}
      onChange={(event) => onChange(event.target.value)}
      onMouseDown={(event) => event.stopPropagation()}
      className="h-7 shrink-0 rounded border border-slate-300 bg-white px-1.5 text-[11px] font-medium text-slate-700 outline-none transition focus:border-indigo-400 focus:ring-1 focus:ring-indigo-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
      style={width ? { width } : undefined}
    >
      {children}
    </select>
  );
}

function CaseChangeDropdown({ editor }: { editor: Editor }) {
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState<{ top: number; left: number } | null>(
    null
  );
  const buttonRef = useRef<HTMLButtonElement>(null);

  const applyCase = (transform: (text: string) => string) => {
    const { from, to } = editor.state.selection;
    if (from === to) return;
    const text = editor.state.doc.textBetween(from, to, "");
    chain(editor).insertContentAt({ from, to }, transform(text)).run();
    setOpen(false);
  };

  const cases = [
    { label: "UPPERCASE", transform: (text: string) => text.toUpperCase() },
    { label: "lowercase", transform: (text: string) => text.toLowerCase() },
    {
      label: "Title Case",
      transform: (text: string) =>
        text.toLowerCase().replace(/\b\w/g, (character) => character.toUpperCase()),
    },
    {
      label: "Sentence case",
      transform: (text: string) =>
        text
          .toLowerCase()
          .replace(/(^\s*\w|[.!?]\s+\w)/g, (match) => match.toUpperCase()),
    },
    {
      label: "tOGGLE cASE",
      transform: (text: string) =>
        text
          .split("")
          .map((character) =>
            character === character.toUpperCase()
              ? character.toLowerCase()
              : character.toUpperCase()
          )
          .join(""),
    },
  ];

  useEffect(() => {
    if (!open || !buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    setPosition({ top: rect.bottom + 4, left: rect.left });

    const closeOnPointer = (event: MouseEvent) => {
      const target = event.target as Element;
      if (
        !buttonRef.current?.contains(target) &&
        !target.closest("[data-case-dropdown]")
      ) {
        setOpen(false);
      }
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };

    document.addEventListener("mousedown", closeOnPointer);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeOnPointer);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [open]);

  return (
    <div className="relative shrink-0">
      <button
        ref={buttonRef}
        type="button"
        title="Change case"
        onMouseDown={(event) => event.preventDefault()}
        onClick={() => setOpen((current) => !current)}
        className={cn(
          "inline-flex h-7 items-center rounded px-1.5 text-[11px] font-bold text-slate-700 hover:bg-slate-200/70 dark:text-slate-200 dark:hover:bg-slate-700",
          open && "bg-slate-200/70 dark:bg-slate-700"
        )}
      >
        Aa
      </button>
      {open &&
        position &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            data-case-dropdown
            className="fixed z-[9999] w-36 overflow-hidden rounded-lg border border-slate-200 bg-white py-1 shadow-xl dark:border-slate-700 dark:bg-slate-800"
            style={{ top: position.top, left: position.left }}
          >
            {cases.map((item) => (
              <button
                key={item.label}
                type="button"
                onMouseDown={(event) => {
                  event.preventDefault();
                  applyCase(item.transform);
                }}
                className="block w-full px-3 py-1.5 text-left text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 dark:text-slate-200 dark:hover:bg-indigo-500/20 dark:hover:text-indigo-200"
              >
                {item.label}
              </button>
            ))}
          </div>,
          document.body
        )}
    </div>
  );
}

export function WordRibbon(props: WordRibbonProps) {
  const [activeTab, setActiveTab] = useState<RibbonTabId>("home");
  const [collapsed, setCollapsed] = useState(false);
  const { editor, fontSize, onFontSize } = props;

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        setCollapsed(localStorage.getItem("aether-ribbon-collapsed") === "true");
      } catch {
        // Storage can be disabled in private or hardened browser modes.
      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("aether-ribbon-collapsed", String(collapsed));
    } catch {
      // The ribbon remains usable even when its preference cannot be saved.
    }
  }, [collapsed]);

  const tabs: { id: RibbonTabId; label: string }[] = [
    { id: "file", label: "File" },
    { id: "home", label: "Home" },
    { id: "insert", label: "Insert" },
    { id: "design", label: "Design" },
    { id: "layout", label: "Layout" },
    { id: "references", label: "References" },
    { id: "review", label: "Review" },
    { id: "view", label: "View" },
    { id: "ai", label: "Aether AI" },
  ];

  const activateTab = (tab: RibbonTabId) => {
    if (tab === activeTab && !collapsed) {
      setCollapsed(true);
      return;
    }
    setActiveTab(tab);
    setCollapsed(false);
  };

  const setLink = () => {
    if (!editor) return;
    const previous = editor.getAttributes("link").href as string | undefined;
    const url = window.prompt("Link URL", previous || "https://");
    if (url === null) return;
    if (!url.trim()) {
      chain(editor).extendMarkRange("link").unsetLink().run();
      return;
    }
    chain(editor).extendMarkRange("link").setLink({ href: url.trim() }).run();
  };

  const addImageFromUrl = () => {
    if (!editor) return;
    const url = window.prompt("Image URL");
    if (url?.trim()) chain(editor).setImage({ src: url.trim() }).run();
  };

  const addImageFromFile = () => {
    if (!editor) return;
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => chain(editor).setImage({ src: String(reader.result) }).run();
      reader.readAsDataURL(file);
    };
    input.click();
  };

  const insertTable = () => {
    if (!editor) return;
    chain(editor).insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
  };

  const savingLabel =
    props.saving === "saving"
      ? "Saving…"
      : props.saving === "error"
        ? "Save failed"
        : props.lastSaved
          ? `Saved ${formatRelativeDate(props.lastSaved)}`
          : "Autosave on";

  return (
    <header
      className={cn(
        "z-40 w-full shrink-0 select-none border-b border-slate-200 bg-white/95 shadow-[0_1px_0_rgba(15,23,42,0.03)] backdrop-blur dark:border-slate-800 dark:bg-slate-900/95",
        props.darkMode && "text-slate-100"
      )}
    >
      {/* One compact title-and-tabs row. No wrapping means it never becomes tall. */}
      <div className="flex h-9 min-w-0 items-center gap-1 px-2">
        <LinkNext
          href="/"
          className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white"
          title="Back to documents"
        >
          <ArrowLeft className="h-4 w-4" />
        </LinkNext>

        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-indigo-600 to-violet-600 text-[10px] font-black text-white shadow-sm">
          Æ
        </div>

        <div className="flex min-w-[118px] max-w-[260px] items-center gap-1 sm:min-w-[170px]">
          <input
            value={props.title}
            onChange={(event) => props.onTitleChange(event.target.value)}
            className="min-w-0 flex-1 truncate rounded border-0 bg-transparent px-1 py-0.5 text-xs font-semibold text-slate-900 outline-none hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-indigo-300 dark:text-white dark:hover:bg-slate-800 dark:focus:bg-slate-800"
            placeholder="Document title"
          />
          <button
            type="button"
            onClick={props.onToggleStar}
            className={cn(
              "rounded p-1 text-slate-300 transition hover:bg-slate-100 hover:text-slate-500 dark:text-slate-600 dark:hover:bg-slate-800",
              props.starred && "text-amber-500 dark:text-amber-400"
            )}
            title="Star document"
          >
            <Star className={cn("h-3.5 w-3.5", props.starred && "fill-current")} />
          </button>
        </div>

        <div className="hidden shrink-0 items-center gap-1 text-[10px] text-slate-400 xl:flex" title={savingLabel}>
          <span
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              props.saving === "error"
                ? "bg-rose-500"
                : props.saving === "saving"
                  ? "animate-pulse bg-amber-500"
                  : "bg-emerald-500"
            )}
          />
          <span className="max-w-24 truncate">{savingLabel}</span>
        </div>

        <Divider />

        <nav
          aria-label="Ribbon tabs"
          className="min-w-0 flex-1 overflow-x-auto overflow-y-hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          <div className="flex h-9 min-w-max items-stretch">
            {tabs.map((tab) => {
              const selected = tab.id === activeTab;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => activateTab(tab.id)}
                  className={cn(
                    "relative h-9 shrink-0 px-2 text-[11px] font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-950 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white",
                    selected &&
                      "font-semibold text-indigo-700 after:absolute after:inset-x-2 after:bottom-0 after:h-0.5 after:rounded-full after:bg-indigo-600 dark:text-indigo-300 dark:after:bg-indigo-400"
                  )}
                  aria-selected={selected}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </nav>

        <div className="flex shrink-0 items-center gap-0.5">
          <IconButton
            title="Undo (Ctrl+Z)"
            onClick={() => editor && chain(editor).undo().run()}
            disabled={!editor || !editor.can().undo()}
          >
            <Undo2 className="h-3.5 w-3.5" />
          </IconButton>
          <IconButton
            title="Redo (Ctrl+Y)"
            onClick={() => editor && chain(editor).redo().run()}
            disabled={!editor || !editor.can().redo()}
          >
            <Redo2 className="h-3.5 w-3.5" />
          </IconButton>
          <IconButton
            title="Export and share"
            active={props.activePanel === "export"}
            onClick={() => props.onTogglePanel("export")}
          >
            <Download className="h-3.5 w-3.5" />
          </IconButton>
          <button
            type="button"
            onClick={() => setCollapsed((current) => !current)}
            className="inline-flex h-7 items-center gap-1 rounded px-1.5 text-[10px] font-semibold text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
            title={collapsed ? "Show ribbon commands" : "Show tabs only"}
          >
            {collapsed ? (
              <ChevronDown className="h-3.5 w-3.5" />
            ) : (
              <ChevronUp className="h-3.5 w-3.5" />
            )}
            <span className="hidden 2xl:inline">{collapsed ? "Expand" : "Tabs only"}</span>
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className="flex h-10 min-w-0 items-center overflow-hidden border-t border-slate-100 bg-slate-50/80 px-2 dark:border-slate-800 dark:bg-slate-950/35">
          <div className="flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto overflow-y-hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {activeTab === "home" && editor && (
              <>
                <CompactSelect
                  title="Font family"
                  width="132px"
                  value={
                    (editor.getAttributes("textStyle").fontFamily as string) ||
                    "__default"
                  }
                  onChange={(value) => {
                    if (value === "__default") chain(editor).unsetFontFamily().run();
                    else chain(editor).setFontFamily(value).run();
                  }}
                >
                  <option value="__default">Default font</option>
                  <option value="Inter, system-ui, sans-serif">Inter</option>
                  <option value="Calibri, 'Helvetica Neue', Arial, sans-serif">Calibri</option>
                  <option value="Arial, Helvetica, sans-serif">Arial</option>
                  <option value="Cambria, Georgia, serif">Cambria</option>
                  <option value="Georgia, serif">Georgia</option>
                  <option value="'Times New Roman', Times, serif">Times New Roman</option>
                  <option value="Garamond, Baskerville, serif">Garamond</option>
                  <option value="Verdana, Geneva, sans-serif">Verdana</option>
                  <option value="Consolas, monospace">Consolas</option>
                </CompactSelect>

                <CompactSelect
                  title="Font size"
                  width="58px"
                  value={
                    (editor.getAttributes("textStyle").fontSize as string) || fontSize
                  }
                  onChange={(value) => {
                    chain(editor).setFontSize(value).run();
                    onFontSize(value);
                  }}
                >
                  {[10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 28, 32, 36, 48, 64, 72].map(
                    (size) => (
                      <option key={size} value={`${size}px`}>
                        {size}
                      </option>
                    )
                  )}
                </CompactSelect>

                <Divider />
                <IconButton title="Bold (Ctrl+B)" active={editor.isActive("bold")} onClick={() => chain(editor).toggleBold().run()}>
                  <Bold className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Italic (Ctrl+I)" active={editor.isActive("italic")} onClick={() => chain(editor).toggleItalic().run()}>
                  <Italic className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Underline (Ctrl+U)" active={editor.isActive("underline")} onClick={() => chain(editor).toggleUnderline().run()}>
                  <UnderlineIcon className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Strikethrough" active={editor.isActive("strike")} onClick={() => chain(editor).toggleStrike().run()}>
                  <Strikethrough className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Highlight" active={editor.isActive("highlight")} onClick={() => chain(editor).toggleHighlight().run()}>
                  <Highlighter className="h-3.5 w-3.5" />
                </IconButton>
                <label className="relative inline-flex h-7 w-7 shrink-0 cursor-pointer items-center justify-center rounded hover:bg-slate-200/70 dark:hover:bg-slate-700" title="Text colour">
                  <Type className="h-3.5 w-3.5 text-slate-600 dark:text-slate-300" />
                  <input type="color" className="absolute inset-0 cursor-pointer opacity-0" onChange={(event) => chain(editor).setColor(event.target.value).run()} />
                </label>
                <CaseChangeDropdown editor={editor} />
                <IconButton title="Subscript" active={editor.isActive("subscript")} onClick={() => chain(editor).toggleSubscript().run()}>
                  <SubscriptIcon className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Superscript" active={editor.isActive("superscript")} onClick={() => chain(editor).toggleSuperscript().run()}>
                  <Superscript className="h-3.5 w-3.5" />
                </IconButton>

                <Divider />
                <IconButton title="Align left" active={editor.isActive({ textAlign: "left" })} onClick={() => chain(editor).setTextAlign("left").run()}>
                  <AlignLeft className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Align centre" active={editor.isActive({ textAlign: "center" })} onClick={() => chain(editor).setTextAlign("center").run()}>
                  <AlignCenter className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Align right" active={editor.isActive({ textAlign: "right" })} onClick={() => chain(editor).setTextAlign("right").run()}>
                  <AlignRight className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Justify" active={editor.isActive({ textAlign: "justify" })} onClick={() => chain(editor).setTextAlign("justify").run()}>
                  <AlignJustify className="h-3.5 w-3.5" />
                </IconButton>

                <CompactSelect
                  title="Line spacing"
                  width="78px"
                  value={(editor.getAttributes("textStyle").lineHeight as string) || "__default"}
                  onChange={(value) => {
                    if (value === "__default") chain(editor).unsetLineHeight().run();
                    else chain(editor).setLineHeight(value).run();
                  }}
                >
                  <option value="__default">Spacing</option>
                  <option value="1">1.0</option>
                  <option value="1.15">1.15</option>
                  <option value="1.5">1.5</option>
                  <option value="2">2.0</option>
                  <option value="2.5">2.5</option>
                  <option value="3">3.0</option>
                </CompactSelect>

                <Divider />
                <IconButton title="Bullets" active={editor.isActive("bulletList")} onClick={() => chain(editor).toggleBulletList().run()}>
                  <List className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Numbering" active={editor.isActive("orderedList")} onClick={() => chain(editor).toggleOrderedList().run()}>
                  <ListOrdered className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Checklist" active={editor.isActive("taskList")} onClick={() => chain(editor).toggleTaskList().run()}>
                  <CheckSquare className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Paragraph" active={editor.isActive("paragraph")} onClick={() => chain(editor).setParagraph().run()}>
                  <Pilcrow className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Heading 1" active={editor.isActive("heading", { level: 1 })} onClick={() => chain(editor).toggleHeading({ level: 1 }).run()}>
                  <Heading1 className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Heading 2" active={editor.isActive("heading", { level: 2 })} onClick={() => chain(editor).toggleHeading({ level: 2 }).run()}>
                  <Heading2 className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Heading 3" active={editor.isActive("heading", { level: 3 })} onClick={() => chain(editor).toggleHeading({ level: 3 }).run()}>
                  <Heading3 className="h-3.5 w-3.5" />
                </IconButton>
                <IconButton title="Clear formatting" onClick={() => chain(editor).unsetAllMarks().clearNodes().run()}>
                  <RemoveFormatting className="h-3.5 w-3.5" />
                </IconButton>
              </>
            )}

            {activeTab === "insert" && editor && (
              <>
                <ActionButton icon={TableIcon} label="Table" title="Insert a 3 × 3 table" onClick={insertTable} />
                <ActionButton icon={ImagePlus} label="Picture" title="Insert picture from this device" onClick={addImageFromFile} />
                <ActionButton icon={ImageIcon} label="Online picture" title="Insert image from URL" onClick={addImageFromUrl} />
                <ActionButton icon={Link2} label="Link" title="Insert or edit hyperlink" onClick={setLink} />
                <Divider />
                <ActionButton icon={FileText} label="Page break" title="Insert page break" onClick={() => chain(editor).insertContent('<hr class="page-break">').run()} />
                <ActionButton icon={Minus} label="Rule" title="Insert horizontal rule" onClick={() => chain(editor).setHorizontalRule().run()} />
                <ActionButton icon={Quote} label="Quote" title="Toggle block quote" active={editor.isActive("blockquote")} onClick={() => chain(editor).toggleBlockquote().run()} />
                <ActionButton icon={Code} label="Code" title="Toggle code block" active={editor.isActive("codeBlock")} onClick={() => chain(editor).toggleCodeBlock().run()} />
                <Divider />
                <ActionButton icon={FileText} label="Footnote" title="Insert footnote" onClick={props.onInsertFootnote} />
                <ActionButton icon={MessageSquare} label="Comment" title="Open comments" active={props.activePanel === "comments"} onClick={() => props.onTogglePanel("comments")} />
              </>
            )}

            {activeTab === "design" && (
              <>
                <ActionButton icon={LayoutTemplate} label="Templates" title="Open templates" active={props.activePanel === "templates"} onClick={() => props.onTogglePanel("templates")} />
                <Divider />
                <label className="flex h-7 shrink-0 items-center gap-1 rounded border border-slate-300 bg-white px-2 text-[11px] font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                  Watermark
                  <select
                    value={props.watermark}
                    onChange={(event) => props.onWatermarkChange(event.target.value)}
                    className="max-w-36 bg-transparent text-[11px] font-semibold text-slate-800 outline-none dark:text-slate-100"
                  >
                    {["", "DRAFT", "CONFIDENTIAL", "DO NOT DISTRIBUTE", "SAMPLE", "ORIGINAL"].map((value) => (
                      <option key={value} value={value}>{value || "None"}</option>
                    ))}
                  </select>
                </label>
                <ActionButton icon={Sun} label="Light" title="Use light interface" active={!props.darkMode} onClick={() => props.darkMode && props.onToggleDarkMode()} />
                <ActionButton icon={Moon} label="Dark" title="Use dark interface" active={props.darkMode} onClick={() => !props.darkMode && props.onToggleDarkMode()} />
              </>
            )}

            {activeTab === "layout" && (
              <>
                <ActionButton icon={FileText} label="Page setup" title="Margins, size and orientation" onClick={props.onOpenPageSetup} accent />
                <label className="flex h-7 shrink-0 items-center gap-1 rounded border border-slate-300 bg-white px-2 text-[11px] font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                  <Columns className="h-3.5 w-3.5" />
                  Columns
                  <select value={props.columns} onChange={(event) => props.onColumnsChange(Number(event.target.value))} className="bg-transparent font-semibold text-slate-800 outline-none dark:text-slate-100">
                    {[1, 2, 3].map((count) => <option key={count} value={count}>{count}</option>)}
                  </select>
                </label>
                <Divider />
                {(["page", "web", "outline"] as PageLayoutMode[]).map((mode) => (
                  <ActionButton
                    key={mode}
                    icon={mode === "outline" ? ListTree : FileText}
                    label={mode === "page" ? "Print layout" : mode === "web" ? "Web layout" : "Outline"}
                    title={`Switch to ${mode} view`}
                    active={props.pageMode === mode}
                    onClick={() => props.onPageModeChange(mode)}
                  />
                ))}
                <Divider />
                <ActionButton icon={Columns} label="Ruler" title="Show or hide ruler" active={props.showRuler} onClick={props.onToggleRuler} />
              </>
            )}

            {activeTab === "references" && (
              <>
                <ActionButton icon={ListTree} label="Contents" title="Open document outline and table of contents" active={props.activePanel === "outline"} onClick={() => props.onTogglePanel("outline")} accent />
                <ActionButton icon={FileText} label="Footnote" title="Insert footnote" onClick={props.onInsertFootnote} />
                <ActionButton icon={Search} label="Research" title="Open research assistant" active={props.activePanel === "research"} onClick={() => props.onTogglePanel("research")} />
                <ActionButton icon={BarChart3} label="Insights" title="Document statistics and readability" active={props.activePanel === "insights"} onClick={() => props.onTogglePanel("insights")} />
              </>
            )}

            {activeTab === "review" && (
              <>
                <ActionButton
                  icon={SpellCheck2}
                  label={`Editor${props.proofIssues ? ` (${props.proofIssues})` : ""}`}
                  title="Show grammar and spelling review"
                  active={props.activePanel === "grammar"}
                  onClick={() => props.onTogglePanel("grammar")}
                  accent
                />
                <ActionButton icon={RefreshCw} label="Rewrite" title="Rewrite selected text" active={props.activePanel === "rewrite"} onClick={() => props.onTogglePanel("rewrite")} />
                <ActionButton icon={Shield} label="Originality" title="Open protection and originality tools" active={props.activePanel === "protection"} onClick={() => props.onTogglePanel("protection")} />
                <Divider />
                <ActionButton icon={props.showProofing ? Eye : EyeOff} label={props.showProofing ? "Proofing on" : "Proofing off"} title="Toggle live proofing" active={props.showProofing} onClick={props.onToggleProofing} />
                <ActionButton icon={props.trackMode === "suggesting" ? Eye : EyeOff} label={props.trackMode === "suggesting" ? "Suggesting" : "Editing"} title="Toggle editing and suggesting mode" active={props.trackMode === "suggesting"} onClick={props.onToggleTrackMode} />
                <Divider />
                <ActionButton icon={MessageSquare} label="Comments" title="Open comments" active={props.activePanel === "comments"} onClick={() => props.onTogglePanel("comments")} />
                <ActionButton icon={History} label="History" title="Open version history" active={props.activePanel === "versions"} onClick={() => props.onTogglePanel("versions")} />
              </>
            )}

            {activeTab === "view" && (
              <>
                <CompactSelect title="Zoom" width="70px" value={props.zoom} onChange={(value) => props.onZoomChange(Number(value))}>
                  {[75, 90, 100, 110, 125, 150].map((zoom) => <option key={zoom} value={zoom}>{zoom}%</option>)}
                </CompactSelect>
                <ActionButton icon={Columns} label="Ruler" title="Show or hide ruler" active={props.showRuler} onClick={props.onToggleRuler} />
                <ActionButton icon={Focus} label="Focus" title="Distraction-free focus mode" active={props.focusMode} onClick={props.onToggleFocusMode} />
                <ActionButton icon={props.darkMode ? Sun : Moon} label={props.darkMode ? "Light" : "Dark"} title="Toggle colour theme" onClick={props.onToggleDarkMode} />
                <ActionButton icon={Keyboard} label="Shortcuts" title="Show keyboard shortcuts" onClick={props.onToggleShortcuts} />
                <Divider />
                <SpeechTools editor={editor} />
              </>
            )}

            {activeTab === "ai" && (
              <>
                <ActionButton icon={Sparkles} label="Copilot" title="Open Aether Copilot" active={props.activePanel === "ai"} onClick={() => props.onTogglePanel("ai")} accent />
                <ActionButton icon={RefreshCw} label="Rewrite" title="Rewrite selected text" active={props.activePanel === "rewrite"} onClick={() => props.onTogglePanel("rewrite")} />
                <ActionButton icon={SpellCheck2} label="Grammar" title="Grammar, spelling and clarity" active={props.activePanel === "grammar"} onClick={() => props.onTogglePanel("grammar")} />
                <ActionButton icon={Search} label="Research" title="Research assistant" active={props.activePanel === "research"} onClick={() => props.onTogglePanel("research")} />
                <ActionButton icon={BarChart3} label="Insights" title="Writing analytics" active={props.activePanel === "insights"} onClick={() => props.onTogglePanel("insights")} />
                <ActionButton icon={Shield} label="Protect" title="Originality and AI-pattern checks" active={props.activePanel === "protection"} onClick={() => props.onTogglePanel("protection")} />
              </>
            )}

            {activeTab === "file" && (
              <>
                <ActionButton icon={FilePlus} label="New" title="Create a new blank document" onClick={props.onNewDoc} accent />
                <ActionButton icon={FileUp} label="Open" title="Open DOCX, PDF, RTF, Markdown or text" onClick={props.onImportFile} />
                <ActionButton icon={Save} label="Checkpoint" title="Save a named version checkpoint" onClick={props.onSaveCheckpoint} />
                <ActionButton icon={CopyIcon} label="Duplicate" title="Duplicate document" onClick={props.onDuplicateDoc} />
                <ActionButton icon={Printer} label="Print" title="Print or save as PDF" onClick={props.onPrint} />
                <Divider />
                <ActionButton icon={Download} label="Export" title="Export DOCX, PDF, Markdown or HTML" active={props.activePanel === "export"} onClick={() => props.onTogglePanel("export")} />
              </>
            )}
          </div>

          <div className="ml-2 hidden shrink-0 items-center gap-2 border-l border-slate-300 pl-2 text-[10px] text-slate-400 2xl:flex dark:border-slate-700">
            <span>{props.wordCount.toLocaleString()} words</span>
          </div>
        </div>
      )}
    </header>
  );
}
