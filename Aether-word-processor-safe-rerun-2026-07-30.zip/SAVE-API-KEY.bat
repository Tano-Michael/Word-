@echo off
setlocal EnableDelayedExpansion
title Aether - Save API Key Securely
color 0E

cd /d "%~dp0"

echo.
echo   ============================================================
echo        AETHER - SAVE API KEY SECURELY
echo   ============================================================
echo.
echo   This stores your API key in Windows Credential Manager.
echo   It will NOT be saved in any file on your disk.
echo   Only your Windows user account can access it.
echo.
echo   Choose which provider to configure:
echo.
echo     1. Google Gemini (recommended, free)
echo     2. OpenAI
echo     3. Anthropic
echo     4. LanguageTool
echo.

set /p CHOICE="  Choice [1-4]: "

if "%CHOICE%"=="1" (
    set "PROVIDER=Gemini"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherGemini"
    set "ENV_VAR=GEMINI_API_KEY"
) else if "%CHOICE%"=="2" (
    set "PROVIDER=OpenAI"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherOpenAI"
    set "ENV_VAR=OPENAI_API_KEY"
) else if "%CHOICE%"=="3" (
    set "PROVIDER=Anthropic"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherAnthropic"
    set "ENV_VAR=ANTHROPIC_API_KEY"
) else if "%CHOICE%"=="4" (
    set "PROVIDER=LanguageTool"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherLanguageTool"
    set "ENV_VAR=LANGUAGETOOL_API_KEY"
) else (
    echo   Invalid choice.
    pause
    exit /b 1
)

echo.
echo   %PROVIDER% selected.
echo.

REM Remove any existing entry first
cmdkey /list | findstr "%TARGET%" >nul 2>nul
if not errorlevel 1 (
    echo   Found existing %PROVIDER% key. Removing it first...
    cmdkey /remove:%TARGET% >nul 2>nul
)

echo   Paste your %PROVIDER% API key below.
echo   (The key will be hidden as you type)
echo.

REM Use PowerShell to securely read the key (hidden input)
for /f "delims=" %%K in ('powershell -NoProfile -Command "Read-Host -Prompt '  %PROVIDER% API key' -AsSecureString | ForEach-Object { [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($_)) }"') do (
    set "API_KEY=%%K"
)

if not defined API_KEY (
    echo   No key entered. Aborted.
    pause
    exit /b 1
)

echo.
echo   Saving to Windows Credential Manager...

REM Store in Credential Manager (generic credential, tied to this user account)
cmdkey /generic:%TARGET% /user:AetherApp /pass:%API_KEY% >nul 2>nul

if errorlevel 1 (
    echo   Failed to save the key.
    pause
    exit /b 1
)

echo   %PROVIDER% API key saved securely.
echo.
echo   It is now stored in Windows Credential Manager and can only be
echo   accessed by your Windows user account on this computer.
echo.
echo   When you start Aether.bat, it will automatically load the key
echo   from Credential Manager and set it as an environment variable.
echo.
echo   To delete this key later, run DELETE-API-KEY.bat
echo.
pause
endlocal
exit /b 0
