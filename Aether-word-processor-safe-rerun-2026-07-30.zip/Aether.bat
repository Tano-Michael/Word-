@echo off
setlocal EnableDelayedExpansion
title Aether - AI Document OS
color 0B

cd /d "%~dp0"

echo.
echo   ============================================
echo          AETHER - AI DOCUMENT OS
echo   ============================================
echo.

REM ===============================================================
REM  1 - Node.js present?
REM ===============================================================
where node >nul 2>nul
if errorlevel 1 (
    color 0C
    echo   [X] Node.js was not found on this computer.
    echo.
    echo       Double-click INSTALL.bat first - it installs everything.
    echo.
    pause
    exit /b 1
)

REM ===============================================================
REM  2 - Installed? If not, run the installer automatically.
REM ===============================================================
if not exist "node_modules" (
    color 0E
    echo   Aether is not installed yet. Launching the installer...
    echo.
    call "%~dp0INSTALL.bat"
    if not exist "node_modules" (
        color 0C
        echo.
        echo   [X] Installation did not finish. Run INSTALL.bat directly
        echo       and note the error message it shows.
        echo.
        pause
        exit /b 1
    )
)

REM ===============================================================
REM  2.5 - Load API keys from Windows Credential Manager (secure)
REM ===============================================================
call :LoadSecureKey "Microsoft_WindowsSystem_AetherGemini" "GEMINI_API_KEY"
call :LoadSecureKey "Microsoft_WindowsSystem_AetherOpenAI" "OPENAI_API_KEY"
call :LoadSecureKey "Microsoft_WindowsSystem_AetherAnthropic" "ANTHROPIC_API_KEY"
call :LoadSecureKey "Microsoft_WindowsSystem_AetherLanguageTool" "LANGUAGETOOL_API_KEY"

REM ===============================================================
REM  3 - Built? If not, build now (one time).
REM ===============================================================
if not exist ".next\BUILD_ID" (
    echo   First launch - preparing the app. This takes 1-3 minutes...
    echo.
    call npm run build
    if errorlevel 1 (
        color 0C
        echo.
        echo   [X] The build failed. Run UPDATE.bat to repair, or
        echo       DIAGNOSE.bat to see what is wrong.
        echo.
        pause
        exit /b 1
    )
)

REM ===============================================================
REM  4 - Already running? Reuse any healthy Aether instance.
REM ===============================================================
set "RUNNING_PORT="
for %%P in (3000 3001 3005 3010 3020) do (
    if not defined RUNNING_PORT (
        curl -s --max-time 2 http://localhost:%%P/api/health > "%TEMP%\aether-health-%%P.json" 2>nul
        findstr /C:"\"ok\":true" "%TEMP%\aether-health-%%P.json" >nul 2>nul
        if not errorlevel 1 set "RUNNING_PORT=%%P"
    )
)

if defined RUNNING_PORT (
    echo   Aether is ALREADY RUNNING on port !RUNNING_PORT!.
    echo   Opening it in your browser now...
    echo.
    start "" "http://localhost:!RUNNING_PORT!"
    goto :alreadyrunning
)

REM ===============================================================
REM  5 - Choose a free port instead of assuming the fallback is free.
REM ===============================================================
set "PORT="
for %%P in (3000 3001 3005 3010 3020) do (
    if not defined PORT (
        netstat -ano 2>nul | findstr ":%%P " | findstr "LISTENING" >nul 2>nul
        if errorlevel 1 set "PORT=%%P"
    )
)

if not defined PORT (
    color 0C
    echo   [X] Aether could not find a free local port.
    echo       Close unused development servers, then start Aether again.
    pause
    exit /b 1
)

if not "!PORT!"=="3000" echo   Port 3000 is busy - using !PORT! instead.

REM ===============================================================
REM  6 - Start the server and WAIT for a real health check
REM ===============================================================
if not exist "data" mkdir "data" >nul 2>nul

echo   Starting Aether on http://localhost:!PORT!
echo.
echo   Waiting for the server to become ready...

start "" /min cmd /c "npm start -- -p !PORT! > data\launch.log 2>&1"

set "READY=0"
for /l %%i in (1,1,25) do (
    timeout /t 2 >nul
    curl -s --max-time 3 http://localhost:!PORT!/api/health > "%TEMP%\aether-wait.json" 2>nul
    if not errorlevel 1 (
        findstr /C:"\"ok\":true" "%TEMP%\aether-wait.json" >nul 2>nul
        if not errorlevel 1 (
            set "READY=1"
            goto :serverready
        )
    )
    echo   ...still starting (%%i)
)

:serverready

if "!READY!"=="1" (
    echo.
    echo   Server is ready. Opening your browser...
    start "" "http://localhost:!PORT!"
    echo.
    color 0A
    echo   ============================================
    echo    AETHER IS RUNNING
    echo    Address:  http://localhost:!PORT!
    echo.
    echo    Work in the browser window/tab that opened.
    echo    DO NOT close this window while using Aether,
    echo    or press any key below to stop Aether.
    echo   ============================================
    echo.
    pause >nul

    REM User pressed a key = stop the server
    echo.
    echo   Stopping Aether...
    for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":!PORT! " ^| findstr "LISTENING"') do (
        taskkill /F /PID %%p >nul 2>nul
    )
    echo   Aether has stopped.
    timeout /t 2 >nul
    endlocal
    exit /b 0
)

REM ===============================================================
REM  7 - Server did NOT come up - show the real reason
REM ===============================================================
color 0C
echo.
echo   [X] Aether did not start after 50 seconds.
echo.
echo   -------- Server log (data\launch.log) --------
if exist "data\launch.log" (
    type "data\launch.log"
) else (
    echo   (no log was written)
)
echo   ----------------------------------------------
echo.
echo   What to do, in order:
echo     1. Run UPDATE.bat (repairs the build, keeps your documents)
echo     2. If it still fails, run DIAGNOSE.bat and read the result
echo     3. Move this folder to C:\Aether and run UPDATE.bat
echo     4. As a last resort, close everything, delete the "data"
echo        folder (your documents), then run INSTALL.bat again
echo.
pause
endlocal
exit /b 1

:LoadSecureKey
REM Loads a key from Windows Credential Manager and sets it as an environment variable.
REM Usage: call :LoadSecureKey "target-name" "ENV_VAR_NAME"
set "KEY_TARGET=%~1"
set "KEY_ENV=%~2"
for /f "delims=" %%V in ('powershell -NoProfile -ExecutionPolicy Bypass -File "read-cred.ps1" -Target "%KEY_TARGET%" 2^>nul') do (
    if not "%%V"=="" (
        set "%KEY_ENV%=%%V"
        echo   [v] Loaded %KEY_ENV% from Credential Manager
    )
)
goto :eof

:alreadyrunning
echo.
echo   NOTE: An Aether window is already running somewhere on this
echo   computer - you do not need to keep this one open.
echo.
echo   If your browser did not open, use the exact port shown above.
echo   Run DIAGNOSE.bat if you need to find the active address.
echo.
pause
endlocal
exit /b 0
