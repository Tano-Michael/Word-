#!/usr/bin/env bash
# Netlify Deploy Helper — one line deploy from the folder
# Usage: ./netlify-deploy.sh
# (Requires the Netlify CLI: npm install -g netlify-cli)

set -euo pipefail

cd "$(dirname "$0")"

echo "=== Aether — Netlify Deploy ==="
echo ""
echo "This will deploy the app to Netlify (production)."
echo "Make sure you have the Netlify CLI installed:  npm i -g netlify-cli"
echo ""
read -rp "Continue? (y/N): " ANS
if [[ ! "${ANS,,}" =~ ^y ]]; then
  echo "Aborted."
  exit 0
fi

echo ""
echo "Installing dependencies..."
if [[ -f package-lock.json ]]; then
  npm ci --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi

echo "Building..."
npm run build

echo "Deploying to Netlify..."
netlify deploy --build --prod --dir=.next

echo ""
echo "Done! Your site URL was printed above."
echo "Open /api/diagnose on the deployed site and confirm the database and DOCX checks pass."
