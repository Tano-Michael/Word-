@echo off
setlocal EnableDelayedExpansion
title Aether - Delete API Key
color 0C

cd /d "%~dp0"

echo.
echo   ============================================================
echo        AETHER - DELETE API KEY
echo   ============================================================
echo.
echo   This removes your API key from Windows Credential Manager.
echo   The key will be permanently deleted.
echo.
echo   Choose which provider to remove:
echo.
echo     1. Google Gemini
echo     2. OpenAI
echo     3. Anthropic
echo     4. LanguageTool
echo     5. All of the above
echo.

set /p CHOICE="  Choice [1-5]: "

if "%CHOICE%"=="1" (
    set "PROVIDER=Gemini"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherGemini"
) else if "%CHOICE%"=="2" (
    set "PROVIDER=OpenAI"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherOpenAI"
) else if "%CHOICE%"=="3" (
    set "PROVIDER=Anthropic"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherAnthropic"
) else if "%CHOICE%"=="4" (
    set "PROVIDER=LanguageTool"
    set "TARGET=generic:Microsoft_WindowsSystem_AetherLanguageTool"
) else if "%CHOICE%"=="5" (
    set "REMOVE_ALL=1"
) else (
    echo   Invalid choice.
    pause
    exit /b 1
)

echo.

if defined REMOVE_ALL (
    echo   Removing all Aether API keys...
    cmdkey /remove:generic:Microsoft_WindowsSystem_AetherGemini >nul 2>nul
    cmdkey /remove:generic:Microsoft_WindowsSystem_AetherOpenAI >nul 2>nul
    cmdkey /remove:generic:Microsoft_WindowsSystem_AetherAnthropic >nul 2>nul
    cmdkey /remove:generic:Microsoft_WindowsSystem_AetherLanguageTool >nul 2>nul
    echo   All Aether API keys removed.
) else (
    echo   Removing %PROVIDER% API key...
    cmdkey /remove:%TARGET% >nul 2>nul
    if errorlevel 1 (
        echo   No %PROVIDER% key found in Credential Manager.
    ) else (
        echo   %PROVIDER% API key removed successfully.
    )
)

echo.
echo   The key has been deleted from this computer.
echo.
pause
endlocal
exit /b 0
