#!/usr/bin/env bash
# Aether - AI Document OS :: launcher for macOS / Linux
set -u

cd "$(dirname "$0")"

CYAN='\033[0;36m'; RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'

echo ""
echo -e "${CYAN}  ============================================${NC}"
echo -e "${CYAN}         AETHER - AI DOCUMENT OS${NC}"
echo -e "${CYAN}  ============================================${NC}"
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo -e "${RED}  [X] Node.js not found. Run ./install.sh first.${NC}"
  exit 1
fi

if [ ! -d "node_modules" ]; then
  echo -e "${RED}  [X] Dependencies missing. Run ./install.sh first.${NC}"
  exit 1
fi

if [ ! -d ".next" ]; then
  echo "  First run detected - building..."
  npm run build || exit 1
fi

# Reuse a healthy instance instead of starting a second database process.
if command -v curl >/dev/null 2>&1; then
  for candidate in 3000 3001 3005 3010 3020; do
    if curl -fsS --max-time 2 "http://localhost:${candidate}/api/health" 2>/dev/null | grep -q '"ok":true'; then
      URL="http://localhost:${candidate}"
      echo "  Aether is already running at ${URL}."
      if command -v open >/dev/null 2>&1; then open "$URL"
      elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
      fi
      exit 0
    fi
  done
fi

port_in_use() {
  local port="$1"
  if command -v lsof >/dev/null 2>&1; then
    lsof -i ":${port}" -sTCP:LISTEN >/dev/null 2>&1
  elif command -v nc >/dev/null 2>&1; then
    nc -z 127.0.0.1 "$port" >/dev/null 2>&1
  else
    return 1
  fi
}

PORT=""
for candidate in 3000 3001 3005 3010 3020; do
  if ! port_in_use "$candidate"; then
    PORT="$candidate"
    break
  fi
done

if [ -z "$PORT" ]; then
  echo -e "${RED}  [X] No free local port was found.${NC}"
  exit 1
fi

if [ "$PORT" != "3000" ]; then
  echo "  Port 3000 busy - using ${PORT}."
fi

URL="http://localhost:${PORT}"
echo -e "  Starting Aether at ${BOLD}${URL}${NC}"
echo ""
echo "  ------------------------------------------------"
echo "   Keep this terminal open while using Aether."
echo "   Press Ctrl+C to stop."
echo "  ------------------------------------------------"
echo ""

# Open the browser once the server is up
(
  sleep 4
  if command -v open >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  fi
) >/dev/null 2>&1 &

exec npm start -- -p "$PORT"
