# Netlify deployment guide for Aether

Aether can run on Netlify, but a **persistent PostgreSQL database is required**.
Do not use a serverless `/tmp` folder for documents: that storage is temporary
and can differ between function instances.

## Before deployment

1. Create a PostgreSQL database with any provider you trust.
2. Copy its connection string.
3. In Netlify, open **Site configuration → Environment variables**.
4. Add:

```text
DATABASE_URL=postgresql://...
```

Keep this value private. Never put a real database password in this folder or
commit it to source control.

## Deploy

```bash
./netlify-deploy.sh
```

Or use the Netlify web UI:

1. Connect the repository.
2. Set the build command to `npm run build`.
3. Set the publish directory to `.next`.
4. Confirm that `DATABASE_URL` exists before deploying.

## Verify after deployment

Open `/api/diagnose` on the deployed site. Confirm that these checks are healthy:

- Database reachable
- Data folder / runtime
- DOCX export engine

If `DATABASE_URL` is missing, Aether deliberately refuses to save documents
rather than pretending temporary serverless storage is permanent.
