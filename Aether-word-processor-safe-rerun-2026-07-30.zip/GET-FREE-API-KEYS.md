# Get Free API Keys for Aether

## ⚡ TROUBLESHOOTING: "I added my key but AI isn't working"

**Do this first — it tells you the exact problem:**

1. Open a document in Aether
2. Click the **Copilot** (✨) panel on the right
3. Click **"Test connection"**
4. Read the result — it shows precisely what's wrong and how to fix it

**The 3 most common causes:**

| Symptom | Cause | Fix |
|---------|-------|-----|
| "No API key was found" | The `.env` file is named `.env.txt`, or the key line has quotes/spaces | Rename to exactly `.env`. Line must be `GEMINI_API_KEY=AIzaSy...` with no quotes |
| "API key not valid" | Key copied incorrectly or expired | Re-copy the full key from Google AI Studio |
| Still says "not connected" | You didn't restart the server | **Fully close** the black Aether window, then run `Aether.bat` again |

> ⚠️ **Environment variables load only when the server starts.** After adding
> or changing a key, you MUST close and reopen `Aether.bat`.

**Easiest secure method:** run `SAVE-API-KEY.bat` — it stores the key in
Windows Credential Manager and `Aether.bat` loads it automatically. No file
editing, no `.env.txt` mistakes.

---

## These are FULLY FREE — no credit card needed.

---

## 1. Google Gemini — Best for Copilot & Rewrite (500 requests/day free)

**What you get:**
- Gemini 2.5 Flash — 500 requests/day, 15 requests/minute
- Works for Copilot, Rewrite, and all AI writing modes
- No credit card required

**How to get your key (3 minutes):**

1. Go to https://aistudio.google.com/app/apikey (opens in your browser)
2. Click **"Get API key"** → **"Create API key"**
3. A free key starting with `AIzaSy...` appears — copy it
4. Close this page, go back to Aether, click the **CONNECT-ONLINE-AI.bat** and choose option 3 (Gemini)
5. **Paste the key** when asked
6. Choose model: `gemini-2.5-flash`

OR paste this into your `.env` file:
```env
AETHER_AI_PROVIDER=gemini
GEMINI_API_KEY=AIzaSy...your-key-here...
GEMINI_MODEL=gemini-2.5-flash
```

---

## 2. LanguageTool — Grammar & Clarity (free, no key needed)

Already built in. Click **"Check online"** in the Grammar panel and it works automatically against the free public LanguageTool endpoint (20 requests/minute, 20KB per check).

For higher limits (750KB, 80 req/min), get a free API key:
1. Go to https://languagetool.org/editor/settings/api (opens in browser)
2. Click **"Generate API key"**
3. Copy the key
4. Paste into CONNECT-ONLINE-AI.bat or add to `.env`:
```env
LANGUAGETOOL_API_KEY=your-key
LANGUAGETOOL_AUTHENTICATED=1
```

---

## 3. OpenAI — Alternative (requires prepaid, but ~$5 minimum)

Only if Gemini doesn't suit your needs:
1. Go to https://platform.openai.com/settings/organization/api-keys
2. Create a new key
3. Add at least $5 in credits
4. Use CONNECT-ONLINE-AI.bat option 1

---

## 4. Anthropic Claude — Alternative (requires prepaid)

1. Go to https://console.anthropic.com/settings/keys
2. Create a key
3. Add credits
4. Use CONNECT-ONLINE-AI.bat option 2

---

## What each feature uses

| Feature | Without API key | With Gemini free key |
|---------|----------------|---------------------|
| Grammar & Clarity | ✅ 40+ local rules + LanguageTool public | ✅ Same + higher LanguageTool limit |
| Rewrite Studio | ✅ Local 13-mode rewriter | ✅ **Cloud-powered rewrite with Gemini** |
| Copilot (AI modes) | ✅ 18 local template modes | ✅ **Full AI generation with Gemini** |
| AI Protection | ✅ Local heuristic engine | ✅ Local engine (heuristic only) |
| Read Aloud | ✅ Browser voices | ✅ Same |

With the Gemini key, the Rewrite and Copilot panels will automatically switch from "local" to "cloud" mode for much better results.

---

## Secure Storage — Don't expose your key in plaintext files

### Option A: Windows Credential Manager (RECOMMENDED — most secure)

Your key never touches a file on disk. It's stored in Windows' built-in secure vault, accessible only to your Windows user account.

**How to use:**

1. Double-click **`SAVE-API-KEY.bat`**
2. Choose which provider (e.g., 1 for Gemini)
3. Paste your key — it's hidden as you type
4. Done. The key is now in Credential Manager.

**When you start Aether.bat**, it automatically loads the key from Credential Manager into environment variables. You never see or manage the key again.

**To delete the key later:** run **`DELETE-API-KEY.bat`**

**Why this is secure:**
- Key is stored in Windows Credential Manager (OS-level encryption)
- Only your Windows user account can access it
- Key is never written to any file on disk
- Survives project folder moves/deletions
- No password to remember (tied to your Windows login)

---

### Option B: Encrypted `.env` file (portable alternative)

If you want to move your key between computers, use a password-encrypted file.

**How to use:**

1. Create a file called `secrets.env` (NOT `.env`)
2. Add your keys:
   ```
   GEMINI_API_KEY=AIzaSy...
   ```
3. Add `secrets.env` to `.gitignore` (already done)
4. When starting Aether, manually load it:
   ```batch
   set /p KEY=<secrets.env
   ```

**Why less secure than Option A:**
- File is on disk (even if in `.gitignore`)
- Can be accidentally exposed (cloud sync, backups)
- Anyone with file access can read it

---

### Security best practices

✅ **DO:**
- Use Option A (Credential Manager) for keys you don't need to move
- Keep `.env` in `.gitignore` (already configured)
- Delete keys with `DELETE-API-KEY.bat` when you stop using a provider
- Use free-tier limits (Gemini: 500/day) to avoid surprise charges

❌ **DON'T:**
- Paste keys into chat, email, or shared documents
- Commit `.env` to Git (it's in `.gitignore` but double-check)
- Store keys in cloud-synced folders (OneDrive, Dropbox)
- Use API keys from untrusted sources (GitHub, forums)
