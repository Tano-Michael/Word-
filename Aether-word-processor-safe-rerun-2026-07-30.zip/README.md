# Aether — AI Document OS

An AI-native document platform that goes beyond Microsoft Word: a full
Word-class editor fused with copilot drafting, Grammarly-depth proofing,
QuillBot-style rewriting, research briefs, living outlines, version history,
and true DOCX / PDF import & export.

---

## Install on Windows (two clicks)

1. Unzip this folder somewhere permanent, e.g. `C:\Aether`
2. Double-click **`INSTALL.bat`**
3. Double-click the **Aether** icon that appears on your Desktop

There is **no database to install** and **no configuration to edit**.
If Node.js is missing, the installer fetches it automatically via `winget`.

### macOS / Linux

```bash
./install.sh     # one-time setup
./start.sh       # launch
```

---

## Connect Aether to the internet

Aether is hybrid: private local engines always work, and cloud providers make
Grammar, Rewrite, and Copilot significantly more capable when connected.

### Windows — one click

Double-click **`CONNECT-ONLINE-AI.bat`**, then choose:

1. OpenAI (GPT)
2. Anthropic (Claude)
3. Google Gemini
4. LanguageTool grammar only
5. Disable online services

The script asks for the provider key securely and writes it to `.env` inside
your Aether folder. Close and restart `Aether.bat` afterward.

### What works without a paid key

The Grammar panel includes **Check online**, powered by LanguageTool for light
personal use. It sends text only after you explicitly press that button. The
automatic live underlines remain private and local.

For higher-volume or commercial use, configure a paid or self-hosted
LanguageTool endpoint:

```env
LANGUAGETOOL_API_URL=https://your-server.example/v2/check
LANGUAGETOOL_USERNAME=your-email
LANGUAGETOOL_API_KEY=your-key
LANGUAGETOOL_AUTOMATIC=1
```

### Cloud provider variables (manual alternative)

```env
# Choose exactly one provider
AETHER_AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4.1-mini

# or
AETHER_AI_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-3-5-haiku-latest

# or
AETHER_AI_PROVIDER=gemini
GEMINI_API_KEY=...
GEMINI_MODEL=gemini-2.5-flash
```

Keys are read only by the Next.js server and are never bundled into the browser.
If any cloud request fails or times out, Aether automatically uses the local
engine instead.

## How storage works

Aether ships with an **embedded PostgreSQL** engine
([PGlite](https://pglite.dev) — real Postgres compiled to WebAssembly) that
runs inside the app process. Your documents live in the `data/` folder
next to the app.

- **Back up your work:** copy the `data/` folder
- **Move to another PC:** copy the whole folder
- **Nothing leaves your machine**

### Optional: use your own PostgreSQL server

If you already run PostgreSQL and prefer it, create `.env`:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/aether
```

then run `npx drizzle-kit push`. Aether detects the variable and switches
from the embedded engine to your server automatically.

---

## Make it a real desktop app

Aether is a PWA. Once it's running in Chrome or Edge, click the **install
icon** in the address bar (or the on-screen banner). You get:

- Its own window — no tabs, no address bar
- A Start-menu / Taskbar / Dock icon
- Offline launch
- Registration as a handler for `.docx`, `.pdf`, `.md`, `.txt`, `.html`

---

## Everyday commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server with hot reload |
| `npm run build` | Production build |
| `npm start` | Run the production server |
| `npm run typecheck` | TypeScript check |
| `npm run lint` | ESLint |
| `npx drizzle-kit push` | Apply schema changes (server-DB mode only) |

---

## Troubleshooting

**Window flashes and closes**
Open Command Prompt, drag `INSTALL.bat` into it, press Enter to read the error.

**"Windows protected your PC" (SmartScreen)**
The scripts aren't code-signed. Click *More info → Run anyway*. You can read
`INSTALL.bat` in Notepad first — it's plain text.

**"Node.js was installed but this window cannot see it yet"**
Expected. Close the window and run `INSTALL.bat` again so Windows refreshes PATH.

**Port 3000 in use**
Aether checks several fallback ports automatically.

**DOCX does not download**
Run `UPDATE.bat`, restart Aether, then open `/api/diagnose` in the browser.
The diagnostic now tests both the rich DOCX engine and the compatibility
fallback. Chrome and Edge receive a native Save As dialog; other browsers use
their normal download flow.

**Netlify deployment**
Set a persistent `DATABASE_URL` before deploying. Temporary serverless `/tmp`
storage is intentionally rejected because it can lose or split documents.

**Start completely over**
Delete the `data/` folder (erases documents) and re-run `INSTALL.bat`.

---

## Tech stack

- **Next.js 16** (App Router) · **React 19** · **TypeScript**
- **Tailwind CSS 4**
- **TipTap / ProseMirror** editor engine
- **PGlite** (embedded Postgres) or **PostgreSQL** · **Drizzle ORM**
- **Mammoth** (DOCX in) · **docx** (DOCX out) · **pdfjs-dist** (PDF in) · **jsPDF** (PDF out)

## Features

Rich text editing · headings · lists · tables with row/column controls · images ·
links · code blocks · find & replace · ruler with draggable margins · page setup ·
print · watermarks · columns · page breaks · dark mode · focus mode · slash
commands · floating toolbar · live proofing underlines · read aloud · dictation ·
18 AI writing modes · 13 rewrite styles · writing analytics · version history ·
comments · templates · DOCX/PDF/Markdown/HTML/TXT/JSON import & export.
